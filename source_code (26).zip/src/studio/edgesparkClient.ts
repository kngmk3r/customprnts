/**
 * Shared EdgeSpark client for CUSTOM PRNTS Studio.
 *
 * Provides authenticated API calls via client.api.fetch().
 * Session is lazily initialized — Studio UI is shown immediately.
 */

import { createEdgeSpark } from '@edgespark/client';

/**
 * Build-time constant from Vite env, falling back to the known deployed
 * backend URL so the client is NEVER without a worker URL.
 */
const BUILD_TIME_WORKER_URL: string =
  import.meta.env.VITE_EDGESPARK_WORKER_URL || '';

/** Known fallback — used when the env var is also empty. */
const FALLBACK_WORKER_URL =
  'https://staging--i9maj862bm27b55rlkm2.youbase.cloud';

/**
 * Resolves the worker URL with a clear priority chain:
 *  1. Runtime override: globalThis.__EDGESPARK_WORKER_URL__ or window.ywConfig.worker_url
 *  2. Build-time env:   import.meta.env.VITE_EDGESPARK_WORKER_URL
 *  3. Hardcoded fallback for the deployed backend
 *
 * An empty string is now effectively unreachable.
 */
function getWorkerUrl(): string {
  const runtimeUrl =
    (globalThis as any).__EDGESPARK_WORKER_URL__
    || (globalThis as any).ywConfig?.worker_url
    || '';

  const workerUrl = runtimeUrl || BUILD_TIME_WORKER_URL || FALLBACK_WORKER_URL;

  if (!workerUrl) {
    // Should be unreachable given the fallback chain above.
    console.error(
      '[CUSTOM PRNTS] CRITICAL: Worker URL is empty after all fallbacks. ' +
      'Check VITE_EDGESPARK_WORKER_URL build config.'
    );
  }

  return workerUrl;
}

let _client: ReturnType<typeof createEdgeSpark> | null = null;

export function getEdgeSparkClient() {
  if (!_client) {
    const workerUrl = getWorkerUrl();
    if (!workerUrl) throw new Error('Worker URL not configured');
    _client = createEdgeSpark({ baseUrl: workerUrl });
  }
  return _client;
}

// ── helpers ────────────────────────────────────────────────────

/** Safe user-shape check — never exposes tokens or raw session objects. */
function hasValidUser(data: any): boolean {
  return !!data?.user && typeof data.user === 'object';
}

/** Safe domain-only logger — never logs full URLs, tokens, cookies, or keys. */
function safeDomain(url: string): string {
  try { return new URL(url).hostname; } catch { return '(invalid-url)'; }
}

// ── session ────────────────────────────────────────────────────

/**
 * Reliable anonymous session initialisation.
 *
 * 1. Try to restore an existing session (fast path).
 * 2. Create an anonymous session if none exists.
 * 3. Verify the result by calling getSession() again.
 * 4. Only return true once a valid user is confirmed.
 *
 * Returns `false` with a safe error reason on failure.
 * Never logs tokens, cookies, API keys, or raw session values.
 */
export async function ensureSession(): Promise<{ ok: boolean; reason?: string }> {
  try {
    const client = getEdgeSparkClient();
    const workerUrl = getWorkerUrl();

    // ── TEMP DIAGNOSTIC: worker URL resolution ──
    const ywConfigExists = !!(globalThis as any).ywConfig;
    const edgsparkGlobalExists = !!(globalThis as any).__EDGESPARK_WORKER_URL__;
    console.warn(
      '[CUSTOM PRNTS AUTH]',
      JSON.stringify({
        step: 'init',
        workerHost: safeDomain(workerUrl),
        workerUrlLength: workerUrl.length,
        ywConfigExists,
        edgsparkGlobalExists,
      })
    );

    // 1. Check for an existing session
    let existing: any;
    try {
      existing = await client.auth.getSession();
    } catch (getSessionErr: any) {
      const safeReason = 'getSession() threw: ' + safeMessage(getSessionErr);
      console.warn('[CUSTOM PRNTS AUTH]', safeReason);
      // Don't return false yet — session might still be creatable
      existing = { data: null };
    }

    const existingHasUser = hasValidUser(existing?.data);
    console.warn(
      '[CUSTOM PRNTS AUTH]',
      JSON.stringify({ step: 'getSession', hasUser: existingHasUser })
    );

    if (existingHasUser) {
      return { ok: true };
    }

    // 2. Create anonymous session
    let signInResult: any;
    try {
      signInResult = await client.auth.signIn.anonymous();
    } catch (signInErr: any) {
      const safeReason = 'signIn.anonymous() threw: ' + safeMessage(signInErr);
      console.warn('[CUSTOM PRNTS AUTH]', safeReason);
      return { ok: false, reason: safeReason };
    }

    // ── TEMP DIAGNOSTIC: safe fields from signIn result ──
    // No tokens, cookies, API keys, session objects, phone numbers, or user IDs logged.
    const signInError = signInResult?.error;
    const signInData = signInResult?.data;
    const hasError = !!signInError;
    const hasData = !!signInData;
    const errorCode = signInError?.code || signInError?.name || null;
    const errorMessage = signInError?.message || signInError?.status || null;
    const errorStatus = signInError?.error?.status || null;
    const dataUserExists = hasData && !!signInData?.user;
    const dataHasToken = hasData && !!signInData?.token;
    console.warn(
      '[CUSTOM PRNTS AUTH]',
      JSON.stringify({
        step: 'signIn.anonymous',
        hasError,
        hasData,
        dataUserExists,
        dataHasToken,
        errorCode,
        errorMessage,
        errorStatus,
        signInOk: !hasError,
      })
    );

    // Inspect the sign-in response for an error
    if (signInResult?.error) {
      const safeReason = 'signIn.anonymous() returned error: code='
        + (signInResult.error?.code || 'none')
        + ' message=' + (signInResult.error?.message || 'none');
      console.warn('[CUSTOM PRNTS AUTH]', safeReason);
      return { ok: false, reason: safeReason };
    }

    // 3. Verify by fetching the session again
    let verified: any;
    try {
      verified = await client.auth.getSession();
    } catch (verifyErr: any) {
      const safeReason = 'getSession() after signIn threw: ' + safeMessage(verifyErr);
      console.warn('[CUSTOM PRNTS AUTH]', safeReason);
      return { ok: false, reason: safeReason };
    }

    const verifiedHasUser = hasValidUser(verified?.data);
    console.warn(
      '[CUSTOM PRNTS AUTH]',
      JSON.stringify({ step: 'verify', hasUser: verifiedHasUser })
    );

    if (verifiedHasUser) {
      return { ok: true };
    }

    const safeReason = 'Session not established after anonymous sign-in. '
      + 'signInResult had data=' + !!signInResult?.data
      + ' user=' + !!signInResult?.data?.user
      + ' token=' + !!signInResult?.data?.token;
    console.warn('[CUSTOM PRNTS AUTH]', safeReason);
    return { ok: false, reason: safeReason };
  } catch (e: any) {
    const safeReason = 'Session initialisation failed: ' + safeMessage(e);
    console.warn('[CUSTOM PRNTS AUTH]', safeReason);
    return { ok: false, reason: safeReason };
  }
}

/** Extract a safe, non-sensitive error message. */
function safeMessage(err: any): string {
  if (err instanceof Error) return err.message;
  if (typeof err === 'string') return err;
  return 'unknown error';
}

// ── authenticated fetch ─────────────────────────────────────────

/**
 * Authenticated fetch — auto-injects session token.
 * If no session exists, the backend returns 401 which surfaces
 * as a ConceptGenerationError with retryable: true.
 */
export async function studioFetch(path: string, options?: RequestInit): Promise<Response> {
  const client = getEdgeSparkClient();
  return client.api.fetch(path, options);
}
