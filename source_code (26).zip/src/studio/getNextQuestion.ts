/**
 * Interview Question Generator
 *
 * This module drives the sequential Q&A flow for new project creation.
 * Each call to `getNextQuestion(brief)` returns the next unanswered question,
 * or `null` when all required questions are answered (review step).
 *
 * To swap for a real AI-driven conversation, replace the body of
 * `getNextQuestion()` — the UI layer remains unchanged.
 */

import type { ProjectBrief } from './storage';

export interface InterviewQuestion {
  id: keyof ProjectBrief;
  label: string;
  prompt: string;
  type: 'text' | 'textarea' | 'select' | 'color-picker' | 'color-swatches' | 'image-upload';
  options?: { value: string; label: string }[];
  colors?: { name: string; hex: string }[];
  multi?: boolean;
  placeholder?: string;
  required: boolean;
}

export const SHIRT_COLORS = [
  { name: 'Black', hex: '#1a1a1a' },
  { name: 'White', hex: '#f5f5f5' },
  { name: 'Tan', hex: '#c2b280' },
  { name: 'Gray', hex: '#808080' },
  { name: 'Red', hex: '#c41e3a' },
  { name: 'Blue', hex: '#1E3A8A' },
];

export const DESIGN_COLORS = [
  { name: 'Gold', hex: '#D4AF37' },
  { name: 'Black', hex: '#1a1a1a' },
  { name: 'White', hex: '#FAFAFA' },
  { name: 'Red', hex: '#c41e3a' },
  { name: 'Navy', hex: '#1E3A8A' },
  { name: 'Royal Blue', hex: '#4169E1' },
  { name: 'Green', hex: '#2d8b2d' },
  { name: 'Purple', hex: '#6b21a8' },
  { name: 'Pink', hex: '#ec4899' },
  { name: 'Orange', hex: '#f97316' },
  { name: 'Gray', hex: '#808080' },
  { name: 'Silver', hex: '#c0c0c0' },
  { name: 'Maroon', hex: '#800000' },
  { name: 'Teal', hex: '#008080' },
];

export const allQuestions: InterviewQuestion[] = [
  {
    id: 'name',
    label: 'Project Name',
    prompt: "What's your project name?",
    type: 'text',
    placeholder: 'e.g., Summer Collection Tee',
    required: true,
  },
  {
    id: 'description',
    label: 'Design Vision',
    prompt: 'Describe your design idea — the mood, style, concept, or visual references you have in mind.',
    type: 'textarea',
    placeholder: 'Describe the concept, mood, style, and any visual ideas...',
    required: false,
  },
  {
    id: 'referenceImageUrl',
    label: 'Reference Image',
    prompt: 'Have a design, logo, or reference image? Upload it to incorporate into your design.',
    type: 'image-upload',
    required: false,
  },
  {
    id: 'productType',
    label: 'Product Type',
    prompt: 'What product is this design for?',
    type: 'select',
    options: [
      { value: 'T-Shirt', label: 'T-Shirt' },
      { value: 'Hoodie', label: 'Hoodie' },
      { value: 'Tank Top', label: 'Tank Top' },
    ],
    required: true,
  },
  {
    id: 'shirtColor',
    label: 'Base Color',
    prompt: 'Pick a base color for the product.',
    type: 'color-swatches',
    colors: SHIRT_COLORS,
    required: true,
  },
  {
    id: 'preferredColors',
    label: 'Design Colors',
    prompt: 'Pick up to 3 colors for your design.',
    type: 'color-swatches',
    colors: DESIGN_COLORS,
    multi: true,
    required: false,
  },
  {
    id: 'mainWording',
    label: 'Main Text',
    prompt: "What's the main text or wording for the design?",
    type: 'text',
    placeholder: 'e.g., STAY TRUE',
    required: true,
  },
  {
    id: 'notes',
    label: 'Additional Notes',
    prompt: 'Any extra details, references, or special requests? (or skip)',
    type: 'textarea',
    placeholder: 'Any additional notes or references...',
    required: false,
  },
];

/**
 * Returns the next question to display, or null when all required
 * fields are answered and we're ready for review.
 *
 * A field is considered "unanswered" only when its value is undefined
 * (never set). Empty strings ('') count as answered — this handles
 * optional/skipped fields so the flow advances to Review exactly once.
 */
export function getNextQuestion(brief: Partial<ProjectBrief>): InterviewQuestion | null {
  for (const q of allQuestions) {
    const val = brief[q.id as keyof ProjectBrief];
    // Only skip when the field has been explicitly set (even to '')
    if (val !== undefined) {
      continue;
    }
    return q;
  }
  // All questions have been asked
  return null;
}

/**
 * Get total number of questions
 */
export function getTotalQuestions(): number {
  return allQuestions.length;
}

/**
 * Get question index (0-based) from the brief.
 * A field is "unanswered" only when its value is undefined.
 */
export function getCurrentQuestionIndex(brief: Partial<ProjectBrief>): number {
  for (let i = 0; i < allQuestions.length; i++) {
    const q = allQuestions[i];
    const val = brief[q.id as keyof ProjectBrief];
    if (val === undefined) {
      return i;
    }
  }
  return allQuestions.length; // all answered = review
}

/**
 * Returns the 0-based index of a question by its id, or -1 if not found.
 */
export function getQuestionIndexById(id: keyof ProjectBrief): number {
  return allQuestions.findIndex(q => q.id === id);
}
