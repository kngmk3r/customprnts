/**
 * AI-Powered Concept Generator (Client Side)
 *
 * Calls server-side authenticated endpoints for real image generation.
 * Server handles Gemini → OpenAI fallback, storage, signed URLs.
 * Client does NOT fall back to mock generation.
 *
 * All errors are surfaced as ConceptGenerationError with safe customer text.
 */

import type { ProjectBrief } from './storage';
import { studioFetch } from './edgesparkClient';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

export interface Concept {
  id: string;
  name: string;
  imageUrl: string;
  storageKey: string;
  provider?: string;
  model?: string;
  meta?: {
    batchId: string;
    provider: string;
    model: string;
    promptVersion: string;
    totalDurationMs: number;
  };
}

export interface GenerationError {
  code: string;
  message: string;
  retryable: boolean;
}

// ═══════════════════════════════════════════════════════════════════
// ERROR CLASS
// ═══════════════════════════════════════════════════════════════════

export class ConceptGenerationError extends Error {
  code: string;
  retryable: boolean;
  constructor(err: GenerationError) {
    super(err.message);
    this.name = 'ConceptGenerationError';
    this.code = err.code;
    this.retryable = err.retryable;
  }
}

// ═══════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════

/** Parse a non-ok Response into a ConceptGenerationError with safe customer text. */
async function parseResponseError(res: Response): Promise<ConceptGenerationError> {
  // 401 — session expired or not created
  if (res.status === 401) {
    return new ConceptGenerationError({
      code: 'SESSION_EXPIRED',
      message: 'Your private workspace session expired or could not be created. Please try again.',
      retryable: true,
    });
  }

  // 429 — rate limited
  if (res.status === 429) {
    return new ConceptGenerationError({
      code: 'RATE_LIMITED',
      message: 'Too many requests. Please wait a moment and try again.',
      retryable: true,
    });
  }

  let body: any;
  try { body = await res.json(); } catch { body = {}; }

  const err: GenerationError = body.error || {
    code: 'SERVER_ERROR',
    message: `Server error ${res.status}`,
    retryable: res.status >= 500,
  };

  return new ConceptGenerationError(err);
}

// ═══════════════════════════════════════════════════════════════════
// BATCH GENERATION (4 images)
// ═══════════════════════════════════════════════════════════════════

export async function generateConceptsAsync(brief: ProjectBrief, tier: 'free' | 'premium' = 'free'): Promise<Concept[]> {
  let res: Response;
  try {
    res = await studioFetch('/api/generate-batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: brief.name, description: brief.description, productType: brief.productType,
        preferredColors: brief.preferredColors, mainWording: brief.mainWording, notes: brief.notes,
        tier,
      }),
    });
  } catch (netErr: any) {
    // Network failure — fetch() throws TypeError on DNS/TLS/connection errors
    throw new ConceptGenerationError({
      code: 'NETWORK_ERROR',
      message: "We couldn't reach the design-generation service. Please try again.",
      retryable: true,
    });
  }

  if (!res.ok) {
    throw await parseResponseError(res);
  }

  const data = await res.json();
  if (!data.success || !data.designs?.length) {
    throw new ConceptGenerationError(data.error || { code: 'GENERATION_FAILED', message: 'No designs generated.', retryable: true });
  }

  console.log('[SUCCESS] Batch generated:', { count: data.designs.length, provider: data.metadata?.provider });

  return data.designs.map((d: any) => ({
    id: d.id,
    name: d.conceptName,
    imageUrl: d.signedPreviewUrl,
    storageKey: d.storageKey,
    provider: data.metadata?.provider,
    model: data.metadata?.model,
    meta: data.metadata,
  }));
}

// ═══════════════════════════════════════════════════════════════════
// SINGLE DESIGN REGENERATION
// ═══════════════════════════════════════════════════════════════════

export async function regenerateDesignAsync(
  designId: string,
  brief: ProjectBrief
): Promise<Concept> {
  const endpoint = '/api/regenerate-design';

  let res: Response;
  try {
    res = await studioFetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        designId,
        brief: {
          name: brief.name, description: brief.description, productType: brief.productType,
          preferredColors: brief.preferredColors, mainWording: brief.mainWording, notes: brief.notes,
        },
      }),
    });
  } catch {
    throw new ConceptGenerationError({
      code: 'NETWORK_ERROR',
      message: "We couldn't reach the design-generation service. Please try again.",
      retryable: true,
    });
  }

  if (!res.ok) {
    throw await parseResponseError(res);
  }

  const data = await res.json();
  if (!data.success || !data.design) {
    throw new ConceptGenerationError(data.error || { code: 'GENERATION_FAILED', message: 'Regeneration failed.', retryable: true });
  }

  return {
    id: data.design.id,
    name: data.design.conceptName,
    imageUrl: data.design.signedPreviewUrl,
    storageKey: data.design.storageKey,
    provider: data.metadata?.provider,
    model: data.metadata?.model,
    meta: data.metadata,
  };
}

// ═══════════════════════════════════════════════════════════════════
// GET DESIGNS FOR A PROJECT
// ═══════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════
// DESIGN HISTORY (all batches for a project)
// ═══════════════════════════════════════════════════════════════════

export interface HistoryBatch {
  batchId: string;
  provider: string | null;
  model: string | null;
  createdAt: number | null;
  designs: Concept[];
}

export async function getDesignHistory(projectId: string): Promise<HistoryBatch[]> {
  try {
    const res = await studioFetch(`/api/design-history/${projectId}`);
    if (!res.ok) return [];
    const data = await res.json();
    return (data.batches || []).map((b: any) => ({
      batchId: b.batchId,
      provider: b.provider,
      model: b.model,
      createdAt: b.createdAt,
      designs: (b.designs || []).map((d: any) => ({
        id: d.id,
        name: d.conceptName,
        imageUrl: d.signedPreviewUrl,
        storageKey: d.storageKey,
        provider: d.provider,
        model: d.model,
      })),
    }));
  } catch {
    return [];
  }
}

// ═══════════════════════════════════════════════════════════════════
// LOCKER — add, list, remove
// ═══════════════════════════════════════════════════════════════════

export interface LockerItem {
  id: string;
  designId: string;
  designImageUrl: string;
  storageKey: string;
  prompt: string | null;
  productType: string | null;
  style: string | null;
  conceptName: string | null;
  createdAt: number;
}

export interface LockerGroup {
  projectId: string;
  projectName: string;
  items: LockerItem[];
}

export async function addToLocker(params: {
  designId: string;
  projectId: string;
  imageUrl: string;
  storageKey: string;
  prompt?: string;
  productType?: string;
  style?: string;
  conceptName?: string;
}): Promise<{ success: boolean; id?: string }> {
  try {
    const res = await studioFetch('/api/locker/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    return { success: data.success, id: data.id };
  } catch {
    return { success: false };
  }
}

export async function getLockerItems(): Promise<LockerGroup[]> {
  try {
    const res = await studioFetch('/api/locker');
    if (!res.ok) return [];
    const data = await res.json();
    return data.groups || [];
  } catch {
    return [];
  }
}

export async function removeFromLocker(id: string): Promise<boolean> {
  try {
    const res = await studioFetch(`/api/locker/${id}`, { method: 'DELETE' });
    return res.ok;
  } catch {
    return false;
  }
}

export async function getDesignsForProject(projectId: string): Promise<Concept[]> {
  try {
    const res = await studioFetch(`/api/designs/${projectId}`);
    if (!res.ok) return [];
    const data = await res.json();
    return (data.designs || []).map((d: any) => ({
      id: d.id,
      name: d.conceptName,
      imageUrl: d.signedPreviewUrl,
      storageKey: d.storageKey,
      provider: d.provider,
      model: d.model,
    }));
  } catch {
    return [];
  }
}
