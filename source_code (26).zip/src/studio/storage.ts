/**
 * Storage Service for CUSTOM PRNTS Design Studio
 */

const DB_NAME = 'cp-studio';
const DB_VERSION = 1;
const STORE_NAME = 'projects';

export interface ProjectBrief {
  name: string;
  description: string;
  productType: 'T-Shirt' | 'Hoodie' | 'Tank Top';
  shirtColor: string;
  preferredColors: string;
  referenceImageUrl?: string;
  mainWording: string;
  notes: string;
}

export interface Project {
  id: string;
  brief: ProjectBrief;
  /** Which concept was selected from the AI generation batch */
  selectedConceptId: string | null;
  /**
   * Serialized Fabric.js canvas state — the artwork layers.
   * This is INDEPENDENT of product type, color, or placement.
   * Artwork lives here; product identity lives in brief.productType / shirtColor.
   */
  canvasJSON: string | null;
  /** URL of the selected concept image (signed, temporary) */
  conceptImageUrl: string | null;
  /** Remote backend project ID (from /api/generate-batch) */
  remoteProjectId: string | null;
  /** Canvas thumbnail for project browser */
  canvasThumbnail: string | null;
  /** Display-ready design image */
  designDataUrl: string | null;
  /** Product color hex — independent of artwork colors */
  shirtColor: string;
  /** V2: Product ID for the selected product */
  productId?: string;
  /** V2: Color ID for the selected color */
  colorId?: string;
  /** V2: Viewpoint ID for the selected view */
  viewId?: string;
  /** V2: Product placement (position on the product surface) — independent of artwork */
  placement?: {
    presetId?: string;
    widthInches: number;
    topOffsetInches: number;
    horizontalOffsetInches: number;
    rotationDegrees: number;
  };
  /** Legacy placement (kept for backward compatibility) */
  legacyPlacement?: {
    size: number;
    verticalOffset: number;
  };
  createdAt: string;
  updatedAt: string;
}

function generateId(): string {
  return `proj_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

let db: IDBDatabase | null = null;

function openDB(): Promise<IDBDatabase> {
  if (db) return Promise.resolve(db);
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };
    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        database.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
}

export async function saveProject(project: Project): Promise<void> {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.put({ ...project, updatedAt: new Date().toISOString() });
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function getProject(id: string): Promise<Project | undefined> {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(id);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllProjects(): Promise<Project[]> {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => {
      const projects = request.result as Project[];
      projects.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
      resolve(projects);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function deleteProject(id: string): Promise<void> {
  const database = await openDB();
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function duplicateProject(project: Project): Promise<Project> {
  const newProject: Project = {
    ...project,
    id: generateId(),
    brief: { ...project.brief, name: `${project.brief.name} (Copy)` },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  await saveProject(newProject);
  return newProject;
}

export function createNewProject(brief: ProjectBrief): Project {
  return {
    id: generateId(),
    brief,
    selectedConceptId: null,
    canvasJSON: null,
    conceptImageUrl: null,
    remoteProjectId: null,
    canvasThumbnail: null,
    designDataUrl: null,
    shirtColor: brief.shirtColor || '#1a1a1a',
    placement: {
      widthInches: 10,
      topOffsetInches: 3,
      horizontalOffsetInches: 0,
      rotationDegrees: 0,
    },
    legacyPlacement: { size: 100, verticalOffset: 0 },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

// ── Regeneration rate-limit persistence (localStorage) ──

const REGEN_STATE_KEY = 'cp-studio-regen-state';

export interface RegenState {
  regenCount: number;
  cooldownEnd: number | null;
}

export function loadRegenState(): RegenState {
  try {
    const raw = localStorage.getItem(REGEN_STATE_KEY);
    if (!raw) return { regenCount: 0, cooldownEnd: null };
    const parsed = JSON.parse(raw) as RegenState;
    // If cooldown has already expired, reset
    if (parsed.cooldownEnd && Date.now() >= parsed.cooldownEnd) {
      return { regenCount: 0, cooldownEnd: null };
    }
    return parsed;
  } catch {
    return { regenCount: 0, cooldownEnd: null };
  }
}

export function saveRegenState(state: RegenState): void {
  try {
    localStorage.setItem(REGEN_STATE_KEY, JSON.stringify(state));
  } catch {
    // localStorage unavailable — fail silently
  }
}

export function clearRegenState(): void {
  try {
    localStorage.removeItem(REGEN_STATE_KEY);
  } catch {
    // fail silently
  }
}
