# CUSTOM PRNTS Design Studio — README

## Overview
The Design Studio is a standalone `/studio` experience for creating custom apparel designs. It runs entirely in the browser with no server dependency.

## Architecture
```
src/studio/
├── index.ts                  — Public exports
├── StudioApp.tsx             — Main view router (manages page state)
├── storage.ts                — IndexedDB storage service
├── store.ts                  — React state management hook
├── conceptGenerator.ts       — Mock AI concept generation
├── exportService.ts          — Export/download functions
└── pages/
    ├── ProjectsPage.tsx      — Project list & empty state
    ├── NewProjectPage.tsx    — Brief form
    ├── ConceptSelectionPage.tsx — 3 concept previews
    ├── DesignEditorPage.tsx  — Fabric.js canvas editor
    └── ShirtPreviewPage.tsx  — T-shirt mockup preview
```

## Where Projects Are Stored
All data lives in **browser IndexedDB** (database: `cp-studio`, object store: `projects`).
No server, no cloud sync — purely local storage.

### What gets saved per project:
- Project name & creative brief
- Selected concept ID
- Canvas JSON (Fabric.js serialized state)
- Canvas thumbnail (base64 dataURL)
- Shirt color & placement settings
- Created/updated timestamps

**Autosave**: Every canvas change triggers a 1.5s debounced save to IndexedDB.

## The Mock AI Generator

**Location**: `src/studio/conceptGenerator.ts`

**Function**: `generateConcepts(brief: ProjectBrief) → Concept[]`

This function generates 3 placeholder design concepts using canvas JSON objects (rectangles, text, circles, lines) with colors derived from the brief. It makes **zero external API calls**.

### How to Replace with a Real AI API

1. Open `src/studio/conceptGenerator.ts`
2. Replace the body of `generateConcepts()` with:

```typescript
export async function generateConcepts(brief: ProjectBrief): Promise<Concept[]> {
  const response = await fetch('https://your-api.com/generate-concepts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(brief),
  });
  const data = await response.json();
  // Must return: Array<{ id: string; name: string; canvasJSON: object }>
  return data.concepts;
}
```

3. Update `StudioApp.tsx` to handle the async return (add `await` to `store.createProject`)
4. No UI code changes needed — the UI only calls `generateConcepts()` from this one file.

## Export & Backup

### From the Design Editor:
- **Export Transparent PNG** — Downloads design as transparent `.png` (2x resolution)
- **Export PNG with Background** — Downloads with canvas background color
- **Download Project JSON** — Downloads full project state as `.json` (can be re-imported later)

### Backup/Restore:
To backup all projects, open browser DevTools → Application → IndexedDB → `cp-studio` → `projects`, and export the entire store. To restore, import into the same IndexedDB path.

## Tech Stack
- **Canvas Editor**: Fabric.js 5.3 (loaded via CDN)
- **State**: React useState + custom hooks
- **Storage**: IndexedDB
- **Styling**: Tailwind CSS with custom studio theme tokens

## Access Control
The studio is protected by YouWare's project-level password/privacy. No login system is built into the app itself.
