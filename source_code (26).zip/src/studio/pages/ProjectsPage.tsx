import { useEffect } from 'react';
import type { Project } from '../storage';

interface Props {
  projects: Project[];
  isLoading: boolean;
  onLoadProjects: () => void;
  onNewProject: () => void;
  onOpenProject: (id: string) => void;
  onDuplicateProject: (project: Project) => void;
  onDeleteProject: (id: string) => void;
}

export default function ProjectsPage({
  projects,
  isLoading,
  onLoadProjects,
  onNewProject,
  onOpenProject,
  onDuplicateProject,
  onDeleteProject,
}: Props) {
  useEffect(() => {
    onLoadProjects();
  }, [onLoadProjects]);

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-studio-surface">
      {/* Header */}
      <div className="border-b border-studio-border bg-studio-surface sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
          <div>
            <h1 className="font-condensed text-2xl md:text-3xl font-bold tracking-wider text-white uppercase">
              CUSTOM PRNTS <span className="text-studio-gold">DESIGN STUDIO</span>
            </h1>
            <p className="text-studio-muted text-sm tracking-[0.3em] uppercase mt-1">FREE TIL' PRNT</p>
          </div>
          <button
            onClick={onNewProject}
            className="studio-btn-primary"
            aria-label="Create New Project"
          >
            + New Project
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {isLoading ? (
          <div className="text-center py-20">
            <div className="inline-block w-8 h-8 border-2 border-studio-gold border-t-transparent rounded-full animate-spin" />
            <p className="text-studio-muted mt-4">Loading projects...</p>
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-studio-elevated border border-studio-border flex items-center justify-center">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-studio-gold">
                <path d="M12 5v14M5 12h14" />
              </svg>
            </div>
            <h2 className="text-xl font-condensed font-bold text-white tracking-wider uppercase mb-2">No Projects Yet</h2>
            <p className="text-studio-muted mb-8 max-w-md mx-auto">
              Start your first custom design. Describe your vision and we'll generate concept options for you.
            </p>
            <button onClick={onNewProject} className="studio-btn-primary" aria-label="Create Your First Project">
              Create Your First Project
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <div
                key={project.id}
                className="bg-studio-elevated border border-studio-border rounded-lg overflow-hidden hover:border-studio-gold/30 transition-colors"
              >
                {/* Thumbnail */}
                <div className="aspect-[4/3] bg-studio-surface flex items-center justify-center">
                  {project.canvasThumbnail || (project as any).conceptImageUrl ? (
                    <img
                      src={project.canvasThumbnail || (project as any).conceptImageUrl}
                      alt={project.brief.name}
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        // If image fails to load, show placeholder
                        (e.target as HTMLImageElement).style.display = 'none';
                        const parent = (e.target as HTMLImageElement).parentElement;
                        if (parent && !parent.querySelector('.fallback-placeholder')) {
                          const div = document.createElement('div');
                          div.className = 'fallback-placeholder text-center p-6';
                          div.innerHTML = '<div class="w-16 h-16 mx-auto mb-3 rounded border border-studio-border flex items-center justify-center"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="text-studio-muted"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></svg></div><p class="text-studio-muted text-xs uppercase tracking-wider">No preview</p>';
                          parent.appendChild(div);
                        }
                      }}
                    />
                  ) : (
                    <div className="text-center p-6">
                      <div className="w-16 h-16 mx-auto mb-3 rounded border border-studio-border flex items-center justify-center">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-studio-muted">
                          <rect x="3" y="3" width="18" height="18" rx="2" />
                          <circle cx="8.5" cy="8.5" r="1.5" />
                          <path d="M21 15l-5-5L5 21" />
                        </svg>
                      </div>
                      <p className="text-studio-muted text-xs uppercase tracking-wider">No preview</p>
                    </div>
                  )}
                </div>
                {/* Info */}
                <div className="p-4">
                  <h3 className="font-condensed text-lg font-bold text-white tracking-wider uppercase truncate">
                    {project.brief.name}
                  </h3>
                  <p className="text-studio-muted text-sm mt-1">
                    {project.brief.productType} · {formatDate(project.updatedAt)}
                  </p>
                  {/* Actions */}
                  <div className="flex gap-2 mt-4">
                    <button
                      onClick={() => onOpenProject(project.id)}
                      className="flex-1 studio-btn-primary !py-2.5 !text-sm"
                      aria-label={`Open ${project.brief.name}`}
                    >
                      Open
                    </button>
                    <button
                      onClick={() => onDuplicateProject(project)}
                      className="studio-btn-ghost !px-3 !py-2.5"
                      title="Duplicate"
                      aria-label={`Duplicate ${project.brief.name}`}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="8" y="8" width="12" height="12" rx="2" />
                        <path d="M16 8V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2" />
                      </svg>
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('Delete this project? This cannot be undone.')) {
                          onDeleteProject(project.id);
                        }
                      }}
                      className="studio-btn-ghost !px-3 !py-2.5 hover:!bg-red-900/50 hover:!text-red-400"
                      title="Delete"
                      aria-label={`Delete ${project.brief.name}`}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14z" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
