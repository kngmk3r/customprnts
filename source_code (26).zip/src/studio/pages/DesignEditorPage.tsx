/**
 * CUSTOM PRNTS — Design Editor Page (v2)
 *
 * Wraps the new EditorLayout and integrates with the StudioApp flow.
 */

import EditorLayout from '../editor/components/v2/EditorLayout';
import type { Project } from '../storage';
import type { OverlayConfig } from '../editor/overlaySystem';

interface Props {
  project: Project;
  onSave: (project: Project) => void;
  onAutosave: (project: Project) => void;
  onPreviewShirt: () => void;
  onBack: () => void;
  onOpenLocker?: () => void;
  overlays: OverlayConfig[];
  onToggleOverlay: (overlayId: string) => void;
  onUnlockDesign: () => void;
}

export default function DesignEditorPage({ project, onSave, onAutosave, onPreviewShirt, onBack, onOpenLocker, overlays, onToggleOverlay, onUnlockDesign }: Props) {
  return (
    <EditorLayout
      project={project}
      onSave={onSave}
      onAutosave={onAutosave}
      onPreview={onPreviewShirt}
      onBack={onBack}
      onOpenLocker={onOpenLocker}
      overlays={overlays}
      onToggleOverlay={onToggleOverlay}
      onUnlockDesign={onUnlockDesign}
    />
  );
}
