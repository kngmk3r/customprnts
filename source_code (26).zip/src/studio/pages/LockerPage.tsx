import { useState, useEffect, useCallback } from 'react';
import { getLockerItems, removeFromLocker, type LockerGroup, type LockerItem } from '../conceptGenerator';
import OverlayLayer from '../editor/components/OverlayLayer';
import type { OverlayConfig } from '../editor/overlaySystem';

interface Props {
  onBack: () => void;
  onApplyToModel: (item: LockerItem) => void;
  onSendToEditor: (item: LockerItem) => void;
  onSendToPreview: (item: LockerItem) => void;
  /** Non-destructive overlays — rendered above saved design images */
  overlays?: OverlayConfig[];
}

export default function LockerPage({ onBack, onApplyToModel, onSendToEditor, onSendToPreview, overlays = [] }: Props) {
  const [groups, setGroups] = useState<LockerGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [removingId, setRemovingId] = useState<string | null>(null);

  useEffect(() => {
    loadLocker();
  }, []);

  const loadLocker = useCallback(async () => {
    setLoading(true);
    const data = await getLockerItems();
    setGroups(data);
    setLoading(false);
  }, []);

  const handleRemove = useCallback(async (itemId: string) => {
    setRemovingId(itemId);
    const ok = await removeFromLocker(itemId);
    if (ok) {
      setGroups(prev =>
        prev
          .map(g => ({ ...g, items: g.items.filter(i => i.id !== itemId) }))
          .filter(g => g.items.length > 0)
      );
      setSelectedIds(prev => { const n = new Set(prev); n.delete(itemId); return n; });
    }
    setRemovingId(null);
  }, []);

  const toggleSelect = useCallback((itemId: string) => {
    setSelectedIds(prev => {
      const n = new Set(prev);
      if (n.has(itemId)) n.delete(itemId); else n.add(itemId);
      return n;
    });
  }, []);

  const selectAll = useCallback(() => {
    const allIds = groups.flatMap(g => g.items.map(i => i.id));
    setSelectedIds(new Set(allIds));
  }, [groups]);

  const deselectAll = useCallback(() => {
    setSelectedIds(new Set());
  }, []);

  const selectedItems = groups.flatMap(g => g.items).filter(i => selectedIds.has(i.id));

  return (
    <div className="min-h-screen bg-studio-surface">
      <div className="border-b border-studio-border bg-studio-surface sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-4">
          <button onClick={onBack} className="studio-btn-ghost !px-3">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M15 18l-6-6 6-6" />
            </svg>
            Back
          </button>
          <div className="flex-1">
            <h1 className="font-condensed text-xl font-bold tracking-wider text-white uppercase">Locker</h1>
            <p className="text-studio-muted text-xs tracking-wider uppercase">Your saved designs</p>
          </div>
          {groups.length > 0 && (
            <div className="flex gap-2">
              {selectedIds.size > 0 ? (
                <>
                  <button onClick={deselectAll} className="studio-btn-ghost !px-3 !text-xs">Deselect All</button>
                  <button
                    onClick={() => { if (selectedItems.length === 1) onApplyToModel(selectedItems[0]); }}
                    disabled={selectedItems.length !== 1}
                    className={`studio-btn-primary !px-4 !text-xs ${selectedItems.length !== 1 ? 'opacity-40 cursor-not-allowed' : ''}`}
                  >
                    Apply to Model
                  </button>
                </>
              ) : (
                <button onClick={selectAll} className="studio-btn-ghost !px-3 !text-xs">Select All</button>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block w-10 h-10 border-2 border-studio-gold border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-studio-muted font-condensed text-sm tracking-wider uppercase">Loading locker...</p>
          </div>
        ) : groups.length === 0 ? (
          <div className="text-center py-20">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-studio-elevated border border-studio-border mb-6">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="1.5">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                <path d="M3 9h18M9 21V9" />
              </svg>
            </div>
            <h2 className="text-xl font-condensed font-bold text-white tracking-wider uppercase mb-3">Locker is Empty</h2>
            <p className="text-studio-muted mb-6 max-w-md mx-auto">
              Go to Concepts and tap "Keep in Locker" on any design to save it here.
            </p>
            <button onClick={onBack} className="studio-btn-primary !px-6">Back to Studio</button>
          </div>
        ) : (
          <div className="space-y-10">
            {groups.map((group) => (
              <div key={group.projectId}>
                <div className="flex items-center gap-3 mb-4">
                  <h2 className="font-condensed text-base font-bold tracking-wider text-white uppercase">{group.projectName}</h2>
                  <span className="text-xs text-studio-muted/60 bg-studio-elevated px-2 py-0.5 rounded">{group.items.length} saved</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {group.items.map((item) => (
                    <div
                      key={item.id}
                      className={`bg-studio-elevated border rounded-lg overflow-hidden transition-colors ${
                        selectedIds.has(item.id) ? 'border-studio-gold ring-1 ring-studio-gold/30' : 'border-studio-border hover:border-studio-gold/20'
                      }`}
                    >
                      <div
                        className="aspect-square bg-studio-surface relative cursor-pointer"
                        onClick={() => toggleSelect(item.id)}
                      >
                        <img
                          src={item.designImageUrl}
                          alt={item.conceptName || 'Saved design'}
                          className="w-full h-full object-contain"
                          draggable={false}
                        />
                        {/* Non-destructive overlay layer above the saved design */}
                        <OverlayLayer overlays={overlays} />
                        {selectedIds.has(item.id) && (
                          <div className="absolute top-2 right-2 w-6 h-6 bg-studio-gold rounded-full flex items-center justify-center">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="3">
                              <path d="M20 6L9 17l-5-5" />
                            </svg>
                          </div>
                        )}
                      </div>
                      <div className="p-3">
                        <p className="font-condensed text-sm font-bold text-white tracking-wider uppercase mb-1 truncate">
                          {item.conceptName || 'Untitled'}
                        </p>
                        {item.productType && (
                          <p className="text-xs text-studio-muted mb-2">{item.productType}</p>
                        )}
                        {item.prompt && (
                          <p className="text-xs text-studio-muted/60 mb-3 line-clamp-2">{item.prompt}</p>
                        )}

                        <div className="flex gap-2">
                          <button
                            onClick={() => onApplyToModel(item)}
                            className="flex-1 studio-btn-primary !py-2 !text-xs"
                          >
                            Apply to Model
                          </button>
                          <button
                            onClick={() => onSendToEditor(item)}
                            className="flex-1 studio-btn-ghost !py-2 !text-xs"
                          >
                            Send to Editor
                          </button>
                        </div>
                        <div className="flex gap-2 mt-2">
                          <button
                            onClick={() => onSendToPreview(item)}
                            className="flex-1 studio-btn-ghost !py-2 !text-xs"
                          >
                            Send to Preview
                          </button>
                          <button
                            onClick={() => handleRemove(item.id)}
                            disabled={removingId === item.id}
                            className="py-2 px-3 rounded text-xs font-condensed font-bold tracking-wider uppercase bg-studio-surface border border-studio-border text-studio-muted hover:border-red-500/40 hover:text-red-400 transition-colors"
                          >
                            {removingId === item.id ? (
                              <span className="inline-block w-3 h-3 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
                            ) : (
                              'Remove'
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
