import { useState, useRef, useEffect } from 'react';
import type { ProjectBrief } from '../storage';
import { getNextQuestion, getCurrentQuestionIndex, getTotalQuestions, DESIGN_COLORS, SHIRT_COLORS, allQuestions, getQuestionIndexById } from '../getNextQuestion';
import type { InterviewQuestion } from '../getNextQuestion';

interface Props {
  onGenerate: (brief: ProjectBrief, tier: 'free' | 'premium') => Promise<void>;
  onBack: () => void;
  isGenerating: boolean;
  initialBrief?: ProjectBrief | null;
}

interface AnsweredEntry {
  question: InterviewQuestion;
  answer: string;
}

export default function NewProjectPage({ onGenerate, onBack, isGenerating, initialBrief }: Props) {
  const [brief, setBrief] = useState<Partial<ProjectBrief>>(() => {
    if (initialBrief) {
      return {
        name: initialBrief.name || '',
        description: initialBrief.description || '',
        productType: initialBrief.productType || 'T-Shirt',
        shirtColor: initialBrief.shirtColor || '#1a1a1a',
        preferredColors: initialBrief.preferredColors || '',
        mainWording: initialBrief.mainWording || '',
        notes: initialBrief.notes || '',
      };
    }
    return {};
  });
  const [answered, setAnswered] = useState<AnsweredEntry[]>(() => {
    if (initialBrief) {
      return allQuestions
        .filter(q => {
          const val = initialBrief[q.id as keyof ProjectBrief];
          return val !== undefined && val !== null && val !== '';
        })
        .map(q => ({
          question: q,
          answer: String(initialBrief[q.id as keyof ProjectBrief] || ''),
        }));
    }
    return [];
  });
  const [currentInput, setCurrentInput] = useState('');
  const [isReview, setIsReview] = useState(false);
  const [validationError, setValidationError] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const currentQuestion = getNextQuestion(brief);
  const questionIndex = getCurrentQuestionIndex(brief);
  const total = getTotalQuestions();
  const progress = Math.round((questionIndex / total) * 100);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [answered, isReview]);

  const handleBack = () => {
    if (answered.length === 0) return;
    const lastEntry = answered[answered.length - 1];
    setAnswered(prev => prev.slice(0, -1));
    const rawValue = brief[lastEntry.question.id as keyof ProjectBrief] ?? '';
    setCurrentInput(String(rawValue));
    setBrief(prev => {
      const next = { ...prev };
      delete next[lastEntry.question.id as keyof ProjectBrief];
      return next;
    });
    setIsReview(false);
  };

  const handleBackNavigation = () => {
    if (answered.length === 0) onBack();
    else handleBack();
  };

  const handleEditFromReview = (questionId: string) => {
    const qIdx = getQuestionIndexById(questionId as keyof ProjectBrief);
    if (qIdx === -1) return;
    const targetIdx = answered.findIndex(e => e.question.id === questionId);
    if (targetIdx === -1) return;
    const entryToEdit = answered[targetIdx];
    setAnswered(prev => prev.slice(0, targetIdx));
    setBrief(prev => {
      const next = { ...prev };
      for (let i = qIdx; i < allQuestions.length; i++) delete next[allQuestions[i].id as keyof ProjectBrief];
      return next;
    });
    const rawValue = brief[entryToEdit.question.id as keyof ProjectBrief] ?? '';
    setCurrentInput(String(rawValue));
    setIsReview(false);
  };

  const handleNext = () => {
    if (!currentQuestion) return;
    const val = currentInput.trim();
    if (currentQuestion.required && !val && currentQuestion.type !== 'select' && currentQuestion.type !== 'color-swatches') {
      setValidationError(`${currentQuestion.label} is required`);
      return;
    }
    if (currentQuestion.required && !currentInput && (currentQuestion.type === 'select' || currentQuestion.type === 'color-swatches')) {
      setValidationError(`Please select a ${currentQuestion.label.toLowerCase()}`);
      return;
    }
    setValidationError('');
    let answerValue: string;
    if (currentQuestion.type === 'color-swatches' && currentQuestion.multi) answerValue = currentInput || '';
    else if (currentQuestion.type === 'color-swatches') answerValue = currentInput || (currentQuestion.id === 'shirtColor' ? (currentInput || '#1a1a1a') : '');
    else if (currentQuestion.type === 'image-upload') answerValue = currentInput || '';
    else if (currentQuestion.id === 'productType') answerValue = currentInput || 'T-Shirt';
    else if (currentQuestion.id === 'preferredColors') answerValue = currentInput || '';
    else if (currentQuestion.id === 'shirtColor') answerValue = currentInput || '#1a1a1a';
    else answerValue = val;

    const newBrief = { ...brief, [currentQuestion.id]: answerValue };
    setBrief(newBrief);
    const displayAnswer = currentQuestion.id === 'shirtColor'
      ? (SHIRT_COLORS.find(c => c.hex.trim() === (newBrief.shirtColor || '').trim())?.name || newBrief.shirtColor || '')
      : currentQuestion.id === 'preferredColors' && currentInput
        ? currentInput.split(',').map(h => { const c = DESIGN_COLORS.find(d => d.hex.trim() === h.trim()); return c ? c.name : h; }).join(', ')
        : currentQuestion.id === 'referenceImageUrl' && currentInput ? '(uploaded)' : (val || '(skipped)');
    setAnswered(prev => [...prev, { question: currentQuestion, answer: displayAnswer }]);
    setCurrentInput('');
    const nextQ = getNextQuestion(newBrief);
    if (!nextQ) setIsReview(true);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (validationError) setValidationError('');
    if (e.key === 'Enter' && !e.shiftKey) {
      if (currentQuestion?.type === 'textarea') return;
      e.preventDefault();
      handleNext();
    }
  };

  const handleFreeGenerate = () => onGenerate(brief as ProjectBrief, 'free');
  const handlePremiumGenerate = () => onGenerate(brief as ProjectBrief, 'premium');

  const renderInput = (q: InterviewQuestion) => {
    switch (q.type) {
      case 'text':
        return (
          <div className="w-full">
            <input
              type="text"
              value={currentInput}
              onChange={e => setCurrentInput(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full bg-[#0d0d0d] border border-[#2a2a2a] rounded-xl px-4 py-3.5 text-[15px] text-white placeholder-[#505050] focus:outline-none focus:border-[#D4AF37]/50 focus:ring-1 focus:ring-[#D4AF37]/20 transition-all"
              placeholder={q.placeholder}
              autoFocus
            />
          </div>
        );
      case 'textarea':
        return (
          <div className="w-full">
            <textarea
              value={currentInput}
              onChange={e => setCurrentInput(e.target.value)}
              className="w-full bg-[#0d0d0d] border border-[#2a2a2a] rounded-xl px-4 py-3.5 text-[15px] text-white placeholder-[#505050] min-h-[110px] resize-none focus:outline-none focus:border-[#D4AF37]/50 focus:ring-1 focus:ring-[#D4AF37]/20 transition-all"
              placeholder={q.placeholder}
              autoFocus
            />
            {q.id === 'notes' && (
              <p className="text-[#5a5a5a] text-[11px] mt-2 italic leading-relaxed">
                Get creative — "An elephant dancing in front of the moon." The weirder, the better.
              </p>
            )}
          </div>
        );
      case 'select':
        return (
          <div className="grid grid-cols-1 xs:grid-cols-3 gap-2 w-full">
            {q.options?.map(opt => (
              <button
                key={opt.value}
                type="button"
                onClick={() => { setCurrentInput(opt.value); setValidationError(''); }}
                className={`px-4 py-3 rounded-xl border font-condensed text-[13px] font-bold tracking-wider uppercase transition-all text-left flex items-center justify-between
                  ${currentInput === opt.value ? 'border-[#D4AF37] bg-[#D4AF37]/10 text-[#D4AF37] shadow-[0_0_15px_rgba(212,175,55,0.15)]' : 'border-[#2a2a2a] bg-[#0d0d0d] text-[#8a8a8a] hover:border-[#3a3a3a] hover:text-white'}`}
              >
                {opt.label}
                {currentInput === opt.value && <span className="w-2 h-2 rounded-full bg-[#D4AF37] shadow-[0_0_6px_rgba(212,175,55,0.6)]" />}
              </button>
            ))}
          </div>
        );
      case 'color-swatches':
        if (q.multi) {
          const selectedHexes = currentInput ? currentInput.split(',').map(s => s.trim()) : [];
          return (
            <div className="w-full">
              <p className="text-[#5a5a5a] text-[11px] mb-3 font-mono uppercase tracking-wider">Tap to select up to 3 • {selectedHexes.length}/3</p>
              <div className="grid grid-cols-4 xs:grid-cols-5 sm:grid-cols-7 gap-2.5">
                {q.colors?.map(color => {
                  const isSelected = selectedHexes.includes(color.hex);
                  const isDisabled = selectedHexes.length >= 3 && !isSelected;
                  return (
                    <button
                      key={color.hex}
                      type="button"
                      disabled={isDisabled}
                      onClick={() => {
                        let next: string[];
                        if (isSelected) next = selectedHexes.filter(h => h !== color.hex);
                        else if (selectedHexes.length < 3) next = [...selectedHexes, color.hex];
                        else return;
                        setCurrentInput(next.join(', '));
                        setValidationError('');
                      }}
                      className={`relative aspect-square rounded-[12px] border-2 transition-all duration-200 flex items-center justify-center group
                        ${isSelected ? 'border-[#D4AF37] scale-[1.06] shadow-[0_0_0_2px_rgba(212,175,55,0.2),0_4px_15px_rgba(0,0,0,0.3)]' : 'border-[#2a2a2a] hover:border-[#3a3a3a] hover:scale-[1.03]'}
                        ${isDisabled ? 'opacity-35 cursor-not-allowed' : ''}`}
                      style={{ backgroundColor: color.hex }}
                    >
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-white/90 text-black flex items-center justify-center shadow">
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 13l4 4L19 7" /></svg>
                        </div>
                      )}
                      <span className="absolute -bottom-5 text-[8px] font-bold tracking-wider uppercase text-[#5a5a5a] group-hover:text-[#8a8a8a] whitespace-nowrap md:opacity-0 md:group-hover:opacity-100 transition-opacity hidden sm:block">{color.name}</span>
                    </button>
                  );
                })}
              </div>
              {selectedHexes.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-6">
                  {selectedHexes.map(h => {
                    const c = DESIGN_COLORS.find(d => d.hex === h);
                    return (
                      <span key={h} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[11px] text-white font-mono">
                        <span className="w-3 h-3 rounded-full border border-white/20" style={{ backgroundColor: h }} />
                        {c?.name || h}
                      </span>
                    );
                  })}
                </div>
              )}
            </div>
          );
        }
        return (
          <div className="grid grid-cols-3 xs:grid-cols-4 sm:grid-cols-6 gap-2.5 w-full">
            {q.colors?.map(color => (
              <button
                key={color.hex}
                type="button"
                onClick={() => { setCurrentInput(color.hex); setValidationError(''); }}
                className={`relative aspect-square rounded-[12px] border-2 transition-all duration-200 flex items-center justify-center
                  ${currentInput === color.hex ? 'border-[#D4AF37] scale-[1.06] shadow-[0_0_0_2px_rgba(212,175,55,0.2),0_4px_15px_rgba(0,0,0,0.3)]' : 'border-[#2a2a2a] hover:border-[#3a3a3a] hover:scale-[1.03]'}`}
                style={{ backgroundColor: color.hex }}
                title={color.name}
              >
                {currentInput === color.hex && (
                  <div className="w-6 h-6 rounded-full bg-white text-black flex items-center justify-center shadow-lg">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 13l4 4L19 7" /></svg>
                  </div>
                )}
                <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[8px] font-bold tracking-wider uppercase text-[#5a5a5a] whitespace-nowrap opacity-0 group-hover:opacity-100 hidden sm:block">{color.name}</span>
              </button>
            ))}
          </div>
        );
      case 'image-upload': {
        const hasImage = !!currentInput;
        return (
          <div className="w-full">
            {hasImage ? (
              <div className="relative rounded-xl overflow-hidden border border-[#2a2a2a] bg-[#0d0d0d] p-3">
                <img src={currentInput} alt="Uploaded" className="max-h-44 w-full object-contain rounded-lg" />
                <button
                  type="button"
                  onClick={() => { setCurrentInput(''); setValidationError(''); }}
                  className="absolute top-4 right-4 w-8 h-8 rounded-full bg-red-500/90 text-white flex items-center justify-center hover:bg-red-500 transition-colors shadow-lg"
                >✕</button>
                <div className="mt-3 flex gap-2">
                  <label className="flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-lg bg-[#1a1a1a] border border-[#2a2a2a] text-[11px] font-bold tracking-wider uppercase text-[#8a8a8a] cursor-pointer hover:text-white hover:border-[#3a3a3a] transition-all">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>
                    Replace
                    <input type="file" accept="image/png,image/jpeg,image/svg+xml" className="sr-only" onChange={(e) => {
                      const file = e.target.files?.[0]; if (!file) return;
                      const reader = new FileReader(); reader.onload = (ev) => { setCurrentInput(ev.target?.result as string); setValidationError(''); }; reader.readAsDataURL(file);
                    }} />
                  </label>
                </div>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-36 md:h-44 border-2 border-dashed border-[#2a2a2a] rounded-xl cursor-pointer hover:border-[#D4AF37]/40 hover:bg-[#D4AF37]/[0.03] transition-all group bg-[#0d0d0d]">
                <div className="flex flex-col items-center gap-2 text-[#5a5a5a] group-hover:text-[#8a8a8a] transition-colors">
                  <div className="w-10 h-10 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center group-hover:border-[#D4AF37]/30">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="3" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" /></svg>
                  </div>
                  <span className="font-condensed text-[12px] font-bold tracking-[0.15em] uppercase">Upload reference</span>
                  <span className="text-[10px] font-mono">PNG, JPG, SVG • max 5MB</span>
                </div>
                <input type="file" accept="image/png,image/jpeg,image/svg+xml" className="sr-only" onChange={(e) => {
                  const file = e.target.files?.[0]; if (!file) return;
                  const reader = new FileReader(); reader.onload = (ev) => { setCurrentInput(ev.target?.result as string); setValidationError(''); }; reader.readAsDataURL(file);
                }} />
              </label>
            )}
          </div>
        );
      }
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0d0d] flex flex-col">
      {/* Header — 320px safe */}
      <div className="border-b border-[#1e1e1e] bg-[#111111] sticky top-0 z-20">
        <div className="max-w-[840px] mx-auto px-4 md:px-6 py-3.5 flex items-center gap-3">
          <button onClick={handleBackNavigation} className="w-9 h-9 flex items-center justify-center rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white hover:border-[#3a3a3a] shrink-0">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="font-condensed text-[14px] font-black tracking-[0.18em] text-white uppercase leading-none">Interview</h1>
            <p className="font-mono text-[10px] text-[#5a5a5a] tracking-wider uppercase mt-1">Step {Math.min(questionIndex + 1, total)} of {total} • {brief.name || 'New project'}</p>
          </div>
          <div className="w-[88px] md:w-32 h-1.5 bg-[#1a1a1a] rounded-full overflow-hidden border border-[#1e1e1e] shrink-0">
            <div className="h-full bg-[#D4AF37] rounded-full transition-all duration-700 shadow-[0_0_8px_rgba(212,175,55,0.4)]" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </div>

      {/* Body — fluid 320px+ */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto">
        <div className="max-w-[840px] mx-auto px-4 md:px-6 py-5 md:py-8 space-y-4 md:space-y-5">
          {/* Answered — collapsible compact for mobile */}
          {answered.map((entry, i) => (
            <div key={i} className="bg-[#111111] border border-[#1e1e1e] rounded-xl px-4 py-3 flex items-start justify-between gap-3 opacity-80">
              <div className="min-w-0">
                <p className="font-condensed text-[10px] font-black tracking-[0.16em] text-[#D4AF37] uppercase">{entry.question.label}</p>
                <p className="font-body text-[13px] text-[#c8c8c8] mt-1 leading-snug truncate md:whitespace-normal">{entry.answer}</p>
              </div>
              <span className="w-1.5 h-1.5 rounded-full bg-green-500/60 mt-1.5 shrink-0" />
            </div>
          ))}

          {/* Current */}
          {!isReview && currentQuestion && (
            <div className="bg-[#111111] border border-[#D4AF37]/20 rounded-[16px] p-4 md:p-7 shadow-[0_8px_40px_rgba(0,0,0,0.4),0_0_0_1px_rgba(212,175,55,0.08)_inset]">
              <div className="flex items-start justify-between gap-3 mb-4">
                <div>
                  <p className="font-condensed text-[11px] font-black tracking-[0.20em] text-[#D4AF37] uppercase flex items-center gap-2">
                    <span className="w-[2px] h-[12px] bg-[#D4AF37] rounded-full" />
                    {currentQuestion.label}
                    {currentQuestion.required && <span className="px-1.5 py-0.5 rounded bg-red-500/15 border border-red-500/20 text-red-400 text-[8px] leading-none">REQUIRED</span>}
                  </p>
                  <p className="font-body text-[17px] md:text-[20px] font-medium text-white leading-[1.2] mt-2 tracking-tight">{currentQuestion.prompt}</p>
                </div>
                <span className="hidden md:block text-[10px] font-mono text-[#3a3a3a] border border-[#1e1e1e] rounded-full px-2 py-1 bg-[#0d0d0d]">{questionIndex + 1} / {total}</span>
              </div>
              {renderInput(currentQuestion)}
              {validationError && <p className="text-red-400 text-[12px] font-body mt-3 flex items-center gap-1.5"><span className="w-4 h-4 rounded-full bg-red-500/15 flex items-center justify-center text-[10px]">!</span>{validationError}</p>}
              <div className="flex gap-2 md:gap-3 mt-5">
                {answered.length > 0 && (
                  <button onClick={handleBack} className="px-4 py-3 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] text-[11px] font-condensed font-bold tracking-[0.15em] uppercase text-[#737373] hover:text-white hover:border-[#3a3a3a] shrink-0">
                    Back
                  </button>
                )}
                <button
                  onClick={handleNext}
                  disabled={!!(currentQuestion.required && !currentInput.trim() && currentQuestion.type !== 'select' && currentQuestion.type !== 'color-swatches')}
                  className="flex-1 bg-[#D4AF37] text-black py-3 rounded-xl font-condensed font-black text-[13px] tracking-[0.15em] uppercase hover:bg-[#E8CC6E] active:scale-[0.98] transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-[0_0_20px_rgba(212,175,55,0.15)]"
                >
                  {getNextQuestion({ ...brief, [currentQuestion.id]: currentInput || '___' }) ? 'Next →' : 'Review →'}
                </button>
                {!currentQuestion.required && (
                  <button onClick={() => {
                    setValidationError('');
                    setBrief(prev => ({ ...prev, [currentQuestion.id]: '' }));
                    setAnswered(prev => [...prev, { question: currentQuestion, answer: '(skipped)' }]);
                    setCurrentInput('');
                    const nextQ = getNextQuestion({ ...brief, [currentQuestion.id]: '' });
                    if (!nextQ) setIsReview(true);
                  }} className="px-4 py-3 rounded-xl border border-[#1e1e1e] text-[11px] font-condensed font-bold tracking-widest uppercase text-[#505050] hover:text-[#8a8a8a] shrink-0">
                    Skip
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Review */}
          {isReview && (
            <div className="bg-[#111111] border border-[#D4AF37]/25 rounded-[16px] p-4 md:p-7 space-y-1">
              <div className="text-center mb-6">
                <div className="w-10 h-10 mx-auto rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center mb-3">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#D4AF37" strokeWidth="2"><path d="M5 13l4 4L19 7" /></svg>
                </div>
                <h2 className="font-condensed text-[20px] md:text-[24px] font-black tracking-[0.08em] text-white uppercase">Review Your Brief</h2>
                <p className="text-[#5a5a5a] text-[12px] mt-1.5">Tap any item to edit • Everything looks good?</p>
              </div>
              <div className="divide-y divide-[#1e1e1e] rounded-xl overflow-hidden border border-[#1e1e1e]">
                {answered.map((entry, i) => (
                  <button key={i} type="button" onClick={() => handleEditFromReview(entry.question.id)} className="w-full flex items-start justify-between gap-3 py-3.5 px-4 bg-[#0d0d0d] hover:bg-[#151515] text-left group transition-colors">
                    <span className="font-condensed text-[10px] font-black tracking-[0.14em] text-[#D4AF37] uppercase pt-0.5 shrink-0">{entry.question.label}</span>
                    {entry.question.id === 'referenceImageUrl' && brief.referenceImageUrl ? (
                      <img src={brief.referenceImageUrl} alt="ref" className="max-h-16 rounded-lg border border-[#1e1e1e] ml-2" />
                    ) : (
                      <span className="font-body text-[13px] text-[#c8c8c8] text-right max-w-[60%] flex items-center gap-2 justify-end leading-snug">
                        <span className="truncate">{entry.answer}</span>
                        <svg className="w-3 h-3 text-[#3a3a3a] group-hover:text-[#8a8a8a] shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z" /></svg>
                      </span>
                    )}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 pt-5">
                <button onClick={handleFreeGenerate} disabled={isGenerating} className="order-2 md:order-1 relative bg-[#1a1a1a] border border-[#2a2a2a] text-white py-4 rounded-xl font-condensed font-black text-[12px] tracking-[0.15em] uppercase hover:border-[#3a3a3a] hover:bg-[#202020] transition-all disabled:opacity-50">
                  {isGenerating ? <span className="flex items-center justify-center gap-2"><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />Free...</span> : <><span>FREE GENERATE</span><span className="block font-mono text-[10px] font-normal normal-case text-[#5a5a5a] mt-0.5 tracking-normal">4 • watermarked</span></>}
                </button>
                <button onClick={handlePremiumGenerate} disabled={isGenerating} className="order-1 md:order-2 md:col-span-1 relative bg-[#D4AF37] text-black py-4 rounded-xl font-condensed font-black text-[13px] tracking-[0.14em] uppercase hover:bg-[#E8CC6E] transition-all shadow-[0_0_30px_rgba(212,175,55,0.2)] disabled:opacity-50">
                  {isGenerating ? <span className="flex items-center justify-center gap-2"><span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />Premium...</span> : <><span>PREMIUM GENERATE</span><span className="block font-mono text-[10px] font-bold normal-case text-black/60 mt-0.5 tracking-normal">4 • 1 credit • clean</span></>}
                  <span className="absolute -top-2 -right-2 px-1.5 py-0.5 rounded-full bg-white text-black text-[8px] font-black tracking-wider border border-[#D4AF37] shadow">POPULAR</span>
                </button>
                <button onClick={() => { setIsReview(false); setBrief({}); setAnswered([]); setCurrentInput(''); setValidationError(''); }} className="order-3 border border-[#1e1e1e] text-[#505050] py-4 rounded-xl font-condensed font-bold text-[11px] tracking-widest uppercase hover:text-[#8a8a8a] hover:border-[#2a2a2a]">Start Over</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
