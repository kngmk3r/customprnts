import { useState } from 'react';
import type { Project } from '../storage';
import { exportDesignFromDataURL, exportProjectJSON } from '../exportService';
import MockupRenderer from '../editor/components/MockupRenderer';
import { getProductById, getViewpoint } from '../editor/data/productLibrary';
import OverlayLayer from '../editor/components/OverlayLayer';
import type { OverlayConfig } from '../editor/overlaySystem';

/* ─── Toast helper ─── */
function showToast(message: string) {
// ...
  const toast = document.createElement('div');
  toast.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;padding:12px 20px;border-radius:8px;font-family:"Barlow Condensed",sans-serif;font-size:14px;font-weight:600;letter-spacing:0.05em;text-transform:uppercase;color:#FAFAFA;background:#1a1a1a;border:1px solid #D4AF37;box-shadow:0 4px 20px rgba(0,0,0,0.4);opacity:0;transform:translateY(10px);transition:all 0.3s ease;pointer-events:auto;';
  toast.textContent = message;
  document.body.appendChild(toast);
  requestAnimationFrame(() => { toast.style.opacity = '1'; toast.style.transform = 'translateY(0)'; });
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

interface Props {
  project: Project;
  onSave: (project: Project) => void;
  onBackToPreview: () => void;
  onBackToProjects: () => void;
  /** Non-destructive overlays — rendered above the mockup */
  overlays?: OverlayConfig[];
}

export default function ProducePage({ project, onSave, onBackToPreview, onBackToProjects, overlays = [] }: Props) {
  const [shirtColor, setShirtColor] = useState(project.shirtColor || '#1a1a1a');
  const product = getProductById(project.productId || 'adult-tshirt');
  const productColors = product?.colors || [];
  const [designSize, setDesignSize] = useState(project.placement?.size || 100);
  const [verticalOffset, setVerticalOffset] = useState(project.placement?.verticalOffset || 0);
  const [selectedChoice, setSelectedChoice] = useState<'order' | 'download' | 'save' | null>(null);
  const [orderType, setOrderType] = useState<'pickup' | 'delivery' | null>(null);

  const handleSavePlacement = () => {
    onSave({
      ...project,
      shirtColor,
      placement: { size: designSize, verticalOffset },
      updatedAt: new Date().toISOString(),
    });
  };

  return (
    <div className="min-h-screen bg-studio-surface">
      {/* Header */}
      <div className="border-b border-studio-border bg-studio-surface sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center gap-3">
          <button onClick={onBackToPreview} className="studio-btn-ghost !px-3">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M15 18l-6-6 6-6" />
            </svg>
            Back to Preview
          </button>
          <span className="text-studio-muted">|</span>
          <button onClick={onBackToProjects} className="studio-btn-ghost !px-3 !text-sm">
            Projects
          </button>
          <h1 className="font-condensed text-xl font-bold tracking-wider text-white uppercase ml-2">Produce</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Mockup Display */}
          <div className="flex items-center justify-center p-8">
            {!project.designDataUrl && !project.canvasThumbnail ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-studio-elevated border border-studio-border flex items-center justify-center">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-studio-muted">
                    <rect x="3" y="3" width="18" height="18" rx="2" />
                    <circle cx="8.5" cy="8.5" r="1.5" />
                    <path d="M21 15l-5-5L5 21" />
                  </svg>
                </div>
                <p className="text-studio-muted text-sm font-condensed uppercase tracking-wider">No design to produce</p>
                <button onClick={onBackToPreview} className="studio-btn-ghost mt-4 !text-sm">← Back to Preview</button>
              </div>
            ) : (
            <div className="relative w-full max-w-lg">
              <MockupRenderer
                productTemplate={{
                  id: product.id,
                  name: product.name,
                  category: product.categoryId,
                  subcategory: product.subcategory,
                  views: product.viewpoints as any,
                  colors: product.colors,
                  baseImageUrl: product.baseImageUrl,
                  maskUrl: product.maskUrl,
                  supportedPrintMethods: product.supportedPrintMethods
                }}
                viewId={project.viewId || 'front'}
                productColor={shirtColor}
                artworkDataUrl={project.canvasThumbnail}
                placementX={0.5 + (project.placement?.horizontalOffsetInches || 0) / (getViewpoint(product, project.viewId || 'front')?.physicalPrintArea.maxWidthInches || 12)}
                placementY={0.3 + (project.placement?.topOffsetInches || 0) / (getViewpoint(product, project.viewId || 'front')?.physicalPrintArea.maxHeightInches || 14)}
                placementWidth={(project.placement?.widthInches || 10) / (getViewpoint(product, project.viewId || 'front')?.physicalPrintArea.maxWidthInches || 12)}
                baseImageUrl={product.baseImageUrl}
                maskUrl={product.maskUrl}
              />
              <OverlayLayer overlays={overlays} />
            </div>
            )}
          </div>

          {/* Controls & Choices */}
          <div className="space-y-6">
            {/* Shirt Color */}
            <div>
              <label className="studio-label">Base Color</label>
              <div className="flex flex-wrap gap-3">
                {productColors.map(color => (
                  <button
                    key={color.id}
                    onClick={() => setShirtColor(color.hex)}
                    aria-label={`Select ${color.name} color`}
                    className={`w-14 h-14 rounded-lg border-2 transition-all flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-studio-gold focus:ring-offset-2 focus:ring-offset-studio-surface ${
                      shirtColor === color.hex
                        ? 'border-studio-gold scale-110'
                        : 'border-studio-border hover:border-studio-gold/50'
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  >
                    {shirtColor === color.hex && (
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3">
                        <path d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Design Size */}
            <div>
              <label className="studio-label">Design Size: {designSize}%</label>
              <input
                type="range"
                min="30"
                max="150"
                value={designSize}
                onChange={e => setDesignSize(Number(e.target.value))}
                className="studio-range w-full"
              />
            </div>

            {/* Vertical Placement */}
            <div>
              <label className="studio-label">Vertical Placement: {verticalOffset > 0 ? '+' : ''}{verticalOffset}%</label>
              <input
                type="range"
                min="-15"
                max="15"
                value={verticalOffset}
                onChange={e => setVerticalOffset(Number(e.target.value))}
                className="studio-range w-full"
              />
            </div>

            <button onClick={handleSavePlacement} className="studio-btn-ghost w-full !text-sm">
              Save Placement
            </button>

            <div className="border-t border-studio-border pt-6">
              <h3 className="font-condensed text-sm font-bold tracking-[0.2em] text-studio-gold uppercase mb-4">How would you like to produce?</h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Order Print */}
                <button
                  onClick={() => setSelectedChoice(selectedChoice === 'order' ? null : 'order')}
                  aria-label="Order Print"
                  className={`p-5 rounded-lg border text-center transition-all focus:outline-none focus:ring-2 focus:ring-studio-gold focus:ring-offset-2 focus:ring-offset-studio-surface ${
                    selectedChoice === 'order'
                      ? 'border-studio-gold bg-studio-gold/10 shadow-[0_0_20px_rgba(212,175,55,0.1)]'
                      : 'border-studio-border hover:border-studio-gold/30'
                  }`}
                >
                  <div className="text-3xl mb-2">🖨️</div>
                  <p className="font-condensed text-sm font-bold tracking-wider text-white uppercase">Order Print</p>
                  <p className="font-body text-xs text-studio-muted mt-1">Pickup or delivery</p>
                </button>

                {/* Download Files */}
                <button
                  onClick={() => setSelectedChoice(selectedChoice === 'download' ? null : 'download')}
                  aria-label="Download Files"
                  className={`p-5 rounded-lg border text-center transition-all focus:outline-none focus:ring-2 focus:ring-studio-gold focus:ring-offset-2 focus:ring-offset-studio-surface ${
                    selectedChoice === 'download'
                      ? 'border-studio-gold bg-studio-gold/10 shadow-[0_0_20px_rgba(212,175,55,0.1)]'
                      : 'border-studio-border hover:border-studio-gold/30'
                  }`}
                >
                  <div className="text-3xl mb-2">📦</div>
                  <p className="font-condensed text-sm font-bold tracking-wider text-white uppercase">Download</p>
                  <p className="font-body text-xs text-studio-muted mt-1">PNG & JSON files</p>
                </button>

                {/* Save Project */}
                <button
                  onClick={() => setSelectedChoice(selectedChoice === 'save' ? null : 'save')}
                  aria-label="Save Project"
                  className={`p-5 rounded-lg border text-center transition-all focus:outline-none focus:ring-2 focus:ring-studio-gold focus:ring-offset-2 focus:ring-offset-studio-surface ${
                    selectedChoice === 'save'
                      ? 'border-studio-gold bg-studio-gold/10 shadow-[0_0_20px_rgba(212,175,55,0.1)]'
                      : 'border-studio-border hover:border-studio-gold/30'
                  }`}
                >
                  <div className="text-3xl mb-2">💾</div>
                  <p className="font-condensed text-sm font-bold tracking-wider text-white uppercase">Save Project</p>
                  <p className="font-body text-xs text-studio-muted mt-1">Browser storage</p>
                </button>
              </div>

              {/* Expanded choices */}
              {selectedChoice === 'order' && (
                <div className="mt-4 p-4 bg-studio-elevated border border-studio-border rounded-lg space-y-3">
                  <div className="flex gap-3">
                    <button
                      onClick={() => setOrderType('pickup')}
                      className={`flex-1 p-3 rounded border text-center transition-all ${
                        orderType === 'pickup'
                          ? 'border-studio-gold bg-studio-gold/10'
                          : 'border-studio-border hover:border-studio-gold/30'
                      }`}
                    >
                      <p className="font-condensed text-sm font-bold text-white">🏪 Pickup</p>
                      <p className="font-body text-xs text-studio-muted">Ready in 3 hours</p>
                    </button>
                    <button
                      onClick={() => setOrderType('delivery')}
                      className={`flex-1 p-3 rounded border text-center transition-all ${
                        orderType === 'delivery'
                          ? 'border-studio-gold bg-studio-gold/10'
                          : 'border-studio-border hover:border-studio-gold/30'
                      }`}
                    >
                      <p className="font-condensed text-sm font-bold text-white">🚚 Delivery</p>
                      <p className="font-body text-xs text-studio-muted">2-5 business days</p>
                    </button>
                  </div>
                  <button
                    className="studio-btn-primary w-full"
                    disabled={!orderType}
                    onClick={() => {
                      handleSavePlacement();
                      showToast('Order submitted — fulfillment coming soon');
                      onBackToProjects();
                    }}
                  >
                    {orderType === 'pickup' ? 'Order for Pickup' : orderType === 'delivery' ? 'Order for Delivery' : 'Select pickup or delivery'}
                  </button>
                </div>
              )}

              {selectedChoice === 'download' && (
                <div className="mt-4 p-4 bg-studio-elevated border border-studio-border rounded-lg space-y-2">
                  <button
                    onClick={() => exportDesignFromDataURL(project.designDataUrl, project.brief.name, 'transparent')}
                    className="studio-btn-secondary w-full !text-sm"
                    aria-label="Export Transparent PNG"
                  >
                    Transparent PNG
                  </button>
                  <button
                    onClick={() => exportDesignFromDataURL(project.designDataUrl, project.brief.name, 'with-bg')}
                    className="studio-btn-secondary w-full !text-sm"
                    aria-label="Export PNG with Background"
                  >
                    PNG with Background
                  </button>
                  <button
                    onClick={() => exportProjectJSON(project)}
                    className="studio-btn-secondary w-full !text-sm"
                    aria-label="Download Project JSON"
                  >
                    Project JSON
                  </button>
                </div>
              )}

              {selectedChoice === 'save' && (
                <div className="mt-4 p-4 bg-studio-elevated border border-studio-border rounded-lg text-center">
                  <p className="font-body text-sm text-white mb-3">
                    Your project is saved in browser storage and will persist until you clear your browser data.
                  </p>
                  <button onClick={() => { handleSavePlacement(); onBackToProjects(); }} className="studio-btn-primary w-full">
                    Save & Return to Projects
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
