import { useState, useCallback, useEffect } from 'react';
import type { Concept } from '../conceptGenerator';
import type { GenerationError } from '../conceptGenerator';
import type { ProjectBrief } from '../storage';
import { loadRegenState, saveRegenState } from '../storage';
import { getDesignHistory, addToLocker, type HistoryBatch } from '../conceptGenerator';
import OverlayLayer from '../editor/components/OverlayLayer';
import type { OverlayConfig } from '../editor/overlaySystem';

const MAX_REGENERATIONS = 3;
const COOLDOWN_MINUTES = 5;
const COOLDOWN_MS = COOLDOWN_MINUTES * 60 * 1000;

interface Props {
  concepts: Concept[];
  onSelect: (conceptId: string) => void;
  onRegenerate: (index: number) => void;
  onRetry: (tier?: 'free' | 'premium') => void;
  onRetryWorkspace: () => void;
  sessionFailed: boolean;
  onBackToInterview: () => void;
  onBackToProjects: () => void;
  onOpenLocker: () => void;
  brief: ProjectBrief;
  projectId: string | null;
  regeneratingIndex: number | null;
  generationError: GenerationError | null;
  lastTier?: 'free' | 'premium' | null;
  overlays?: OverlayConfig[];
}

function ConceptImage({ concept, overlays }: { concept: Concept; overlays?: OverlayConfig[] }) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  return (
    <div className="w-full h-full bg-[#111111] flex items-center justify-center relative">
      {!loaded && !error && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
        </div>
      )}
      {error ? (
        <div className="text-center p-4">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="1.5" className="mx-auto mb-2">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
            <circle cx="8.5" cy="8.5" r="1.5" />
            <polyline points="21 15 16 10 5 21" />
          </svg>
          <p className="text-[#5a5a5a] text-xs">Image unavailable</p>
        </div>
      ) : (
        <>
          <img
            src={concept.imageUrl}
            alt={concept.name}
            className={`w-full h-full object-contain transition-opacity duration-300 ${loaded ? 'opacity-100' : 'opacity-0'}`}
            onLoad={() => setLoaded(true)}
            onError={() => setError(true)}
            draggable={false}
          />
          <OverlayLayer overlays={overlays || []} />
        </>
      )}
    </div>
  );
}

export default function ConceptSelectionPage({
  concepts, onSelect, onRegenerate, onRetry, onRetryWorkspace,
  sessionFailed, onBackToInterview, onBackToProjects, onOpenLocker,
  brief, projectId, regeneratingIndex, generationError, lastTier, overlays = [],
}: Props) {
  const [regenCount, setRegenCount] = useState(() => loadRegenState().regenCount);
  const [cooldownEnd, setCooldownEnd] = useState<number | null>(() => loadRegenState().cooldownEnd);
  const [countdown, setCountdown] = useState(0);
  const [historyBatches, setHistoryBatches] = useState<HistoryBatch[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historyLoaded, setHistoryLoaded] = useState(false);
  const [lockedIds, setLockedIds] = useState<Set<string>>(new Set());
  const [discardedIds, setDiscardedIds] = useState<Set<string>>(new Set());
  const [lockingId, setLockingId] = useState<string | null>(null);

  useEffect(() => { saveRegenState({ regenCount, cooldownEnd }); }, [regenCount, cooldownEnd]);
  const isInCooldown = cooldownEnd !== null && Date.now() < cooldownEnd;
  const remainingBeforeLimit = Math.max(0, MAX_REGENERATIONS - regenCount);

  useEffect(() => {
    if (!cooldownEnd) return;
    const tick = () => {
      const remaining = Math.max(0, Math.ceil((cooldownEnd - Date.now()) / 1000));
      setCountdown(remaining);
      if (remaining <= 0) { setCooldownEnd(null); setRegenCount(0); }
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [cooldownEnd]);

  const formatCountdown = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const handleRegenerate = useCallback((index: number) => {
    if (isInCooldown || regeneratingIndex !== null) return;
    const newCount = regenCount + 1;
    if (newCount >= MAX_REGENERATIONS) {
      setRegenCount(0);
      setCooldownEnd(Date.now() + COOLDOWN_MS);
    } else {
      setRegenCount(newCount);
    }
    onRegenerate(index);
  }, [isInCooldown, regenCount, regeneratingIndex, onRegenerate]);

  const loadHistory = useCallback(async () => {
    if (!projectId || historyLoaded) return;
    const batches = await getDesignHistory(projectId);
    const filtered = batches.length > 1 ? batches.slice(1) : [];
    setHistoryBatches(filtered);
    setHistoryLoaded(true);
  }, [projectId, historyLoaded]);

  const handleKeepInLocker = useCallback(async (concept: Concept) => {
    if (!projectId || lockedIds.has(concept.id)) return;
    setLockingId(concept.id);
    const result = await addToLocker({
      designId: concept.id,
      projectId,
      imageUrl: concept.imageUrl,
      storageKey: concept.storageKey,
      prompt: brief.description,
      productType: brief.productType,
      conceptName: concept.name,
    });
    if (result.success) setLockedIds(prev => new Set(prev).add(concept.id));
    setLockingId(null);
  }, [projectId, lockedIds, brief]);

  const handleDiscard = useCallback((conceptId: string) => {
    setDiscardedIds(prev => new Set(prev).add(conceptId));
  }, []);

  const visibleConcepts = concepts.filter(c => !discardedIds.has(c.id));
  const inferredLastTier = lastTier || (concepts[0] as any)?.meta?.tier || 'free';

  return (
    <div className="min-h-screen bg-[#0d0d0d]">
      {/* Header - 320px safe */}
      <div className="border-b border-[#1e1e1e] bg-[#111111] sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-3.5 flex flex-wrap items-center gap-2 md:gap-4">
          <div className="flex items-center gap-1.5">
            <button onClick={onBackToInterview} className="w-8 h-8 md:w-auto md:px-3 flex items-center justify-center rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#8a8a8a] hover:text-white text-[11px] font-bold uppercase tracking-wider">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="md:mr-1"><path d="M15 18l-6-6 6-6" /></svg>
              <span className="hidden md:inline">Edit Brief</span>
            </button>
            <button onClick={onBackToProjects} className="px-2.5 py-1.5 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#5a5a5a] hover:text-white text-[10px] font-bold uppercase tracking-wider">Projects</button>
            <button onClick={onOpenLocker} className="px-2.5 py-1.5 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#5a5a5a] hover:text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><path d="M3 9h18M9 21V9" /></svg>
              Locker
            </button>
          </div>
          <div className="flex-1 min-w-[180px]">
            <h1 className="font-condensed text-[14px] md:text-[16px] font-black tracking-[0.14em] text-white uppercase leading-none">Choose a Concept</h1>
            <p className="font-mono text-[9px] md:text-[10px] text-[#5a5a5a] tracking-wider uppercase mt-1">4 concepts • {inferredLastTier === 'premium' ? 'PREMIUM clean • Ideogram→Recraft→Gemini→OpenAI' : 'FREE watermarked • Runware'} • Select or regen</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-5 md:py-8">
        {generationError && concepts.length === 0 ? (
          <div className="text-center py-10 md:py-20">
            <div className="inline-flex items-center justify-center w-14 h-14 md:w-16 md:h-16 rounded-full bg-red-500/10 border border-red-500/20 mb-5">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" />
              </svg>
            </div>
            <h2 className="text-[18px] md:text-xl font-condensed font-black text-white tracking-[0.12em] uppercase mb-2">Generation Failed</h2>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] mb-3">
              <span className={`w-2 h-2 rounded-full ${inferredLastTier === 'premium' ? 'bg-[#D4AF37]' : 'bg-[#5a5a5a]'}`} />
              <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-[#8a8a8a]">Last attempt: {inferredLastTier.toUpperCase()} • {generationError.code}</span>
            </div>
            <p className="text-[#8a8a8a] mb-2 max-w-md mx-auto text-[13px] leading-relaxed px-4">{generationError.message}</p>
            <p className="text-[#505050] text-[11px] mb-6 md:mb-8 max-w-md mx-auto px-4">Your brief is saved. Retry preserves tier by default, but you can choose. Free is Runware-only; if Runware fails, free is stuck — premium falls back to Gemini → OpenAI.</p>
            
            <div className="flex flex-col sm:flex-row gap-2.5 justify-center items-stretch sm:items-center max-w-[520px] mx-auto px-4">
              {sessionFailed ? (
                <button onClick={onRetryWorkspace} className="flex-1 sm:flex-none bg-[#D4AF37] text-black px-6 py-3 rounded-xl font-condensed font-black text-[12px] tracking-[0.14em] uppercase">
                  Retry Workspace
                </button>
              ) : (
                <>
                  <button onClick={() => onRetry(inferredLastTier as any || 'free')} className="flex-1 bg-[#1a1a1a] border border-[#2a2a2a] text-white px-5 py-3.5 rounded-xl font-condensed font-black text-[11px] tracking-[0.15em] uppercase hover:border-[#3a3a3a] flex flex-col items-center">
                    <span className="flex items-center gap-1.5"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 4v6h6M23 20v-6h-6" /><path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15" /></svg> RETRY {inferredLastTier.toUpperCase()} (SAME)</span>
                    <span className="text-[9px] font-mono font-normal normal-case text-[#5a5a5a] mt-1">{inferredLastTier === 'free' ? 'Runware-only • watermarked' : 'Ideogram→Recraft→Gemini→OpenAI • clean'}</span>
                  </button>
                  <button onClick={() => onRetry(inferredLastTier === 'free' ? 'premium' : 'free')} className="flex-1 bg-[#D4AF37] text-black px-5 py-3.5 rounded-xl font-condensed font-black text-[11px] tracking-[0.15em] uppercase hover:bg-[#E8CC6E] flex flex-col items-center shadow-[0_0_20px_rgba(212,175,55,0.2)]">
                    <span>TRY {inferredLastTier === 'free' ? 'PREMIUM' : 'FREE'} INSTEAD</span>
                    <span className="text-[9px] font-mono font-bold normal-case text-black/60 mt-1">{inferredLastTier === 'free' ? '1 credit • fallback works' : 'Free • $0.0024/batch'}</span>
                  </button>
                </>
              )}
            </div>
            <div className="flex gap-2 justify-center mt-3 px-4">
              <button onClick={onBackToInterview} className="px-4 py-2.5 rounded-full bg-[#1a1a1a] border border-[#1e1e1e] text-[#5a5a5a] hover:text-[#8a8a8a] text-[11px] font-bold uppercase tracking-wider">Edit Brief</button>
              <button onClick={onBackToProjects} className="px-4 py-2.5 rounded-full bg-[#1a1a1a] border border-[#1e1e1e] text-[#5a5a5a] hover:text-[#8a8a8a] text-[11px] font-bold uppercase tracking-wider">Projects</button>
            </div>

            {/* Debug: tier trace */}
            <div className="mt-8 mx-auto max-w-[520px] p-3 rounded-xl bg-[#0d0d0d] border border-[#1e1e1e] text-left">
              <p className="font-mono text-[9px] font-bold tracking-widest uppercase text-[#505050] mb-2">🔍 Premium Tier Trace (for dev)</p>
              <div className="font-mono text-[10px] text-[#5a5a5a] leading-relaxed space-y-1">
                <p>• Last tier attempted: <span className="text-[#8a8a8a] font-bold">{inferredLastTier}</span></p>
                <p>• Retry now sends tier explicitly (bug #1 fixed)</p>
                <p>• Backend chain premium: Runware Ideogram $0.03 → Recraft $0.035 → Gemini 3.1 Flash ~$0.04 → GPT-Image-2 $0.1248</p>
                <p>• Free chain: Runware schnell $0.0006 → Runware p-image $0.00168 → (optional Gemini if enabled) — no OpenAI to avoid burn</p>
                <p>• All batches in DB currently free (0 premium) per your analysis — premium never attempted</p>
              </div>
            </div>
          </div>
        ) : concepts.length === 0 ? (
          <div className="text-center py-16 md:py-20">
            <div className="inline-block w-10 h-10 md:w-12 md:h-12 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin mb-4" />
            <h2 className="text-[16px] md:text-xl font-condensed font-black text-white tracking-[0.14em] uppercase mb-2">Generating {inferredLastTier.toUpperCase()} Concepts</h2>
            <p className="text-[#5a5a5a] mb-6 max-w-md mx-auto text-[13px] px-4">Creating unique designs from your brief. {inferredLastTier === 'premium' ? 'Premium chain: Ideogram → Recraft → Gemini → OpenAI (~12s)' : 'Free: Runware schnell (fast, cheap)'}...</p>
            <button onClick={onBackToProjects} className="px-4 py-2 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#5a5a5a] text-[11px] font-bold uppercase">← Cancel</button>
          </div>
        ) : (
          <>
            {/* Tier badge */}
            <div className="flex items-center gap-2 mb-4 md:mb-6">
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[10px] font-mono font-bold tracking-wider uppercase ${inferredLastTier === 'premium' ? 'bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#D4AF37]' : 'bg-[#1a1a1a] border-[#2a2a2a] text-[#8a8a8a]'}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${inferredLastTier === 'premium' ? 'bg-[#D4AF37] animate-pulse' : 'bg-[#5a5a5a]'}`} />
                {inferredLastTier.toUpperCase()} • {(concepts[0] as any)?.meta?.provider || 'runware'} • {(concepts[0] as any)?.meta?.model || ''}
              </span>
              {concepts[0]?.meta?.costUsd !== undefined && (
                <span className="text-[10px] font-mono text-[#505050]">${(concepts[0].meta as any).costUsd?.toFixed(6) || '0.000'} batch</span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
              {visibleConcepts.map((concept, index) => (
                <div key={concept.id} className="bg-[#111111] border border-[#1e1e1e] rounded-[16px] overflow-hidden hover:border-[#D4AF37]/20 transition-colors shadow-[0_8px_30px_rgba(0,0,0,0.2)]">
                  <div className="aspect-[1/1] bg-[#0d0d0d] relative">
                    <ConceptImage concept={concept} overlays={overlays} />
                    <div className="absolute top-2 left-2 px-2 py-1 rounded-full bg-black/70 border border-white/10 text-[9px] font-mono font-bold text-[#8a8a8a] tracking-wider backdrop-blur-md">
                      {concept.provider || 'runware'} • {index + 1}
                    </div>
                  </div>
                  <div className="p-3.5 md:p-4">
                    <h3 className="font-condensed text-[13px] md:text-[14px] font-black text-white tracking-[0.12em] uppercase mb-3 truncate">{concept.name}</h3>
                    <div className="flex gap-2 items-center mb-2.5">
                      <button onClick={() => onSelect(concept.id)} className="flex-1 bg-[#D4AF37] text-black py-2.5 md:py-3 rounded-xl font-condensed font-black text-[11px] md:text-[12px] tracking-[0.14em] uppercase hover:bg-[#E8CC6E] active:scale-[0.98] shadow-[0_0_15px_rgba(212,175,55,0.15)]">
                        Select Concept
                      </button>
                      <div className="flex flex-col items-center gap-1">
                        <button
                          onClick={() => handleRegenerate(index)}
                          className={`w-9 h-9 md:w-10 md:h-10 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-[#5a5a5a] hover:text-white hover:border-[#3a3a3a] ${regeneratingIndex === index ? 'animate-pulse opacity-50' : ''} ${isInCooldown ? 'opacity-40 cursor-not-allowed' : ''}`}
                          title={isInCooldown ? `Try again in ${formatCountdown(countdown)}` : 'Regenerate'}
                          disabled={regeneratingIndex !== null || isInCooldown}
                        >
                          {regeneratingIndex === index ? (
                            <span className="inline-block w-4 h-4 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 4v6h6M23 20v-6h-6" /><path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15" /></svg>
                          )}
                        </button>
                        {isInCooldown ? (
                          <span className="text-[9px] text-amber-400 font-mono whitespace-nowrap">{formatCountdown(countdown)}</span>
                        ) : remainingBeforeLimit < MAX_REGENERATIONS ? (
                          <span className="text-[9px] text-[#505050] font-condensed whitespace-nowrap">{remainingBeforeLimit} left</span>
                        ) : null}
                      </div>
                    </div>
                    <div className="flex gap-2 items-center">
                      <button
                        onClick={() => handleKeepInLocker(concept)}
                        disabled={lockedIds.has(concept.id) || lockingId === concept.id}
                        className={`flex-1 flex items-center justify-center gap-1.5 py-2 md:py-2.5 px-3 rounded-xl text-[10px] font-condensed font-bold tracking-[0.12em] uppercase transition-colors border
                          ${lockedIds.has(concept.id) ? 'bg-green-500/10 text-green-400 border-green-500/20 cursor-default' : 'bg-[#0d0d0d] border-[#1e1e1e] text-[#5a5a5a] hover:border-[#2a2a2a] hover:text-white'}`}
                      >
                        {lockingId === concept.id ? <span className="inline-block w-3 h-3 border-2 border-[#D4AF37] border-t-transparent rounded-full animate-spin" /> : lockedIds.has(concept.id) ? '✓ Locked' : 'Keep in Locker'}
                      </button>
                      <button onClick={() => handleDiscard(concept.id)} className="px-3 py-2 md:py-2.5 rounded-xl text-[10px] font-condensed font-bold tracking-wider uppercase bg-[#0d0d0d] border border-[#1e1e1e] text-[#505050] hover:border-red-500/20 hover:text-red-400">
                        Discard
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 md:mt-10">
              {!historyOpen ? (
                <button onClick={() => { setHistoryOpen(true); loadHistory(); }} className="w-full py-3 px-4 bg-[#111111] border border-[#1e1e1e] rounded-xl text-[#5a5a5a] hover:border-[#2a2a2a] hover:text-white transition-colors font-condensed text-[11px] font-bold tracking-[0.15em] uppercase flex items-center justify-center gap-2">
                  View Previous Generations
                </button>
              ) : (
                <div>
                  <button onClick={() => setHistoryOpen(false)} className="w-full py-3 px-4 bg-[#111111] border border-[#1e1e1e] rounded-xl text-[#5a5a5a] hover:text-white transition-colors font-condensed text-[11px] font-bold tracking-wider uppercase flex items-center justify-center gap-2 mb-4">
                    Hide Previous Generations
                  </button>
                  {historyBatches.length === 0 ? (
                    <p className="text-center text-[#5a5a5a] text-[13px] py-8">No previous generations for this project yet.</p>
                  ) : (
                    <div className="space-y-6">
                      {historyBatches.map((batch) => (
                        <div key={batch.batchId}>
                          <div className="flex items-center gap-3 mb-3">
                            <h3 className="font-condensed text-[11px] font-bold tracking-[0.15em] text-[#5a5a5a] uppercase">Batch • {batch.provider || ''} • {batch.model || ''}</h3>
                            {batch.createdAt && <span className="text-[10px] text-[#3a3a3a] font-mono">{new Date(batch.createdAt).toLocaleString()}</span>}
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            {batch.designs.map((design) => (
                              <div key={design.id} className="bg-[#111111] border border-[#1e1e1e] rounded-xl overflow-hidden">
                                <div className="aspect-square bg-[#0d0d0d]"><img src={design.imageUrl} alt={design.name} className="w-full h-full object-contain" draggable={false} /></div>
                                <div className="p-2"><p className="font-condensed text-[10px] font-bold text-white tracking-wider uppercase truncate">{design.name}</p></div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
