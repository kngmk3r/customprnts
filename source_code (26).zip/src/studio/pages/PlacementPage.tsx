/**
 * CUSTOM PRNTS — Design Placement (Polished — Formation Cards)
 *
 * Premium "Draft Day" visual selection:
 * - High-fidelity ghost mannequins per product category & viewpoint
 * - Glowing Print Zones with accurate physical positioning
 * - Fully responsive: desktop split, mobile tabs
 * - Garment color picker with quality details
 */

import { useState, useMemo } from 'react';
import type { Project } from '../storage';
import MockupRenderer from '../editor/components/MockupRenderer';
import { getProductById, getViewpoint } from '../editor/data/productLibrary';
import type { ProductDefinition, ProductViewpoint } from '../editor/data/productLibrary';
import type { OverlayConfig } from '../editor/overlaySystem';

interface Props {
  project: Project;
  onSave: (project: Project) => void;
  onApprove: () => void;
  onBack: () => void;
  onOpenAdvancedEditor: () => void;
  overlays?: OverlayConfig[];
}

export interface ProductFormation {
  id: string;
  name: string;
  viewId: string;
  label: string;
  description: string;
  widthInches: number;
  topOffsetInches: number;
  horizontalOffsetInches: number;
  badge?: string;
  icon: string; // used for glow positioning
  viewCategory?: 'tops' | 'headwear' | 'drinkware' | 'generic';
}

// ── Formation factory per product category ──

function getFormationsForProduct(product: ProductDefinition): ProductFormation[] {
  const cat = product.categoryId;

  if (cat === 'tops') {
    return [
      { id: 'center-chest', name: 'Center Chest', viewId: 'front', label: 'Classic', description: 'Standard centered placement — most versatile', widthInches: 10, topOffsetInches: 3, horizontalOffsetInches: 0, badge: 'MOST POPULAR', icon: 'center', viewCategory: 'tops' },
      { id: 'left-chest', name: 'Left Chest', viewId: 'front', label: 'Pocket Style', description: 'Elegant small logo — corporate ready', widthInches: 3.5, topOffsetInches: 3, horizontalOffsetInches: -3.5, icon: 'chest-left', viewCategory: 'tops' },
      { id: 'right-chest', name: 'Right Chest', viewId: 'front', label: 'Mirrored', description: 'Right chest small — modern', widthInches: 3.5, topOffsetInches: 3, horizontalOffsetInches: 3.5, icon: 'chest-right', viewCategory: 'tops' },
      { id: 'full-front', name: 'Full Front', viewId: 'front', label: 'Statement', description: 'Large impact — streetwear oversized', widthInches: 11.5, topOffsetInches: 2, horizontalOffsetInches: 0, badge: 'PREMIUM', icon: 'full', viewCategory: 'tops' },
      { id: 'full-back', name: 'Full Back', viewId: 'back', label: 'Big Back', description: 'Large back graphic — statement piece', widthInches: 12, topOffsetInches: 4, horizontalOffsetInches: 0, icon: 'back-full', viewCategory: 'tops' },
      { id: 'upper-back', name: 'Upper Back', viewId: 'back', label: 'Neck Logo', description: 'Small logo below collar — subtle', widthInches: 4, topOffsetInches: 1.8, horizontalOffsetInches: 0, icon: 'back-upper', viewCategory: 'tops' },
      { id: 'left-sleeve', name: 'Left Sleeve', viewId: 'left-sleeve', label: 'Sleeve Hit', description: 'Sleeve branding — detail', widthInches: 3, topOffsetInches: 1, horizontalOffsetInches: 0, icon: 'sleeve', viewCategory: 'tops' },
    ];
  }

  if (cat === 'headwear') {
    return [
      { id: 'hat-front', name: 'Front Center', viewId: 'front', label: 'Classic', description: 'Centered front embroidery', widthInches: 4, topOffsetInches: 0.5, horizontalOffsetInches: 0, badge: 'MOST POPULAR', icon: 'hat-front', viewCategory: 'headwear' },
      { id: 'hat-back', name: 'Back Arch', viewId: 'back', label: 'Arch', description: 'Small arch above closure', widthInches: 3, topOffsetInches: 0.3, horizontalOffsetInches: 0, icon: 'hat-back', viewCategory: 'headwear' },
      { id: 'hat-side-left', name: 'Side Left', viewId: 'left', label: 'Side Hit', description: 'Left side small hit', widthInches: 2.5, topOffsetInches: 0.5, horizontalOffsetInches: 0, icon: 'hat-side', viewCategory: 'headwear' },
      { id: 'hat-side-right', name: 'Side Right', viewId: 'right', label: 'Side Hit', description: 'Right side small hit', widthInches: 2.5, topOffsetInches: 0.5, horizontalOffsetInches: 0, icon: 'hat-side', viewCategory: 'headwear' },
    ];
  }

  if (cat === 'drinkware') {
    return [
      { id: 'mug-front', name: 'Front Side', viewId: 'front', label: 'Front', description: 'Single-sided front print', widthInches: 3.2, topOffsetInches: 0.5, horizontalOffsetInches: 0, badge: 'MOST POPULAR', icon: 'mug-front', viewCategory: 'drinkware' },
      { id: 'mug-back', name: 'Back Side', viewId: 'back', label: 'Back', description: 'Back side print', widthInches: 3.2, topOffsetInches: 0.5, horizontalOffsetInches: 0, icon: 'mug-back', viewCategory: 'drinkware' },
      { id: 'mug-wrap', name: 'Full Wrap', viewId: 'wrap', label: 'Wrap', description: '360° panoramic wrap', widthInches: 8.5, topOffsetInches: 0.5, horizontalOffsetInches: 0, badge: 'PREMIUM', icon: 'mug-wrap', viewCategory: 'drinkware' },
    ];
  }

  if (cat === 'bags') {
    return [
      { id: 'tote-center', name: 'Center', viewId: 'front', label: 'Centered', description: 'Large centered tote graphic', widthInches: 10, topOffsetInches: 3, horizontalOffsetInches: 0, badge: 'MOST POPULAR', icon: 'center', viewCategory: 'generic' },
      { id: 'tote-small', name: 'Small Center', viewId: 'front', label: 'Minimal', description: 'Small minimalist centered', widthInches: 5, topOffsetInches: 2, horizontalOffsetInches: 0, icon: 'chest-left', viewCategory: 'generic' },
    ];
  }

  // Generic / Print / Home / Tech fallback — one formation per viewpoint
  const viewpoints = product.viewpoints;
  return viewpoints.map((vp, idx) => ({
    id: `${vp.id}-center`,
    name: `${vp.label} Center`,
    viewId: vp.id,
    label: idx === 0 ? 'Standard' : vp.label,
    description: `Centered on ${vp.label.toLowerCase()}`,
    widthInches: Math.min(vp.physicalPrintArea.maxWidthInches * 0.75, 10),
    topOffsetInches: 1,
    horizontalOffsetInches: 0,
    badge: idx === 0 ? 'MOST POPULAR' : undefined,
    icon: 'center',
    viewCategory: 'generic' as const,
  }));
}

// ── Ghost Silhouettes ──

function GhostTShirt({ viewId, isSelected }: { viewId: string; isSelected: boolean }) {
  const isBack = viewId.includes('back');
  return (
    <svg viewBox="0 0 100 120" className={`w-full h-full transition-all duration-700 ${isSelected ? 'opacity-[0.28] scale-[1.08]' : 'opacity-[0.10] scale-100'}`}>
      {/* T-Shirt shape — more refined path */}
      <path
        fill="currentColor"
        className="text-white"
        d={isBack
          ? "M50 8 C42 8 35 10 30 14 L30 18 L14 28 L18 42 L26 38 L26 110 L74 110 L74 38 L82 42 L86 28 L70 18 L70 14 C65 10 58 8 50 8 Z M50 12 C48 12 46 13 45 15 L55 15 C54 13 52 12 50 12 Z"
          : "M50 10 C41 10 33 13 28 18 L12 27 L16 45 L28 39 L28 112 L72 112 L72 39 L84 45 L88 27 L72 18 C67 13 59 10 50 10 Z M50 14 C47 14 45 16 44 18 L56 18 C55 16 53 14 50 14 Z"
        }
      />
      {/* Stitch lines when selected */}
      {isSelected && (
        <path
          fill="none"
          stroke="currentColor"
          strokeWidth="0.3"
          strokeDasharray="2 2"
          className="text-white/20"
          d="M28 39 L28 110 M72 39 L72 110 M28 39 L72 39"
        />
      )}
    </svg>
  );
}

function GhostHat({ isSelected }: { isSelected: boolean }) {
  return (
    <svg viewBox="0 0 100 70" className={`w-full h-full transition-all duration-700 ${isSelected ? 'opacity-[0.28] scale-[1.08]' : 'opacity-[0.10] scale-100'}`}>
      <path fill="currentColor" className="text-white" d="M50 5 C30 5 15 18 12 30 L12 38 Q12 42 20 42 L80 42 Q88 42 88 38 L88 30 C85 18 70 5 50 5 Z M10 42 Q50 52 90 42 L85 48 Q50 58 15 48 Z" />
    </svg>
  );
}

function GhostMug({ isSelected, isWrap }: { isSelected: boolean; isWrap?: boolean }) {
  return (
    <svg viewBox="0 0 100 80" className={`w-full h-full transition-all duration-700 ${isSelected ? 'opacity-[0.28] scale-[1.08]' : 'opacity-[0.10] scale-100'}`}>
      {isWrap ? (
        <path fill="currentColor" className="text-white" d="M10 10 H90 C92 10 94 12 94 15 V65 C94 68 92 70 90 70 H10 C8 70 6 68 6 65 V15 C6 12 8 10 10 10 Z M90 20 C98 20 98 55 90 55 M10 20 C2 20 2 55 10 55" />
      ) : (
        <path fill="currentColor" className="text-white" d="M25 10 H75 C78 10 80 12 80 15 V60 C80 63 78 65 75 65 H25 C22 65 20 63 20 60 V15 C20 12 22 10 25 10 Z M80 20 C88 20 90 30 90 38 C90 46 88 55 80 55" />
      )}
    </svg>
  );
}

function GhostGeneric({ isSelected }: { isSelected: boolean }) {
  return (
    <svg viewBox="0 0 100 100" className={`w-full h-full transition-all duration-700 ${isSelected ? 'opacity-[0.28] scale-[1.08]' : 'opacity-[0.10] scale-100'}`}>
      <rect x="8" y="8" width="84" height="84" rx="8" fill="currentColor" className="text-white" />
    </svg>
  );
}

function GhostForFormation({ formation, isSelected }: { formation: ProductFormation; isSelected: boolean }) {
  const cat = formation.viewCategory;
  if (cat === 'headwear') return <GhostHat isSelected={isSelected} />;
  if (cat === 'drinkware') return <GhostMug isSelected={isSelected} isWrap={formation.id.includes('wrap')} />;
  if (cat === 'tops') return <GhostTShirt viewId={formation.viewId} isSelected={isSelected} />;
  return <GhostGeneric isSelected={isSelected} />;
}

// Print Zone positions — precise per formation
function getPrintZoneStyle(icon: string) {
  switch (icon) {
    case 'center':
      return 'w-[52%] h-[56%] top-[28%] left-1/2 -translate-x-1/2';
    case 'chest-left':
      return 'w-[22%] h-[20%] top-[31%] left-[26%]';
    case 'chest-right':
      return 'w-[22%] h-[20%] top-[31%] right-[26%] left-auto';
    case 'full':
      return 'w-[68%] h-[72%] top-[22%] left-1/2 -translate-x-1/2';
    case 'back-full':
      return 'w-[66%] h-[70%] top-[26%] left-1/2 -translate-x-1/2';
    case 'back-upper':
      return 'w-[38%] h-[18%] top-[20%] left-1/2 -translate-x-1/2';
    case 'sleeve':
      return 'w-[46%] h-[36%] top-[32%] left-1/2 -translate-x-1/2';
    case 'hat-front':
      return 'w-[56%] h-[38%] top-[22%] left-1/2 -translate-x-1/2';
    case 'hat-back':
      return 'w-[42%] h-[20%] top-[28%] left-1/2 -translate-x-1/2';
    case 'hat-side':
      return 'w-[36%] h-[26%] top-[32%] left-1/2 -translate-x-1/2';
    case 'mug-front':
      return 'w-[58%] h-[52%] top-[22%] left-1/2 -translate-x-1/2';
    case 'mug-back':
      return 'w-[58%] h-[52%] top-[22%] left-1/2 -translate-x-1/2';
    case 'mug-wrap':
      return 'w-[88%] h-[62%] top-[18%] left-1/2 -translate-x-1/2';
    default:
      return 'w-[50%] h-[50%] top-[30%] left-1/2 -translate-x-1/2';
  }
}

// ── Main Component ──

export default function PlacementPage({ project, onSave, onApprove, onBack, onOpenAdvancedEditor }: Props) {
  const [selectedFormationId, setSelectedFormationId] = useState<string | null>(project.placement?.presetId || null);
  const [colorId, setColorId] = useState(project.colorId || 'black');
  const [mobileTab, setMobileTab] = useState<'placements' | 'preview'>('placements');

  const product = useMemo(() => getProductById(project.productId || 'adult-tshirt')!, [project.productId]);
  const currentColor = useMemo(() => product.colors.find(c => c.id === colorId) || product.colors[0], [product, colorId]);

  const formations = useMemo(() => getFormationsForProduct(product), [product]);

  const selectedFormation = useMemo(
    () => formations.find(f => f.id === selectedFormationId) || null,
    [formations, selectedFormationId]
  );

  const handleApprove = () => {
    if (!selectedFormation) return;
    onSave({
      ...project,
      colorId,
      viewId: selectedFormation.viewId,
      placement: {
        presetId: selectedFormation.id,
        widthInches: selectedFormation.widthInches,
        topOffsetInches: selectedFormation.topOffsetInches,
        horizontalOffsetInches: selectedFormation.horizontalOffsetInches,
        rotationDegrees: 0
      }
    });
    onApprove();
  };

  // Auto-switch to preview tab on mobile when selecting
  const handleSelectFormation = (id: string) => {
    setSelectedFormationId(id);
    if (window.innerWidth < 768) {
      // brief delay to allow selection animation
      setTimeout(() => setMobileTab('preview'), 400);
    }
  };

  return (
    <div className="min-h-screen bg-[#0d0d0d] flex flex-col">
      {/* ── Header ── */}
      <div className="h-14 border-b border-[#2a2a2a] bg-[#111111] flex items-center justify-between px-4 md:px-6 shrink-0 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="w-9 h-9 flex items-center justify-center rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white hover:border-[#3a3a3a] transition-all">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
          </button>
          <div className="hidden md:block w-px h-5 bg-[#2a2a2a] mx-1" />
          <div>
            <h1 className="font-condensed text-[13px] md:text-[15px] font-black text-white tracking-[0.18em] uppercase leading-none">Design Placement</h1>
            <p className="font-mono text-[9px] text-[#737373] tracking-widest uppercase mt-0.5 hidden md:block">{product.name} • {formations.length} formations</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAdvancedEditor}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-[#2a2a2a] bg-[#1a1a1a] text-[10px] font-condensed font-bold text-[#737373] hover:text-[#D4AF37] hover:border-[#D4AF37]/30 tracking-widest uppercase transition-all"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 20h9" /><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z" /></svg>
            Advanced Editor
          </button>
          <button
            onClick={handleApprove}
            disabled={!selectedFormationId}
            className="bg-[#D4AF37] text-[#0d0d0d] px-4 md:px-6 py-2 rounded-full font-condensed font-black text-[11px] md:text-xs tracking-[0.15em] uppercase hover:bg-[#E8CC6E] transition-all shadow-[0_0_20px_rgba(212,175,55,0.25)] disabled:opacity-30 disabled:grayscale disabled:cursor-not-allowed active:scale-[0.98]"
          >
            <span className="hidden sm:inline">Continue to Approval →</span>
            <span className="sm:hidden">Continue →</span>
          </button>
        </div>
      </div>

      {/* ── Mobile Tabs ── */}
      <div className="md:hidden flex bg-[#111111] border-b border-[#2a2a2a] sticky top-14 z-30">
        <button
          onClick={() => setMobileTab('placements')}
          className={`flex-1 py-3 text-[11px] font-condensed font-black tracking-[0.2em] uppercase border-b-2 transition-all ${mobileTab === 'placements' ? 'border-[#D4AF37] text-white bg-[#1a1a1a]' : 'border-transparent text-[#737373]'}`}
        >
          placements ({formations.length})
        </button>
        <button
          onClick={() => setMobileTab('preview')}
          className={`flex-1 py-3 text-[11px] font-condensed font-black tracking-[0.2em] uppercase border-b-2 transition-all flex items-center justify-center gap-1.5 ${mobileTab === 'preview' ? 'border-[#D4AF37] text-white bg-[#1a1a1a]' : 'border-transparent text-[#737373]'}`}
        >
          <span className={`w-1.5 h-1.5 rounded-full ${selectedFormationId ? 'bg-green-500 animate-pulse' : 'bg-[#2a2a2a]'}`} />
          preview
        </button>
      </div>

      {/* ── Main Layout ── */}
      <div className="flex-1 flex overflow-hidden flex-col md:flex-row">
        {/* Left: Playbook */}
        <div className={`w-full md:w-[52%] lg:w-[54%] md:border-r border-[#2a2a2a] bg-[#0d0d0d] flex flex-col overflow-hidden ${mobileTab === 'preview' ? 'hidden md:flex' : 'flex'}`}>
          <div className="flex-1 overflow-y-auto">
            <div className="max-w-[760px] mx-auto p-4 md:p-8">
              <div className="mb-6 md:mb-8">
                <h2 className="text-[24px] md:text-[30px] font-condensed font-black text-white tracking-tight uppercase leading-[0.9]">Where should<br className="hidden md:block" /> your design go?</h2>
                <p className="text-[12px] md:text-[13px] text-[#737373] font-body mt-2 md:mt-3 leading-relaxed max-w-md">
                  Select a placement below. Each card is pre-sized for production — pro-grade results with zero experience.
                </p>
                {/* Steps */}
                <div className="flex items-center gap-2 mt-4">
                  <div className="flex items-center gap-1.5">
                    <div className="w-5 h-5 rounded-full bg-[#D4AF37] text-black flex items-center justify-center font-black text-[10px]">1</div>
                    <span className="text-[10px] font-condensed font-bold text-white tracking-wider uppercase">Choose placement</span>
                  </div>
                  <div className="w-6 h-px bg-[#2a2a2a]" />
                  <div className="flex items-center gap-1.5 opacity-40">
                    <div className="w-5 h-5 rounded-full bg-[#2a2a2a] text-[#737373] flex items-center justify-center font-black text-[10px]">2</div>
                    <span className="text-[10px] font-condensed font-bold tracking-wider uppercase">Pick color</span>
                  </div>
                  <div className="w-6 h-px bg-[#2a2a2a]" />
                  <div className="flex items-center gap-1.5 opacity-40">
                    <div className="w-5 h-5 rounded-full bg-[#2a2a2a] text-[#737373] flex items-center justify-center font-black text-[10px]">3</div>
                    <span className="text-[10px] font-condensed font-bold tracking-wider uppercase">Approve</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                {formations.map((f) => {
                  const isSelected = selectedFormationId === f.id;
                  return (
                    <button
                      key={f.id}
                      onClick={() => handleSelectFormation(f.id)}
                      className={`relative group flex flex-col text-left transition-all duration-300 rounded-[12px] overflow-hidden border-2
                        ${isSelected
                          ? 'border-[#D4AF37] bg-[#1a1a1a] shadow-[0_0_40px_rgba(212,175,55,0.22),0_0_0_1px_rgba(212,175,55,0.2)_inset] scale-[1.02] md:scale-[1.04] z-10'
                          : 'border-[#232323] bg-[#111111] hover:border-[#D4AF37]/40 hover:shadow-[0_0_24px_rgba(212,175,55,0.08)] hover:scale-[1.01]'
                        }`}
                    >
                      {/* Top accent */}
                      <div className={`h-[3px] w-full transition-all ${f.badge ? 'bg-[#D4AF37]' : isSelected ? 'bg-[#D4AF37]/60' : 'bg-[#2a2a2a] group-hover:bg-[#3a3a3a]'}`} />

                      {f.badge && (
                        <div className="absolute top-[10px] left-[10px] z-20">
                          <span className={`px-1.5 py-0.5 rounded-[4px] text-[8px] font-black tracking-[0.08em] uppercase shadow-sm
                            ${f.badge === 'MOST POPULAR' ? 'bg-[#D4AF37] text-black' : f.badge === 'PREMIUM' ? 'bg-white text-black' : 'bg-[#2a2a2a] text-[#D4AF37] border border-[#D4AF37]/30'}`}>
                            {f.badge}
                          </span>
                        </div>
                      )}

                      <div className="absolute top-[10px] right-[10px] z-20 flex items-center gap-1">
                        <span className={`px-1.5 py-0.5 rounded-full text-[9px] font-mono font-bold tracking-wider border backdrop-blur-md
                          ${isSelected ? 'bg-black/70 border-[#D4AF37]/40 text-[#D4AF37]' : 'bg-black/60 border-white/10 text-[#888] group-hover:text-white'}`}>
                          {f.widthInches}"
                        </span>
                      </div>

                      {/* Card Main — Ghost */}
                      <div className="aspect-[3/4] md:aspect-[4/5] p-4 md:p-6 flex items-center justify-center relative overflow-hidden">
                        {/* Grid pattern */}
                        <div className="absolute inset-0 opacity-[0.04] group-hover:opacity-[0.06] transition-opacity">
                          <svg width="100%" height="100%"><pattern id={`grid-${f.id}`} width="16" height="16" patternUnits="userSpaceOnUse"><path d="M 16 0 L 0 0 0 16" fill="none" stroke="white" strokeWidth="0.5" /></pattern><rect width="100%" height="100%" fill={`url(#grid-${f.id})`} /></svg>
                        </div>
                        {/* Radial glow when selected */}
                        <div className={`absolute inset-0 bg-radial-gradient from-[#D4AF37]/[0.08] via-transparent to-transparent transition-opacity duration-500 ${isSelected ? 'opacity-100' : 'opacity-0'}`} />

                        <div className="relative w-full h-full flex items-center justify-center">
                          <div className="w-[76%] md:w-[72%] h-[84%] flex items-center justify-center">
                            <GhostForFormation formation={f} isSelected={isSelected} />
                          </div>

                          {/* Print Zone */}
                          <div className={`absolute border-2 rounded-[3px] transition-all duration-500 ${getPrintZoneStyle(f.icon)} 
                            ${isSelected
                              ? 'border-[#D4AF37] bg-[#D4AF37]/[0.22] shadow-[0_0_22px_rgba(212,175,55,0.6),inset_0_0_12px_rgba(212,175,55,0.15)]'
                              : 'border-[#D4AF37]/50 bg-[#D4AF37]/[0.10] group-hover:border-[#D4AF37]/80 group-hover:bg-[#D4AF37]/[0.16] shadow-[0_0_12px_rgba(212,175,55,0.22)]'
                            }`}>
                            {/* Corner brackets */}
                            <div className="absolute -top-[1px] -left-[1px] w-2 h-2 border-l-2 border-t-2 border-[#D4AF37] rounded-tl-[2px]" />
                            <div className="absolute -top-[1px] -right-[1px] w-2 h-2 border-r-2 border-t-2 border-[#D4AF37] rounded-tr-[2px]" />
                            <div className="absolute -bottom-[1px] -left-[1px] w-2 h-2 border-l-2 border-b-2 border-[#D4AF37] rounded-bl-[2px]" />
                            <div className="absolute -bottom-[1px] -right-[1px] w-2 h-2 border-r-2 border-b-2 border-[#D4AF37] rounded-br-[2px]" />
                            {/* Center dot */}
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-1 bg-[#D4AF37] rounded-full opacity-60" />
                          </div>
                        </div>

                        {/* Selected check */}
                        {isSelected && (
                          <div className="absolute bottom-2 right-2 w-5 h-5 rounded-full bg-[#D4AF37] text-black flex items-center justify-center shadow-[0_0_10px_rgba(212,175,55,0.6)] animate-in zoom-in duration-300">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5"><path d="M5 13l4 4L19 7" /></svg>
                          </div>
                        )}
                      </div>

                      {/* Card Footer */}
                      <div className={`p-3 md:p-3.5 border-t transition-colors ${isSelected ? 'border-[#D4AF37]/20 bg-[#D4AF37]/[0.04]' : 'border-[#1e1e1e] bg-[#0d0d0d] group-hover:bg-[#151515]'}`}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <h3 className="font-condensed font-black text-white text-[11px] md:text-[12px] tracking-[0.12em] uppercase truncate leading-tight">{f.name}</h3>
                            <p className="text-[9px] md:text-[10px] text-[#8a8a8a] font-bold uppercase tracking-[0.14em] mt-0.5 truncate">{f.label} • {f.viewId.toUpperCase()}</p>
                          </div>
                          <div className="hidden md:flex gap-[3px] pt-1 shrink-0">
                            {[1,2,3].map(i => <div key={i} className={`w-[3px] h-[3px] rounded-full transition-colors ${isSelected ? 'bg-[#D4AF37]' : 'bg-[#2a2a2a] group-hover:bg-[#444]'}`} />)}
                          </div>
                        </div>
                        <p className="text-[10px] text-[#5a5a5a] leading-[1.3] mt-1.5 hidden md:block line-clamp-2">{f.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Garment Color — polished */}
              <div className="mt-10 md:mt-14 pt-6 md:pt-8 border-t border-[#1e1e1e]">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-condensed text-[12px] md:text-[13px] font-black text-white tracking-[0.18em] uppercase flex items-center gap-2">
                    <span className="w-[2px] h-[14px] bg-[#D4AF37] rounded-full" />
                    Garment Color
                    <span className="ml-2 px-2 py-0.5 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[9px] font-mono font-bold text-[#737373] tracking-wider uppercase">{currentColor.name}</span>
                  </h3>
                  <span className="text-[10px] font-mono text-[#505050]">{product.colors.length} colors</span>
                </div>
                <div className="grid grid-cols-4 xs:grid-cols-5 sm:grid-cols-6 md:flex md:flex-wrap gap-2.5 md:gap-3">
                  {product.colors.map(c => {
                    const isSelected = colorId === c.id;
                    return (
                      <button
                        key={c.id}
                        onClick={() => setColorId(c.id)}
                        className="group relative flex flex-col items-center gap-1.5"
                        title={`${c.name} — ${c.hex}`}
                      >
                        <div
                          className={`w-[44px] h-[44px] md:w-[48px] md:h-[48px] rounded-[12px] border-2 transition-all duration-300 shadow-[0_2px_10px_rgba(0,0,0,0.3)] relative overflow-hidden
                            ${isSelected ? 'border-[#D4AF37] scale-[1.08] shadow-[0_0_0_1px_rgba(212,175,55,0.3),0_0_20px_rgba(212,175,55,0.2)]' : 'border-[#2a2a2a] hover:border-white/30 hover:scale-[1.04]'}
                          `}
                          style={{ backgroundColor: c.hex }}
                        >
                          {/* Inner fabric texture for darks */}
                          <div className="absolute inset-0 opacity-[0.06] mix-blend-overlay" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence baseFrequency='0.9'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")` }} />
                          {isSelected && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className={`w-5 h-5 rounded-full flex items-center justify-center backdrop-blur-md border ${c.isDark ? 'bg-white/90 border-white text-black' : 'bg-black/80 border-black/20 text-white'}`}>
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M5 13l4 4L19 7" /></svg>
                              </div>
                            </div>
                          )}
                        </div>
                        <span className={`text-[9px] font-condensed font-bold tracking-wider uppercase truncate max-w-[56px] transition-colors ${isSelected ? 'text-white' : 'text-[#5a5a5a] group-hover:text-[#8a8a8a]'}`}>{c.name}</span>
                      </button>
                    );
                  })}
                </div>
                {/* Selected color detail */}
                <div className="mt-4 p-3 rounded-xl bg-[#111111] border border-[#1e1e1e] flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg border border-[#2a2a2a] shadow-inner" style={{ backgroundColor: currentColor.hex }} />
                  <div className="min-w-0">
                    <p className="font-condensed font-bold text-white text-[11px] tracking-wider uppercase leading-none">{currentColor.name}</p>
                    <p className="font-mono text-[10px] text-[#737373] mt-1">{currentColor.hex.toUpperCase()} • {currentColor.isDark ? 'Dark base — light inks pop' : 'Light base — dark inks pop'}</p>
                  </div>
                  <div className={`ml-auto px-2 py-1 rounded-full text-[9px] font-bold tracking-widest uppercase border ${currentColor.isDark ? 'bg-[#1a1a1a] border-[#2a2a2a] text-[#8a8a8a]' : 'bg-white text-black border-white'}`}>
                    {currentColor.isDark ? 'DARK' : 'LIGHT'}
                  </div>
                </div>
              </div>

              {/* Mobile continue — shows only if placement selected and on placements tab */}
              <div className="md:hidden mt-8">
                <button onClick={() => setMobileTab('preview')} disabled={!selectedFormationId} className="w-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] py-4 rounded-xl font-condensed font-black text-[12px] tracking-[0.2em] uppercase disabled:opacity-30">
                  {selectedFormationId ? 'Preview Placement →' : 'Select a placement first'}
                </button>
                <button onClick={onOpenAdvancedEditor} className="w-full mt-3 text-[10px] font-condensed font-bold text-[#505050] tracking-widest uppercase text-center py-2">
                  Need custom positioning? <span className="text-[#D4AF37]">Open Advanced Editor (BETA)</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Realistic Preview — polished */}
        <div className={`flex-1 bg-[#080808] flex flex-col relative overflow-hidden ${mobileTab === 'placements' ? 'hidden md:flex' : 'flex'}`}>
          {/* Background effects */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-[-30%] left-1/2 -translate-x-1/2 w-[80%] h-[60%] bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.10)_0%,_transparent_70%)] blur-2xl" />
            <div className="absolute inset-0 opacity-[0.02]" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }} />
          </div>

          {selectedFormation ? (
            <div className="flex-1 flex flex-col p-4 md:p-8 lg:p-12 overflow-y-auto relative z-10">
              {/* Selected badge */}
              <div className="text-center mb-4 md:mb-6">
                <span className="inline-flex items-center gap-2 px-3 md:px-4 py-1.5 rounded-full border border-[#D4AF37]/30 bg-[#D4AF37]/10 text-[10px] font-condensed font-black text-[#D4AF37] tracking-[0.2em] uppercase backdrop-blur-md">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />
                  {selectedFormation.name} • {selectedFormation.viewId} • {selectedFormation.widthInches}"
                </span>
                <p className="text-[11px] md:text-[12px] text-[#5a5a5a] mt-2.5 max-w-[320px] mx-auto leading-relaxed">
                  Your design is auto-sized to <span className="text-[#8a8a8a] font-bold">{selectedFormation.widthInches}" wide</span> and positioned for production. 300 DPI checked.
                </p>
              </div>

              {/* Mockup */}
              <div className="flex-1 flex items-center justify-center">
                <div className="w-full max-w-[440px] md:max-w-[520px] relative group">
                  {/* Glow behind mockup when selected */}
                  <div className="absolute inset-0 -m-6 bg-[radial-gradient(ellipse_at_center,_rgba(212,175,55,0.12)_0%,_transparent_60%)] blur-xl opacity-60 group-hover:opacity-80 transition-opacity" />
                  <div className="relative">
                    <MockupRenderer
                      productTemplate={{
                        id: product.id,
                        name: product.name,
                        category: product.categoryId,
                        subcategory: product.subcategory,
                        views: product.viewpoints as any,
                        colors: product.colors,
                        baseImageUrl: product.baseImageUrl,
                        maskUrl: product.maskUrl,
                        supportedPrintMethods: product.supportedPrintMethods
                      }}
                      viewId={selectedFormation.viewId}
                      productColor={currentColor.hex}
                      artworkDataUrl={project.canvasThumbnail || project.conceptImageUrl}
                      placementX={0.5 + selectedFormation.horizontalOffsetInches / 12}
                      placementY={0.3 + selectedFormation.topOffsetInches / 14}
                      placementWidth={selectedFormation.widthInches / 12}
                      baseImageUrl={product.baseImageUrl}
                      maskUrl={product.maskUrl}
                    />
                  </div>
                </div>
              </div>

              {/* Production meta & actions */}
              <div className="mt-6 md:mt-8 max-w-[380px] mx-auto w-full space-y-3">
                <div className="bg-[#111111] border border-[#1e1e1e] rounded-xl p-3.5 flex items-center justify-between shadow-[0_8px_30px_rgba(0,0,0,0.4)]">
                  <div className="flex items-center gap-2.5">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
                    <div>
                      <p className="text-[10px] font-condensed font-black text-white tracking-[0.12em] uppercase leading-none">Placement Optimized</p>
                      <p className="text-[9px] font-mono text-[#5a5a5a] mt-1">{selectedFormation.widthInches}" • {selectedFormation.topOffsetInches}" down • centered</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-2 py-1 rounded bg-[#1a1a1a] border border-[#2a2a2a] text-[8px] font-mono font-bold text-[#D4AF37] tracking-wider">300 DPI ✓</span>
                    <p className="text-[8px] font-mono text-[#505050] mt-1">PRODUCTION READY</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <button onClick={handleApprove} className="bg-[#D4AF37] text-black py-[14px] rounded-xl font-condensed font-black text-[11px] tracking-[0.16em] uppercase hover:bg-[#E8CC6E] transition-all active:scale-[0.98] shadow-[0_8px_20px_rgba(212,175,55,0.25)]">
                    Choose This Placement
                  </button>
                  <button onClick={() => setSelectedFormationId(null)} className="bg-[#1a1a1a] border border-[#2a2a2a] text-[#8a8a8a] py-[14px] rounded-xl font-condensed font-bold text-[11px] tracking-[0.16em] uppercase hover:text-white hover:border-[#3a3a3a] hover:bg-[#222] transition-all active:scale-[0.98]">
                    Change
                  </button>
                </div>

                <button onClick={handleApprove} className="w-full bg-white/[0.06] hover:bg-white/[0.09] border border-white/10 text-white py-3 rounded-xl font-condensed font-bold text-[11px] tracking-[0.18em] uppercase transition-all active:scale-[0.98]">
                  Continue to Approval →
                </button>

                <div className="flex items-center justify-center gap-3 pt-1">
                  <button onClick={() => setMobileTab('placements')} className="md:hidden text-[10px] font-condensed font-bold text-[#505050] hover:text-[#8a8a8a] tracking-widest uppercase">← Back to Placements</button>
                  <span className="md:hidden w-px h-3 bg-[#2a2a2a]" />
                  <button onClick={onOpenAdvancedEditor} className="text-[10px] font-condensed font-bold text-[#505050] hover:text-white tracking-widest uppercase flex items-center gap-1.5 group">
                    Custom? <span className="text-[#D4AF37] group-hover:text-[#E8CC6E]">Advanced Editor</span>
                    <span className="px-1 py-0.5 rounded bg-[#1e1e1e] border border-[#2a2a2a] text-[7px] font-black tracking-tighter leading-none">BETA</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-12 relative z-10 text-center">
              <div className="w-24 h-24 mx-auto mb-6 relative">
                <div className="absolute inset-0 rounded-full border border-dashed border-[#2a2a2a] animate-[spin_20s_linear_infinite]" />
                <div className="absolute inset-[12%] rounded-full border border-[#1e1e1e] flex items-center justify-center bg-[#111111]">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#2a2a2a" strokeWidth="1.2"><rect x="3" y="3" width="18" height="18" rx="3" /><path d="M12 8v8M8 12h8" /></svg>
                </div>
                {/* Orbit dots */}
                <div className="absolute top-1 left-1/2 w-1 h-1 bg-[#D4AF37]/60 rounded-full" />
                <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-[#D4AF37]/30 rounded-full" />
              </div>
              <p className="font-condensed text-[13px] font-black text-[#505050] tracking-[0.16em] uppercase">Select a Placement to Preview</p>
              <p className="font-body text-[11px] text-[#3a3a3a] mt-2 max-w-[240px] leading-relaxed">Choose a formation card on the left — your design will appear here instantly, production-ready.</p>
              <button onClick={() => setMobileTab('placements')} className="md:hidden mt-6 px-5 py-2.5 rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[11px] font-condensed font-bold tracking-widest uppercase text-[#8a8a8a] hover:text-white hover:border-[#3a3a3a]">
                Browse Placements
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
