import { useState, useCallback, useEffect } from 'react';
import { useStudioStore } from './store';
import { ensureSession } from './edgesparkClient';
import SiteHeader from '../components/SiteHeader';
import ProjectsPage from './pages/ProjectsPage';
import NewProjectPage from './pages/NewProjectPage';
import ConceptSelectionPage from './pages/ConceptSelectionPage';
import DesignEditorPage from './pages/DesignEditorPage';
import ProducePage from './pages/ProducePage';
import PlacementPage from './pages/PlacementPage';
import LockerPage from './pages/LockerPage';
import type { ProjectBrief } from './storage';
import type { GenerationError } from './conceptGenerator';
import type { LockerItem } from './conceptGenerator';

type StudioView = 'projects' | 'new-project' | 'concepts' | 'editor' | 'placement' | 'produce' | 'locker';

type SessionStatus =
  | { phase: 'checking' }
  | { phase: 'ready' }
  | { phase: 'failed'; reason?: string };

export default function StudioApp() {
  const store = useStudioStore();
  const [view, setView] = useState<StudioView>('projects');
  const [isGenerating, setIsGenerating] = useState(false);
  const [regeneratingIndex, setRegeneratingIndex] = useState<number | null>(null);

  // ── session state ────────────────────────────────────────
  const [session, setSession] = useState<SessionStatus>({ phase: 'checking' });

  // Handle direct URL access for Advanced Editor
  useEffect(() => {
    if (window.location.pathname.includes('/editor') || window.location.hash.includes('/editor')) {
      if (store.currentProject) {
        setView('editor');
      }
    }
  }, [store.currentProject]);

  useEffect(() => {
    ensureSession().then(r => {
      setSession(r.ok ? { phase: 'ready' } : { phase: 'failed', reason: r.reason });
    });
  }, []);

  // ── handlers ─────────────────────────────────────────────

  const handleNewProject = useCallback(() => setView('new-project'), []);
  const handleBackToInterview = useCallback(() => {
    // Pass the existing brief so the interview form is pre-filled
    setView('new-project');
  }, []);

  const handleBackToProjects = useCallback(() => {
    store.setState(s => ({ ...s, currentProject: null, concepts: [], generationError: null }));
    setView('projects');
    store.loadProjects();
  }, [store]);

  const handleRetryWorkspace = useCallback(() => {
    setSession({ phase: 'checking' });
    ensureSession().then(r => {
      setSession(r.ok ? { phase: 'ready' } : { phase: 'failed', reason: r.reason });
    });
  }, []);

  const handleGenerate = useCallback(async (brief: ProjectBrief, tier: 'free' | 'premium' = 'free') => {
    setIsGenerating(true);

    // ── ensure a valid session before hitting the backend ──
    if (session.phase !== 'ready') {
      setSession({ phase: 'checking' });
      const result = await ensureSession();
      if (!result.ok) {
        setSession({ phase: 'failed', reason: result.reason });
        setIsGenerating(false);
        // Show a customer-facing generation error — do NOT wipe the brief
        store.setState(s => ({
          ...s,
          generationError: {
            code: 'SESSION_FAILED',
            message: "We couldn't create your private design workspace. Please try again.",
            retryable: true,
          },
        }));
        setView('concepts');
        return;
      }
      setSession({ phase: 'ready' });
    }

    try {
      await store.createProject(brief, tier);
      setView('concepts');
    } finally {
      setIsGenerating(false);
    }
  }, [session.phase, store]);

  const handleOpenProject = useCallback(async (id: string) => {
    await store.openProject(id);
    setView('editor');
  }, [store]);

  const handleSelectConcept = useCallback(async (conceptId: string) => {
    if (!store.currentProject) return;
    const concept = store.concepts.find(c => c.id === conceptId);
    if (!concept) return;
    console.log('[StudioApp] handleSelectConcept:', { conceptId, conceptURL: concept.imageUrl });
    const updated = {
      ...store.currentProject,
      selectedConceptId: conceptId,
      conceptImageUrl: concept.imageUrl,
      canvasJSON: null,
      productId: 'adult-tshirt',
      colorId: 'black',
      viewId: 'front',
      placement: {
        widthInches: 10,
        topOffsetInches: 2,
        horizontalOffsetInches: 0,
        rotationDegrees: 0,
      },
      updatedAt: new Date().toISOString(),
    };
    console.log('[StudioApp] Saving project with conceptImageUrl:', updated.conceptImageUrl);
    await store.saveProject(updated);
    console.log('[StudioApp] Project saved, navigating to placement');
    setView('placement');
  }, [store]);

  const handleRegenerate = useCallback(async (index: number) => {
    if (!store.currentProject) return;
    setRegeneratingIndex(index);
    try {
      await store.regenerateConcept(index, store.currentProject.brief);
    } finally {
      setRegeneratingIndex(null);
    }
  }, [store]);

  const handleRetryGeneration = useCallback((tier?: 'free' | 'premium') => {
    if (!store.currentProject) return;
    setIsGenerating(true);
    store.retryGeneration(store.currentProject.brief, tier).then(() => {
      setIsGenerating(false);
    }).catch(() => setIsGenerating(false));
  }, [store]);

  const handleSave = useCallback(async (project: any) => {
    await store.saveProject(project);
  }, [store]);

  const handlePreview = useCallback(() => setView('produce'), []);
  const handleProduce = useCallback(() => setView('produce'), []);
  const handleBackToEditor = useCallback(() => setView('editor'), []);
  const handleBackToPreview = useCallback(() => setView('editor'), []);
  const handleOpenAdvancedEditor = useCallback(() => setView('editor'), []);
  const handleOpenLocker = useCallback(() => setView('locker'), []);
  const handleBackFromLocker = useCallback(() => setView('projects'), []);

  // ── Locker → Model/Editor/Preview ──

  const handleLockerApplyToModel = useCallback(async (item: LockerItem) => {
    // Set designDataUrl so ProducePage can render it on the mockup
    if (store.currentProject) {
      const updated = {
        ...store.currentProject,
        conceptImageUrl: item.designImageUrl,
        canvasThumbnail: item.designImageUrl,
        selectedConceptId: item.designId,
        updatedAt: new Date().toISOString(),
      };
      await store.saveProject(updated);
    }
    setView('editor');
  }, [store]);

  const handleLockerSendToEditor = useCallback(async (item: LockerItem) => {
    // Editor reads conceptImageUrl to load into Fabric.js canvas
    if (store.currentProject) {
      const updated = {
        ...store.currentProject,
        conceptImageUrl: item.designImageUrl,
        selectedConceptId: item.designId,
        // Clear canvasJSON so editor loads fresh from conceptImageUrl
        canvasJSON: null,
        canvasThumbnail: item.designImageUrl,
        updatedAt: new Date().toISOString(),
      };
      await store.saveProject(updated);
    }
    setView('editor');
  }, [store]);

  const handleLockerSendToPreview = useCallback(async (item: LockerItem) => {
    // Navigate to Editor
    if (store.currentProject) {
      const updated = {
        ...store.currentProject,
        conceptImageUrl: item.designImageUrl,
        canvasThumbnail: item.designImageUrl,
        selectedConceptId: item.designId,
        updatedAt: new Date().toISOString(),
      };
      await store.saveProject(updated);
    }
    setView('editor');
  }, [store]);

  // ── rendering helpers ────────────────────────────────────

  /** Customer-facing "workspace preparing" overlay shown while session initialises. */
  const sessionOverlay = session.phase === 'checking' && (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-studio-surface/90 backdrop-blur-sm">
      <div className="text-center">
        <div className="inline-block w-12 h-12 border-2 border-studio-gold border-t-transparent rounded-full animate-spin mb-4" />
        <p className="font-condensed text-lg font-bold tracking-wider text-white uppercase">
          Preparing your private design workspace…
        </p>
        <p className="font-body text-sm text-studio-muted mt-1">This usually takes just a moment.</p>
      </div>
    </div>
  );

  /** Customer-facing "workspace failed" overlay with retry button. */
  const sessionFailedOverlay = session.phase === 'failed' && view === 'projects' && (
    <div className="max-w-lg mx-auto mt-16 text-center px-6">
      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 mb-6">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10" />
          <line x1="15" y1="9" x2="9" y2="15" />
          <line x1="9" y1="9" x2="15" y2="15" />
        </svg>
      </div>
      <h2 className="text-xl font-condensed font-bold text-white tracking-wider uppercase mb-3">
        Workspace Not Available
      </h2>
      <p className="text-studio-muted mb-6 max-w-sm mx-auto">
        We couldn't create your private design workspace. Please try again.
      </p>
      <button onClick={handleRetryWorkspace} className="studio-btn-primary px-6">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="inline mr-2">
          <path d="M1 4v6h6M23 20v-6h-6" />
          <path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15" />
        </svg>
        Retry Workspace
      </button>
    </div>
  );

  // ── view router ──────────────────────────────────────────

  const renderView = () => {
    switch (view) {
      case 'projects':
        return (
          <>
            {sessionFailedOverlay}
            <ProjectsPage
              projects={store.projects}
              isLoading={store.isLoading}
              onLoadProjects={store.loadProjects}
              onNewProject={handleNewProject}
              onOpenProject={handleOpenProject}
              onDuplicateProject={store.duplicateProject}
              onDeleteProject={store.deleteProject}
            />
          </>
        );
      case 'new-project':
        return (
          <NewProjectPage
            onGenerate={handleGenerate}
            onBack={handleBackToProjects}
            isGenerating={isGenerating}
            initialBrief={store.currentProject?.brief || null}
          />
        );
      case 'concepts':
        return (
          <ConceptSelectionPage
            concepts={store.concepts}
            onSelect={handleSelectConcept}
            onRegenerate={handleRegenerate}
            onRetry={handleRetryGeneration}
            onRetryWorkspace={handleRetryWorkspace}
            sessionFailed={session.phase === 'failed'}
            onBackToInterview={handleBackToInterview}
            onBackToProjects={handleBackToProjects}
            onOpenLocker={handleOpenLocker}
            brief={store.currentProject?.brief || { name: '', description: '', productType: 'T-Shirt', shirtColor: '#1a1a1a', preferredColors: '', mainWording: '', notes: '' }}
            projectId={store.currentProject ? (store.currentProject as any).remoteProjectId || null : null}
            regeneratingIndex={regeneratingIndex}
            generationError={store.generationError}
            lastTier={store.lastTier}
            overlays={store.overlays}
          />
        );
      case 'editor':
        return (
          <DesignEditorPage
            project={store.currentProject!}
            onSave={handleSave}
            onAutosave={store.autosaveProject}
            onPreviewShirt={handleProduce}
            onBack={handleBackToProjects}
            onOpenLocker={handleOpenLocker}
            overlays={store.overlays}
            onToggleOverlay={store.toggleOverlay}
            onUnlockDesign={store.unlockDesign}
          />
        );
      case 'placement':
        return (
          <PlacementPage
            project={store.currentProject!}
            onSave={handleSave}
            onApprove={handleProduce}
            onBack={handleBackToProjects}
            onOpenAdvancedEditor={handleOpenAdvancedEditor}
            overlays={store.overlays}
          />
        );
      case 'produce':
        return (
          <ProducePage
            project={store.currentProject!}
            onSave={handleSave}
            onBackToEditor={handleBackToEditor}
            onBackToProjects={handleBackToProjects}
            overlays={store.overlays}
          />
        );
      case 'locker':
        return (
          <LockerPage
            onBack={handleBackFromLocker}
            onApplyToModel={handleLockerApplyToModel}
            onSendToEditor={handleLockerSendToEditor}
            onSendToPreview={handleLockerSendToPreview}
            overlays={store.overlays}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-studio-surface">
      <SiteHeader
        mode="studio"
        breadcrumbs={view === 'projects' ? [] : [{ label: view === 'new-project' ? 'New Project' : view === 'concepts' ? 'Concepts' : view === 'editor' ? 'Editor' : view === 'placement' ? 'Placement' : view === 'produce' ? 'Produce' : view === 'locker' ? 'Locker' : '' }]}
      />
      {sessionOverlay}
      {isGenerating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-studio-surface/90 backdrop-blur-sm">
          <div className="text-center">
            <div className="inline-block w-12 h-12 border-2 border-studio-gold border-t-transparent rounded-full animate-spin mb-4" />
            <p className="font-condensed text-lg font-bold tracking-wider text-white uppercase">Generating Concepts</p>
            <p className="font-body text-sm text-studio-muted mt-1">Creating unique designs from your brief...</p>
          </div>
        </div>
      )}
      {renderView()}
    </div>
  );
}
