/**
 * Export Service for CUSTOM PRNTS Design Studio
 *
 * All exports return a success boolean and trigger user-visible feedback.
 */

import type { Project } from './storage';

/* ─── Toast Feedback ─── */
let toastContainer: HTMLDivElement | null = null;

function showToast(message: string, type: 'success' | 'error' = 'success') {
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'studio-toast-container';
    toastContainer.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
    document.body.appendChild(toastContainer);
  }
  const toast = document.createElement('div');
  toast.style.cssText = `
    pointer-events:auto;
    padding:12px 20px;
    border-radius:8px;
    font-family:'Barlow Condensed',sans-serif;
    font-size:14px;
    font-weight:600;
    letter-spacing:0.05em;
    text-transform:uppercase;
    color:#FAFAFA;
    background:${type === 'success' ? '#1a1a1a' : '#7f1d1d'};
    border:1px solid ${type === 'success' ? '#D4AF37' : '#ef4444'};
    box-shadow:0 4px 20px rgba(0,0,0,0.4);
    opacity:0;
    transform:translateY(10px);
    transition:all 0.3s ease;
  `;
  toast.textContent = message;
  toastContainer.appendChild(toast);

  // Animate in
  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateY(0)';
  });

  // Remove after 3s
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/* ─── Downloads ─── */
function triggerDownload(dataUrl: string, filename: string) {
  const link = document.createElement('a');
  link.download = filename;
  link.href = dataUrl;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function triggerJSONDownload(data: object, filename: string) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  triggerDownload(url, filename);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

export function exportTransparentPNG(
  canvas: { toDataURL: (format: string, options?: object) => string },
  projectName: string
): boolean {
  try {
    const dataUrl = canvas.toDataURL('png', { multiplier: 2 });
    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    triggerDownload(dataUrl, `${safeName}_transparent.png`);
    showToast('Transparent PNG exported', 'success');
    return true;
  } catch (err) {
    console.error('Export transparent PNG failed:', err);
    showToast('Export failed — try again', 'error');
    return false;
  }
}

export function exportPNGWithBackground(
  canvas: { toDataURL: (format: string, options?: object) => string },
  projectName: string
): boolean {
  try {
    const dataUrl = canvas.toDataURL('png', { format: 'png', quality: 1, multiplier: 2 });
    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    triggerDownload(dataUrl, `${safeName}_with_bg.png`);
    showToast('PNG with background exported', 'success');
    return true;
  } catch (err) {
    console.error('Export PNG with background failed:', err);
    showToast('Export failed — try again', 'error');
    return false;
  }
}

export function exportProjectJSON(project: Project): boolean {
  try {
    const safeName = project.brief.name.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    triggerJSONDownload(project, `${safeName}_project.json`);
    showToast('Project JSON downloaded', 'success');
    return true;
  } catch (err) {
    console.error('Export project JSON failed:', err);
    showToast('Export failed — try again', 'error');
    return false;
  }
}

/** Export design from a data URL (for pages without a live Fabric.js canvas) */
export function exportDesignFromDataURL(
  dataUrl: string | null,
  projectName: string,
  variant: 'transparent' | 'with-bg'
): boolean {
  try {
    if (!dataUrl) {
      showToast('No design to export — open a project first', 'error');
      return false;
    }
    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    const suffix = variant === 'transparent' ? '_transparent' : '_with_bg';
    triggerDownload(dataUrl, `${safeName}${suffix}.png`);
    showToast(variant === 'transparent' ? 'Transparent PNG exported' : 'PNG with background exported', 'success');
    return true;
  } catch (err) {
    console.error('Export from data URL failed:', err);
    showToast('Export failed — try again', 'error');
    return false;
  }
}
