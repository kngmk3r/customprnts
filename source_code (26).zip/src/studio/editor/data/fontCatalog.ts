/**
 * CUSTOM PRNTS — Curated Font Catalog
 *
 * Fonts organized by design category, suitable for:
 * Streetwear, Church, Family Reunion, Sports, Business, Luxury, Kids, Memorial, Events.
 */

export interface FontEntry {
  family: string;
  label: string;
  categories: string[];
  weights: string[];
  source: 'google'; // all loaded from Google Fonts
}

export const FONT_CATALOG: FontEntry[] = [
  // ── Streetwear / Bold ──
  { family: 'Anton', label: 'Anton', categories: ['streetwear', 'sports'], weights: ['400'], source: 'google' },
  { family: 'Bebas Neue', label: 'Bebas Neue', categories: ['streetwear', 'events', 'bold'], weights: ['400'], source: 'google' },
  { family: 'Oswald', label: 'Oswald', categories: ['streetwear', 'bold'], weights: ['300', '400', '500', '600', '700'], source: 'google' },
  { family: 'Barlow Condensed', label: 'Barlow Condensed', categories: ['streetwear', 'ui'], weights: ['300', '400', '500', '600', '700'], source: 'google' },
  { family: 'Permanent Marker', label: 'Permanent Marker', categories: ['streetwear', 'graffiti'], weights: ['400'], source: 'google' },
  { family: 'Rubik Mono One', label: 'Rubik Mono One', categories: ['streetwear', 'bold'], weights: ['400'], source: 'google' },

  // ── Church / Elegant ──
  { family: 'Playfair Display', label: 'Playfair Display', categories: ['church', 'luxury', 'elegant'], weights: ['400', '500', '600', '700', '800', '900'], source: 'google' },
  { family: 'Cormorant Garamond', label: 'Cormorant Garamond', categories: ['church', 'luxury'], weights: ['300', '400', '500', '600', '700'], source: 'google' },
  { family: 'Cinzel', label: 'Cinzel', categories: ['church', 'luxury', 'classic'], weights: ['400', '500', '600', '700', '800', '900'], source: 'google' },
  { family: 'Great Vibes', label: 'Great Vibes', categories: ['church', 'elegant', 'script'], weights: ['400'], source: 'google' },
  { family: 'Lora', label: 'Lora', categories: ['church', 'classic'], weights: ['400', '500', '600', '700'], source: 'google' },

  // ── Family Reunion / Warm ──
  { family: 'Lobster', label: 'Lobster', categories: ['family', 'script', 'fun'], weights: ['400'], source: 'google' },
  { family: 'Pacifico', label: 'Pacifico', categories: ['family', 'script', 'fun'], weights: ['400'], source: 'google' },
  { family: 'Satisfy', label: 'Satisfy', categories: ['family', 'script'], weights: ['400'], source: 'google' },
  { family: 'Dancing Script', label: 'Dancing Script', categories: ['family', 'script'], weights: ['400', '500', '600', '700'], source: 'google' },
  { family: 'Amatic SC', label: 'Amatic SC', categories: ['family', 'fun', 'handwritten'], weights: ['400', '700'], source: 'google' },

  // ── Sports / Athletic ──
  { family: 'Teko', label: 'Teko', categories: ['sports', 'athletic'], weights: ['300', '400', '500', '600', '700'], source: 'google' },
  { family: 'Chakra Petch', label: 'Chakra Petch', categories: ['sports', 'tech'], weights: ['300', '400', '500', '600', '700'], source: 'google' },
  { family: 'Russo One', label: 'Russo One', categories: ['sports', 'bold'], weights: ['400'], source: 'google' },
  { family: 'Black Ops One', label: 'Black Ops One', categories: ['sports', 'military', 'bold'], weights: ['400'], source: 'google' },

  // ── Business / Professional ──
  { family: 'Montserrat', label: 'Montserrat', categories: ['business', 'clean', 'modern'], weights: ['300', '400', '500', '600', '700', '800', '900'], source: 'google' },
  { family: 'Raleway', label: 'Raleway', categories: ['business', 'clean', 'modern'], weights: ['300', '400', '500', '600', '700', '800', '900'], source: 'google' },
  { family: 'Poppins', label: 'Poppins', categories: ['business', 'clean', 'modern'], weights: ['300', '400', '500', '600', '700', '800', '900'], source: 'google' },
  { family: 'Roboto', label: 'Roboto', categories: ['business', 'clean'], weights: ['300', '400', '500', '700', '900'], source: 'google' },
  { family: 'Inter', label: 'Inter', categories: ['business', 'clean', 'ui'], weights: ['300', '400', '500', '600', '700', '800', '900'], source: 'google' },

  // ── Luxury / Premium ──
  { family: 'Cormorant', label: 'Cormorant', categories: ['luxury', 'elegant'], weights: ['300', '400', '500', '600', '700'], source: 'google' },
  { family: 'DM Serif Display', label: 'DM Serif Display', categories: ['luxury', 'classic'], weights: ['400'], source: 'google' },
  { family: 'Libre Baskerville', label: 'Libre Baskerville', categories: ['luxury', 'classic'], weights: ['400', '700'], source: 'google' },
  { family: 'Bodoni Moda', label: 'Bodoni Moda', categories: ['luxury', 'fashion'], weights: ['400', '500', '600', '700', '800', '900'], source: 'google' },

  // ── Kids / Fun ──
  { family: 'Bubblegum Sans', label: 'Bubblegum Sans', categories: ['kids', 'fun'], weights: ['400'], source: 'google' },
  { family: 'Fredoka One', label: 'Fredoka One', categories: ['kids', 'fun'], weights: ['400'], source: 'google' },
  { family: 'Boogaloo', label: 'Boogaloo', categories: ['kids', 'fun'], weights: ['400'], source: 'google' },
  { family: 'Luckiest Guy', label: 'Luckiest Guy', categories: ['kids', 'fun', 'bold'], weights: ['400'], source: 'google' },
  { family: 'Chewy', label: 'Chewy', categories: ['kids', 'fun'], weights: ['400'], source: 'google' },

  // ── Memorial / Somber ──
  { family: 'EB Garamond', label: 'EB Garamond', categories: ['memorial', 'classic'], weights: ['400', '500', '600', '700', '800', '900'], source: 'google' },
  { family: 'Spectral', label: 'Spectral', categories: ['memorial', 'elegant'], weights: ['300', '400', '500', '600', '700', '800'], source: 'google' },

  // ── Events / Display ──
  { family: 'Righteous', label: 'Righteous', categories: ['events', 'display'], weights: ['400'], source: 'google' },
  { family: 'Bungee', label: 'Bungee', categories: ['events', 'bold', 'display'], weights: ['400'], source: 'google' },
  { family: 'Monoton', label: 'Monoton', categories: ['events', 'retro'], weights: ['400'], source: 'google' },
  { family: 'Press Start 2P', label: 'Press Start 2P', categories: ['events', 'retro', 'gaming'], weights: ['400'], source: 'google' },
];

export const FONT_CATEGORIES = [
  { id: 'all', label: 'All Fonts' },
  { id: 'streetwear', label: 'Streetwear' },
  { id: 'church', label: 'Church' },
  { id: 'family', label: 'Family Reunion' },
  { id: 'sports', label: 'Sports' },
  { id: 'business', label: 'Business' },
  { id: 'luxury', label: 'Luxury' },
  { id: 'kids', label: 'Kids' },
  { id: 'memorial', label: 'Memorial' },
  { id: 'events', label: 'Events' },
  { id: 'script', label: 'Script' },
  { id: 'bold', label: 'Bold Display' },
];

/**
 * Get fonts filtered by category.
 */
export function getFontsByCategory(category: string): FontEntry[] {
  if (category === 'all') return FONT_CATALOG;
  return FONT_CATALOG.filter(f => f.categories.includes(category));
}

/**
 * Search fonts by name or category.
 */
export function searchFonts(query: string): FontEntry[] {
  const q = query.toLowerCase().trim();
  if (!q) return FONT_CATALOG;
  return FONT_CATALOG.filter(f =>
    f.label.toLowerCase().includes(q) ||
    f.categories.some(c => c.includes(q))
  );
}

/**
 * Build a Google Fonts CSS URL for the needed fonts.
 */
export function buildGoogleFontsUrl(families: string[]): string {
  if (families.length === 0) return '';
  const params = families
    .map(f => f.replace(/ /g, '+') + ':wght@300;400;500;600;700;800;900')
    .join('&family=');
  return `https://fonts.googleapis.com/css2?family=${params}&display=swap`;
}

/**
 * Get unique font families used in the catalog.
 */
export function getAllFontFamilies(): string[] {
  return [...new Set(FONT_CATALOG.map(f => f.family))];
}
