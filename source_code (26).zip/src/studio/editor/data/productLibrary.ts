/**
 * CUSTOM PRNTS — Product Library
 *
 * Expandable product database with viewpoint data for all product categories.
 * Each product has multiple clickable views (not 3D — lightweight 2D viewpoints).
 *
 * Architecture allows unlimited products to be added later.
 * Future-ready for 360° viewer support without redesigning the editor.
 */

// ═══════════════════════════════════════════════════════════════
// VIEWPOINT SYSTEM
// ═══════════════════════════════════════════════════════════════

export interface ProductViewpoint {
  id: string;
  label: string;
  /** Canvas dimensions for this view (design resolution) */
  canvasWidth: number;
  canvasHeight: number;
  /** Printable area within the canvas (where artwork can be placed) */
  printableArea: { x: number; y: number; width: number; height: number };
  /** Safe area within printable (recommended artwork bounds) */
  safeArea: { x: number; y: number; width: number; height: number };
  /** Physical maximum print dimensions in inches */
  physicalPrintArea: { maxWidthInches: number; maxHeightInches: number };
  /** Reference anchor points for smart placement */
  anchors: Record<string, { x: number; y: number; label: string }>;
  /** SVG path or description for the product silhouette in this view */
  silhouettePath?: string;
  /** Placeholder image URL for the product view (used during development) */
  placeholderUrl?: string;
}

export interface ProductColor {
  id: string;
  name: string;
  hex: string;
  isDark: boolean;
}

export interface ProductCategory {
  id: string;
  name: string;
  icon: string;
  order: number;
}

export interface ProductDefinition {
  id: string;
  name: string;
  categoryId: string;
  subcategory: string;
  viewpoints: ProductViewpoint[];
  colors: ProductColor[];
  supportedPrintMethods: string[];
  /** Default placement for new artwork */
  defaultPlacement: {
    widthRatio: number;
    topOffsetRatio: number;
    horizontalAnchor: 'center' | 'left' | 'right';
  };
  /** Real product mockup image URL (optional — falls back to colored shapes) */
  baseImageUrl?: string;
  /** SVG or image mask for clipping artwork onto the product shape */
  maskUrl?: string;
}

// ═══════════════════════════════════════════════════════════════
// CATEGORIES
// ═══════════════════════════════════════════════════════════════

export const PRODUCT_CATEGORIES: ProductCategory[] = [
  { id: 'tops', name: 'Tops', icon: '👕', order: 1 },
  { id: 'bottoms', name: 'Bottoms', icon: '👖', order: 2 },
  { id: 'headwear', name: 'Headwear', icon: '🧢', order: 3 },
  { id: 'accessories', name: 'Accessories', icon: '🎒', order: 4 },
  { id: 'drinkware', name: 'Drinkware', icon: '☕', order: 5 },
  { id: 'print', name: 'Print', icon: '🖼', order: 6 },
  { id: 'home', name: 'Home', icon: '🏠', order: 7 },
  { id: 'stationery', name: 'Stationery', icon: '📓', order: 8 },
  { id: 'tech', name: 'Tech', icon: '📱', order: 9 },
  { id: 'bags', name: 'Bags', icon: '👜', order: 10 },
];

// ═══════════════════════════════════════════════════════════════
// COLORS
// ═══════════════════════════════════════════════════════════════

const GARMENT_COLORS: ProductColor[] = [
  { id: 'black', name: 'Black', hex: '#111111', isDark: true },
  { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
  { id: 'charcoal', name: 'Charcoal', hex: '#36454F', isDark: true },
  { id: 'navy', name: 'Navy', hex: '#1B2A4A', isDark: true },
  { id: 'forest-green', name: 'Forest Green', hex: '#2D5A27', isDark: true },
  { id: 'maroon', name: 'Maroon', hex: '#800000', isDark: true },
  { id: 'red', name: 'Red', hex: '#C41E3A', isDark: false },
  { id: 'royal-blue', name: 'Royal Blue', hex: '#1E3A8A', isDark: true },
  { id: 'gold', name: 'Gold', hex: '#D4AF37', isDark: false },
  { id: 'tan', name: 'Tan', hex: '#C2B280', isDark: false },
  { id: 'grey', name: 'Grey', hex: '#808080', isDark: false },
  { id: 'pink', name: 'Pink', hex: '#FFB6C1', isDark: false },
  { id: 'cream', name: 'Cream', hex: '#FFFDD0', isDark: false },
  { id: 'olive', name: 'Olive', hex: '#808000', isDark: true },
  { id: 'rust', name: 'Rust', hex: '#B7410E', isDark: true },
  { id: 'sage', name: 'Sage', hex: '#9DC183', isDark: false },
];

const CERAMIC_COLORS: ProductColor[] = [
  { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
  { id: 'black', name: 'Black', hex: '#111111', isDark: true },
  { id: 'cream', name: 'Cream', hex: '#FFFDD0', isDark: false },
  { id: 'light-blue', name: 'Light Blue', hex: '#ADD8E6', isDark: false },
  { id: 'mint', name: 'Mint', hex: '#98FF98', isDark: false },
  { id: 'coral', name: 'Coral', hex: '#FF7F50', isDark: false },
];

const METAL_COLORS: ProductColor[] = [
  { id: 'stainless', name: 'Stainless', hex: '#C0C0C0', isDark: false },
  { id: 'matte-black', name: 'Matte Black', hex: '#28282B', isDark: true },
  { id: 'rose-gold', name: 'Rose Gold', hex: '#B76E79', isDark: false },
  { id: 'ocean-blue', name: 'Ocean Blue', hex: '#4F97A3', isDark: true },
  { id: 'forest', name: 'Forest', hex: '#228B22', isDark: true },
  { id: 'lilac', name: 'Lilac', hex: '#C8A2C8', isDark: false },
];

// ═══════════════════════════════════════════════════════════════
// VIEWPOINT TEMPLATES
// ═══════════════════════════════════════════════════════════════

/** Shirt-style viewpoints (t-shirts, hoodies, crewnecks, etc.) */
function createGarmentViews(hasSleeves: boolean = true): ProductViewpoint[] {
  const views: ProductViewpoint[] = [
    {
      id: 'front',
      label: 'Front',
      canvasWidth: 1000,
      canvasHeight: 1200,
      printableArea: { x: 150, y: 200, width: 700, height: 700 },
      safeArea: { x: 200, y: 250, width: 600, height: 600 },
      physicalPrintArea: { maxWidthInches: 12, maxHeightInches: 14 },
      anchors: {
        'center-chest': { x: 500, y: 400, label: 'Center Chest' },
        'left-chest': { x: 320, y: 350, label: 'Left Chest' },
        'right-chest': { x: 680, y: 350, label: 'Right Chest' },
        'upper-back': { x: 500, y: 300, label: 'Upper Back' },
      },
    },
    {
      id: 'back',
      label: 'Back',
      canvasWidth: 1000,
      canvasHeight: 1200,
      printableArea: { x: 150, y: 200, width: 700, height: 800 },
      safeArea: { x: 200, y: 250, width: 600, height: 700 },
      physicalPrintArea: { maxWidthInches: 12, maxHeightInches: 14 },
      anchors: {
        'center-back': { x: 500, y: 400, label: 'Center Back' },
        'upper-back': { x: 500, y: 300, label: 'Upper Back' },
        'lower-back': { x: 500, y: 700, label: 'Lower Back' },
      },
    },
  ];

  if (hasSleeves) {
    views.push(
      {
        id: 'left-sleeve',
        label: 'Left Sleeve',
        canvasWidth: 400,
        canvasHeight: 800,
        printableArea: { x: 50, y: 100, width: 300, height: 400 },
        safeArea: { x: 80, y: 150, width: 240, height: 300 },
        physicalPrintArea: { maxWidthInches: 4, maxHeightInches: 6 },
        anchors: {
          'center-sleeve': { x: 200, y: 300, label: 'Center Sleeve' },
        },
      },
      {
        id: 'right-sleeve',
        label: 'Right Sleeve',
        canvasWidth: 400,
        canvasHeight: 800,
        printableArea: { x: 50, y: 100, width: 300, height: 400 },
        safeArea: { x: 80, y: 150, width: 240, height: 300 },
        physicalPrintArea: { maxWidthInches: 4, maxHeightInches: 6 },
        anchors: {
          'center-sleeve': { x: 200, y: 300, label: 'Center Sleeve' },
        },
      }
    );
  }

  return views;
}

/** Hat viewpoints */
function createHatViews(): ProductViewpoint[] {
  return [
    {
      id: 'front',
      label: 'Front',
      canvasWidth: 800,
      canvasHeight: 600,
      printableArea: { x: 150, y: 100, width: 500, height: 300 },
      safeArea: { x: 200, y: 130, width: 400, height: 240 },
      physicalPrintArea: { maxWidthInches: 4.5, maxHeightInches: 2.5 },
      anchors: {
        'center-front': { x: 400, y: 250, label: 'Center Front' },
      },
    },
    {
      id: 'back',
      label: 'Back',
      canvasWidth: 800,
      canvasHeight: 600,
      printableArea: { x: 200, y: 100, width: 400, height: 200 },
      safeArea: { x: 240, y: 130, width: 320, height: 140 },
      physicalPrintArea: { maxWidthInches: 3.5, maxHeightInches: 1.5 },
      anchors: {
        'center-back': { x: 400, y: 200, label: 'Center Back' },
      },
    },
    {
      id: 'left',
      label: 'Left',
      canvasWidth: 500,
      canvasHeight: 600,
      printableArea: { x: 100, y: 150, width: 300, height: 200 },
      safeArea: { x: 130, y: 180, width: 240, height: 140 },
      physicalPrintArea: { maxWidthInches: 3, maxHeightInches: 2 },
      anchors: {
        'center-side': { x: 250, y: 250, label: 'Center Side' },
      },
    },
    {
      id: 'right',
      label: 'Right',
      canvasWidth: 500,
      canvasHeight: 600,
      printableArea: { x: 100, y: 150, width: 300, height: 200 },
      safeArea: { x: 130, y: 180, width: 240, height: 140 },
      physicalPrintArea: { maxWidthInches: 3, maxHeightInches: 2 },
      anchors: {
        'center-side': { x: 250, y: 250, label: 'Center Side' },
      },
    },
  ];
}

/** Mug viewpoints */
function createMugViews(): ProductViewpoint[] {
  return [
    {
      id: 'front',
      label: 'Front',
      canvasWidth: 1000,
      canvasHeight: 800,
      printableArea: { x: 150, y: 100, width: 700, height: 500 },
      safeArea: { x: 200, y: 150, width: 600, height: 400 },
      physicalPrintArea: { maxWidthInches: 8.5, maxHeightInches: 3.5 },
      anchors: {
        'center-mug': { x: 500, y: 350, label: 'Center Mug' },
      },
    },
    {
      id: 'back',
      label: 'Back',
      canvasWidth: 1000,
      canvasHeight: 800,
      printableArea: { x: 150, y: 100, width: 700, height: 500 },
      safeArea: { x: 200, y: 150, width: 600, height: 400 },
      physicalPrintArea: { maxWidthInches: 8.5, maxHeightInches: 3.5 },
      anchors: {
        'center-mug': { x: 500, y: 350, label: 'Center Mug' },
      },
    },
    {
      id: 'wrap',
      label: 'Full Wrap',
      canvasWidth: 2000,
      canvasHeight: 800,
      printableArea: { x: 100, y: 100, width: 1800, height: 500 },
      safeArea: { x: 200, y: 150, width: 1600, height: 400 },
      physicalPrintArea: { maxWidthInches: 9, maxHeightInches: 3.5 },
      anchors: {
        'center-wrap': { x: 1000, y: 350, label: 'Center Wrap' },
      },
    },
  ];
}

/** Tumbler viewpoints */
function createTumblerViews(): ProductViewpoint[] {
  return [
    {
      id: 'front',
      label: 'Front',
      canvasWidth: 600,
      canvasHeight: 1000,
      printableArea: { x: 75, y: 100, width: 450, height: 700 },
      safeArea: { x: 100, y: 150, width: 400, height: 600 },
      physicalPrintArea: { maxWidthInches: 9, maxHeightInches: 8 },
      anchors: {
        'center': { x: 300, y: 450, label: 'Center' },
      },
    },
    {
      id: 'back',
      label: 'Back',
      canvasWidth: 600,
      canvasHeight: 1000,
      printableArea: { x: 75, y: 100, width: 450, height: 700 },
      safeArea: { x: 100, y: 150, width: 400, height: 600 },
      physicalPrintArea: { maxWidthInches: 9, maxHeightInches: 8 },
      anchors: {
        'center': { x: 300, y: 450, label: 'Center' },
      },
    },
    {
      id: 'wrap',
      label: 'Full Wrap',
      canvasWidth: 1600,
      canvasHeight: 1000,
      printableArea: { x: 50, y: 100, width: 1500, height: 700 },
      safeArea: { x: 100, y: 150, width: 1400, height: 600 },
      physicalPrintArea: { maxWidthInches: 9.5, maxHeightInches: 8 },
      anchors: {
        'center-wrap': { x: 800, y: 450, label: 'Center Wrap' },
      },
    },
  ];
}

/** Canvas/Poster viewpoints */
function createCanvasViews(): ProductViewpoint[] {
  return [
    {
      id: 'front',
      label: 'Front',
      canvasWidth: 1000,
      canvasHeight: 1000,
      printableArea: { x: 50, y: 50, width: 900, height: 900 },
      safeArea: { x: 100, y: 100, width: 800, height: 800 },
      physicalPrintArea: { maxWidthInches: 24, maxHeightInches: 24 },
      anchors: {
        'center': { x: 500, y: 500, label: 'Center' },
      },
    },
  ];
}

/** Mouse pad viewpoints */
function createMousePadViews(): ProductViewpoint[] {
  return [
    {
      id: 'front',
      label: 'Front',
      canvasWidth: 1200,
      canvasHeight: 800,
      printableArea: { x: 30, y: 30, width: 1140, height: 740 },
      safeArea: { x: 60, y: 60, width: 1080, height: 680 },
      physicalPrintArea: { maxWidthInches: 10, maxHeightInches: 8 },
      anchors: {
        'center': { x: 600, y: 400, label: 'Center' },
      },
    },
  ];
}

/** Sticker viewpoints */
function createStickerViews(): ProductViewpoint[] {
  return [
    {
      id: 'front',
      label: 'Front',
      canvasWidth: 800,
      canvasHeight: 800,
      printableArea: { x: 50, y: 50, width: 700, height: 700 },
      safeArea: { x: 100, y: 100, width: 600, height: 600 },
      physicalPrintArea: { maxWidthInches: 4, maxHeightInches: 4 },
      anchors: {
        'center': { x: 400, y: 400, label: 'Center' },
      },
    },
  ];
}

/** Phone case viewpoints */
function createPhoneCaseViews(): ProductViewpoint[] {
  return [
    {
      id: 'back',
      label: 'Back',
      canvasWidth: 500,
      canvasHeight: 1000,
      printableArea: { x: 25, y: 50, width: 450, height: 900 },
      safeArea: { x: 50, y: 100, width: 400, height: 800 },
      physicalPrintArea: { maxWidthInches: 3.5, maxHeightInches: 7 },
      anchors: {
        'center': { x: 250, y: 500, label: 'Center' },
      },
    },
  ];
}

// ═══════════════════════════════════════════════════════════════
// PRODUCT DEFINITIONS
// ═══════════════════════════════════════════════════════════════

export const PRODUCT_LIBRARY: ProductDefinition[] = [
  // ── TOPS ──
  {
    id: 'adult-tshirt',
    name: 'Adult T-Shirt',
    categoryId: 'tops',
    subcategory: 'T-Shirts',
    viewpoints: createGarmentViews(true),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'DTG', 'Screen Print'],
    defaultPlacement: { widthRatio: 0.65, topOffsetRatio: 0.20, horizontalAnchor: 'center' },
    baseImageUrl: 'https://images.clothes.com/mockups/tshirt-base.png',
    maskUrl: 'https://images.clothes.com/mockups/tshirt-mask.png',
  },
  {
    id: 'oversized-tshirt',
    name: 'Oversized T-Shirt',
    categoryId: 'tops',
    subcategory: 'T-Shirts',
    viewpoints: createGarmentViews(true),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'DTG'],
    defaultPlacement: { widthRatio: 0.75, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
    baseImageUrl: 'https://images.clothes.com/mockups/oversized-base.png',
    maskUrl: 'https://images.clothes.com/mockups/oversized-mask.png',
  },
  {
    id: 'youth-tshirt',
    name: 'Youth T-Shirt',
    categoryId: 'tops',
    subcategory: 'T-Shirts',
    viewpoints: createGarmentViews(true),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'DTG', 'Screen Print'],
    defaultPlacement: { widthRatio: 0.60, topOffsetRatio: 0.22, horizontalAnchor: 'center' },
  },
  {
    id: 'hoodie',
    name: 'Hoodie',
    categoryId: 'tops',
    subcategory: 'Hoodies',
    viewpoints: createGarmentViews(true),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'DTG'],
    defaultPlacement: { widthRatio: 0.60, topOffsetRatio: 0.25, horizontalAnchor: 'center' },
    baseImageUrl: 'https://images.clothes.com/mockups/hoodie-base.png',
    maskUrl: 'https://images.clothes.com/mockups/hoodie-mask.png',
  },
  {
    id: 'crewneck',
    name: 'Crewneck Sweatshirt',
    categoryId: 'tops',
    subcategory: 'Sweatshirts',
    viewpoints: createGarmentViews(true),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'DTG'],
    defaultPlacement: { widthRatio: 0.60, topOffsetRatio: 0.22, horizontalAnchor: 'center' },
  },
  {
    id: 'long-sleeve',
    name: 'Long Sleeve',
    categoryId: 'tops',
    subcategory: 'Long Sleeves',
    viewpoints: createGarmentViews(true),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'DTG', 'Screen Print'],
    defaultPlacement: { widthRatio: 0.60, topOffsetRatio: 0.22, horizontalAnchor: 'center' },
  },
  {
    id: 'tank-top',
    name: 'Tank Top',
    categoryId: 'tops',
    subcategory: 'Tank Tops',
    viewpoints: createGarmentViews(false),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'DTG', 'Screen Print'],
    defaultPlacement: { widthRatio: 0.65, topOffsetRatio: 0.20, horizontalAnchor: 'center' },
  },
  {
    id: 'polo',
    name: 'Polo Shirt',
    categoryId: 'tops',
    subcategory: 'Polos',
    viewpoints: createGarmentViews(true),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'Embroidery'],
    defaultPlacement: { widthRatio: 0.25, topOffsetRatio: 0.18, horizontalAnchor: 'left' },
  },

  // ── HEADWEAR ──
  {
    id: 'dad-hat',
    name: 'Dad Hat',
    categoryId: 'headwear',
    subcategory: 'Hats',
    viewpoints: createHatViews(),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['Embroidery', 'DTF'],
    defaultPlacement: { widthRatio: 0.50, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },
  {
    id: 'snapback',
    name: 'Snapback',
    categoryId: 'headwear',
    subcategory: 'Hats',
    viewpoints: createHatViews(),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['Embroidery', 'DTF'],
    defaultPlacement: { widthRatio: 0.50, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },
  {
    id: 'beanie',
    name: 'Beanie',
    categoryId: 'headwear',
    subcategory: 'Beanies',
    viewpoints: [
      {
        id: 'front',
        label: 'Front',
        canvasWidth: 600,
        canvasHeight: 600,
        printableArea: { x: 150, y: 150, width: 300, height: 200 },
        safeArea: { x: 180, y: 180, width: 240, height: 140 },
        physicalPrintArea: { maxWidthInches: 3, maxHeightInches: 2 },
        anchors: {
          'center-front': { x: 300, y: 250, label: 'Center Front' },
        },
      },
      {
        id: 'back',
        label: 'Back',
        canvasWidth: 600,
        canvasHeight: 600,
        printableArea: { x: 150, y: 150, width: 300, height: 200 },
        safeArea: { x: 180, y: 180, width: 240, height: 140 },
        physicalPrintArea: { maxWidthInches: 3, maxHeightInches: 2 },
        anchors: {
          'center-back': { x: 300, y: 250, label: 'Center Back' },
        },
      },
    ],
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['Embroidery'],
    defaultPlacement: { widthRatio: 0.40, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },

  // ── DRINKWARE ──
  {
    id: 'ceramic-mug',
    name: 'Ceramic Mug',
    categoryId: 'drinkware',
    subcategory: 'Mugs',
    viewpoints: createMugViews(),
    colors: CERAMIC_COLORS,
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.60, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },
  {
    id: 'tumbler',
    name: 'Tumbler',
    categoryId: 'drinkware',
    subcategory: 'Tumblers',
    viewpoints: createTumblerViews(),
    colors: METAL_COLORS,
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.70, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },
  {
    id: 'travel-mug',
    name: 'Travel Mug',
    categoryId: 'drinkware',
    subcategory: 'Mugs',
    viewpoints: createTumblerViews(),
    colors: METAL_COLORS,
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.70, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },

  // ── ACCESSORIES ──
  {
    id: 'mouse-pad',
    name: 'Mouse Pad',
    categoryId: 'accessories',
    subcategory: 'Mouse Pads',
    viewpoints: createMousePadViews(),
    colors: [
      { id: 'black', name: 'Black', hex: '#111111', isDark: true },
      { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
    ],
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.80, topOffsetRatio: 0.10, horizontalAnchor: 'center' },
  },
  {
    id: 'apron',
    name: 'Apron',
    categoryId: 'accessories',
    subcategory: 'Aprons',
    viewpoints: createGarmentViews(false),
    colors: GARMENT_COLORS,
    supportedPrintMethods: ['DTF', 'Screen Print'],
    defaultPlacement: { widthRatio: 0.50, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },

  // ── PRINT ──
  {
    id: 'canvas-print',
    name: 'Canvas Print',
    categoryId: 'print',
    subcategory: 'Canvas',
    viewpoints: createCanvasViews(),
    colors: [
      { id: 'white', name: 'White Canvas', hex: '#f5f5f5', isDark: false },
    ],
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.85, topOffsetRatio: 0.05, horizontalAnchor: 'center' },
  },
  {
    id: 'banner',
    name: 'Banner',
    categoryId: 'print',
    subcategory: 'Banners',
    viewpoints: [
      {
        id: 'front',
        label: 'Front',
        canvasWidth: 1600,
        canvasHeight: 600,
        printableArea: { x: 30, y: 30, width: 1540, height: 540 },
        safeArea: { x: 80, y: 80, width: 1440, height: 440 },
        physicalPrintArea: { maxWidthInches: 48, maxHeightInches: 18 },
        anchors: {
          'center': { x: 800, y: 300, label: 'Center' },
        },
      },
    ],
    colors: [
      { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
      { id: 'black', name: 'Black', hex: '#111111', isDark: true },
    ],
    supportedPrintMethods: ['Sublimation', 'Screen Print'],
    defaultPlacement: { widthRatio: 0.70, topOffsetRatio: 0.10, horizontalAnchor: 'center' },
  },

  // ── HOME ──
  {
    id: 'throw-pillow',
    name: 'Throw Pillow',
    categoryId: 'home',
    subcategory: 'Pillows',
    viewpoints: [
      {
        id: 'front',
        label: 'Front',
        canvasWidth: 1000,
        canvasHeight: 1000,
        printableArea: { x: 50, y: 50, width: 900, height: 900 },
        safeArea: { x: 100, y: 100, width: 800, height: 800 },
        physicalPrintArea: { maxWidthInches: 18, maxHeightInches: 18 },
        anchors: {
          'center': { x: 500, y: 500, label: 'Center' },
        },
      },
    ],
    colors: [
      { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
      { id: 'cream', name: 'Cream', hex: '#FFFDD0', isDark: false },
      { id: 'grey', name: 'Grey', hex: '#808080', isDark: false },
      { id: 'navy', name: 'Navy', hex: '#1B2A4A', isDark: true },
    ],
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.70, topOffsetRatio: 0.10, horizontalAnchor: 'center' },
  },
  {
    id: 'blanket',
    name: 'Blanket',
    categoryId: 'home',
    subcategory: 'Blankets',
    viewpoints: [
      {
        id: 'front',
        label: 'Front',
        canvasWidth: 1400,
        canvasHeight: 1000,
        printableArea: { x: 50, y: 50, width: 1300, height: 900 },
        safeArea: { x: 100, y: 100, width: 1200, height: 800 },
        physicalPrintArea: { maxWidthInches: 60, maxHeightInches: 50 },
        anchors: {
          'center': { x: 700, y: 500, label: 'Center' },
        },
      },
    ],
    colors: [
      { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
      { id: 'cream', name: 'Cream', hex: '#FFFDD0', isDark: false },
    ],
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.60, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },

  // ── STATIONERY ──
  {
    id: 'journal',
    name: 'Journal',
    categoryId: 'stationery',
    subcategory: 'Journals',
    viewpoints: [
      {
        id: 'front',
        label: 'Front Cover',
        canvasWidth: 800,
        canvasHeight: 1000,
        printableArea: { x: 50, y: 50, width: 700, height: 900 },
        safeArea: { x: 100, y: 100, width: 600, height: 800 },
        physicalPrintArea: { maxWidthInches: 6, maxHeightInches: 8 },
        anchors: {
          'center': { x: 400, y: 500, label: 'Center' },
        },
      },
      {
        id: 'back',
        label: 'Back Cover',
        canvasWidth: 800,
        canvasHeight: 1000,
        printableArea: { x: 50, y: 50, width: 700, height: 900 },
        safeArea: { x: 100, y: 100, width: 600, height: 800 },
        physicalPrintArea: { maxWidthInches: 6, maxHeightInches: 8 },
        anchors: {
          'center': { x: 400, y: 500, label: 'Center' },
        },
      },
    ],
    colors: [
      { id: 'black', name: 'Black', hex: '#111111', isDark: true },
      { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
      { id: 'navy', name: 'Navy', hex: '#1B2A4A', isDark: true },
      { id: 'maroon', name: 'Maroon', hex: '#800000', isDark: true },
    ],
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.70, topOffsetRatio: 0.10, horizontalAnchor: 'center' },
  },

  // ── TECH ──
  {
    id: 'phone-case',
    name: 'Phone Case',
    categoryId: 'tech',
    subcategory: 'Phone Cases',
    viewpoints: createPhoneCaseViews(),
    colors: [
      { id: 'clear', name: 'Clear', hex: '#ffffff', isDark: false },
      { id: 'black', name: 'Black', hex: '#111111', isDark: true },
      { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
    ],
    supportedPrintMethods: ['Sublimation'],
    defaultPlacement: { widthRatio: 0.80, topOffsetRatio: 0.05, horizontalAnchor: 'center' },
  },

  // ── BAGS ──
  {
    id: 'tote-bag',
    name: 'Tote Bag',
    categoryId: 'bags',
    subcategory: 'Tote Bags',
    viewpoints: [
      {
        id: 'front',
        label: 'Front',
        canvasWidth: 1000,
        canvasHeight: 1100,
        printableArea: { x: 150, y: 200, width: 700, height: 600 },
        safeArea: { x: 200, y: 250, width: 600, height: 500 },
        physicalPrintArea: { maxWidthInches: 12, maxHeightInches: 10 },
        anchors: {
          'center': { x: 500, y: 500, label: 'Center' },
        },
      },
      {
        id: 'back',
        label: 'Back',
        canvasWidth: 1000,
        canvasHeight: 1100,
        printableArea: { x: 150, y: 200, width: 700, height: 600 },
        safeArea: { x: 200, y: 250, width: 600, height: 500 },
        physicalPrintArea: { maxWidthInches: 12, maxHeightInches: 10 },
        anchors: {
          'center': { x: 500, y: 500, label: 'Center' },
        },
      },
    ],
    colors: [
      { id: 'natural', name: 'Natural', hex: '#F5F5DC', isDark: false },
      { id: 'black', name: 'Black', hex: '#111111', isDark: true },
      { id: 'white', name: 'White', hex: '#f5f5f5', isDark: false },
      { id: 'navy', name: 'Navy', hex: '#1B2A4A', isDark: true },
    ],
    supportedPrintMethods: ['DTF', 'Screen Print', 'Sublimation'],
    defaultPlacement: { widthRatio: 0.60, topOffsetRatio: 0.15, horizontalAnchor: 'center' },
  },
];

// ═══════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

export function getProductById(id: string): ProductDefinition | undefined {
  return PRODUCT_LIBRARY.find(p => p.id === id);
}

export function getProductsByCategory(categoryId: string): ProductDefinition[] {
  return PRODUCT_LIBRARY.filter(p => p.categoryId === categoryId);
}

export function getCategoryById(id: string): ProductCategory | undefined {
  return PRODUCT_CATEGORIES.find(c => c.id === id);
}

export function getViewpoint(product: ProductDefinition, viewId: string): ProductViewpoint | undefined {
  return product.viewpoints.find(v => v.id === viewId);
}

export function getFirstViewpoint(product: ProductDefinition): ProductViewpoint {
  return product.viewpoints[0];
}

/** Map a legacy brief product type to the new product library ID */
export function mapBriefToProductId(productType: string): string {
  const map: Record<string, string> = {
    'T-Shirt': 'adult-tshirt',
    'Hoodie': 'hoodie',
    'Tank Top': 'tank-top',
  };
  return map[productType] || 'adult-tshirt';
}
