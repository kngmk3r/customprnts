/**
 * CUSTOM PRNTS Editor — Public API (v2)
 *
 * Exports all editor types, data, utilities, and components.
 */

// ═══════════════════════════════════════════════════════════════
// Types (existing)
// ═══════════════════════════════════════════════════════════════
export type {
  ProductTemplate, ProductView, ProductColor as LegacyProductColor, ProductArea, ProductAnchor,
  PlacementPreset, PlacementState,
  EditorObject, EditorImageObject, EditorTextObject, EditorObjectType,
  QualityState, QualityWarning, WarningSeverity,
  CanvasState, ProductState,
  EditorState, EditorViewMode, ProductViewId,
  DesignRevision, RevisionStatus,
  ProductionSpec, ProductionPackage,
} from './types';

// ═══════════════════════════════════════════════════════════════
// New Product Library Types
// ═══════════════════════════════════════════════════════════════
export type {
  ProductDefinition,
  ProductViewpoint,
  ProductColor,
  ProductCategory,
} from './data/productLibrary';

// ═══════════════════════════════════════════════════════════════
// Data — Legacy Templates
// ═══════════════════════════════════════════════════════════════
export { PRODUCT_TEMPLATES, getProductTemplate, getProductView, getPlacementPreset, getViewPresets, getProductColor, mapBriefProductType } from './data/productTemplates';

// ═══════════════════════════════════════════════════════════════
// Data — New Product Library
// ═══════════════════════════════════════════════════════════════
export {
  PRODUCT_LIBRARY,
  PRODUCT_CATEGORIES,
  getProductById,
  getProductsByCategory,
  getCategoryById,
  getViewpoint,
  getFirstViewpoint,
  mapBriefToProductId,
} from './data/productLibrary';

// ═══════════════════════════════════════════════════════════════
// Data — Fonts
// ═══════════════════════════════════════════════════════════════
export { FONT_CATALOG, FONT_CATEGORIES, getFontsByCategory, searchFonts } from './data/fontCatalog';

// ═══════════════════════════════════════════════════════════════
// Utils
// ═══════════════════════════════════════════════════════════════
export { pixelsToInches, inchesToPixels, calculateDpi, rateDpi, formatInches, formatDpi, getSnapPoints, snapValue } from './utils/measurementUtils';
export { runQualityChecks, getQualitySummary } from './utils/qualityChecker';
export { HistoryManager } from './utils/HistoryManager';
export { exportTransparentMaster, exportProductionSpec, exportEditorProject, buildProductionSpec, captureMockup } from './utils/exportManager';

// ═══════════════════════════════════════════════════════════════
// Overlay System
// ═══════════════════════════════════════════════════════════════
export type { OverlayConfig, OverlayType, OverlayRegistryEntry } from './overlaySystem';
export { OVERLAY_REGISTRY, getOverlayEntry, createOverlayConfig, createWatermarkOverlay, hasVisibleOverlays, getVisibleOverlays, isOverlayVisible, getOverlaySetting } from './overlaySystem';

// ═══════════════════════════════════════════════════════════════
// Components — Legacy
// ═══════════════════════════════════════════════════════════════
export { default as EditorShell } from './components/EditorShell';
export { default as OverlayLayer } from './components/OverlayLayer';

// ═══════════════════════════════════════════════════════════════
// Components — v2 (New Editor)
// ═══════════════════════════════════════════════════════════════
export { default as EditorLayout } from './components/v2/EditorLayout';
export { default as LeftToolbar } from './components/v2/LeftToolbar';
export { default as CenterCanvas } from './components/v2/CenterCanvas';
export { default as RightPanel } from './components/v2/RightPanel';
export { default as ProductBrowser } from './components/v2/ProductBrowser';
export { default as ViewpointBar } from './components/v2/ViewpointBar';
