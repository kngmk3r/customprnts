/**
 * CUSTOM PRNTS — Overlay Layer Component
 *
 * Renders non-destructive UI overlays above artwork.
 * Uses pointer-events: none so overlays never interfere with editing/zooming.
 * The original image is NEVER modified — overlays are purely visual CSS layers.
 */

import React, { useMemo } from 'react';
import type { OverlayConfig } from '../overlaySystem';
import { getOverlaySetting } from '../overlaySystem';

// ═══════════════════════════════════════════════════════════════
// PROPS
// ═══════════════════════════════════════════════════════════════

interface OverlayLayerProps {
  /** Array of overlay configurations to render */
  overlays: OverlayConfig[];
  /** Optional className for the container */
  className?: string;
  /** Optional style overrides */
  style?: React.CSSProperties;
}

// ═══════════════════════════════════════════════════════════════
// WATERMARK RENDERER — diagonal repeating text
// ═══════════════════════════════════════════════════════════════

function WatermarkOverlay({ config }: { config: OverlayConfig }) {
  const text = getOverlaySetting<string>(config, 'text', 'CUSTOM PRNTS');
  const rotation = getOverlaySetting<number>(config, 'rotation', -40);
  const opacity = getOverlaySetting<number>(config, 'opacity', 0.10);
  const fontSize = getOverlaySetting<number>(config, 'fontSize', 48);
  const color = getOverlaySetting<string>(config, 'color', '#ffffff');
  const spacingX = getOverlaySetting<number>(config, 'spacingX', 320);
  const spacingY = getOverlaySetting<number>(config, 'spacingY', 200);

  const watermarkStyle: React.CSSProperties = useMemo(() => ({
    position: 'absolute',
    inset: 0,
    overflow: 'hidden',
    pointerEvents: 'none',
    opacity,
    zIndex: 10,
  }), [opacity]);

  const textStyle: React.CSSProperties = useMemo(() => ({
    position: 'absolute',
    top: '-50%',
    left: '-50%',
    width: '300%',
    height: '300%',
    transform: `rotate(${rotation}deg)`,
    transformOrigin: 'center center',
    display: 'flex',
    flexWrap: 'wrap',
    alignContent: 'flex-start',
    gap: `${spacingY}px ${spacingX}px`,
    padding: '40px',
    boxSizing: 'border-box',
  }), [rotation, spacingX, spacingY]);

  // Generate enough repeated text to fill the area
  const repeatedText = useMemo(() => {
    const lines: string[] = [];
    // We need enough text to cover a 300% x 300% area
    for (let row = 0; row < 40; row++) {
      for (let col = 0; col < 8; col++) {
        lines.push(
          <span
            key={`${row}-${col}`}
            style={{
              fontFamily: "'Bebas Neue', 'Oswald', Impact, sans-serif",
              fontSize: `${fontSize}px`,
              fontWeight: 700,
              color,
              letterSpacing: '0.15em',
              textTransform: 'uppercase',
              whiteSpace: 'nowrap',
              userSelect: 'none',
              lineHeight: 1,
            }}
            aria-hidden="true"
          >
            {text}
          </span>
        );
      }
    }
    return lines;
  }, [text, fontSize, color]);

  return (
    <div style={watermarkStyle} aria-hidden="true">
      <div style={textStyle}>
        {repeatedText}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// ALIGNMENT GRID RENDERER
// ═══════════════════════════════════════════════════════════════

function AlignmentGridOverlay({ config }: { config: OverlayConfig }) {
  const gridSize = getOverlaySetting<number>(config, 'gridSize', 50);
  const color = getOverlaySetting<string>(config, 'color', '#ffffff');
  const opacity = getOverlaySetting<number>(config, 'opacity', 0.08);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        pointerEvents: 'none',
        opacity,
        zIndex: 10,
        backgroundImage: `
          linear-gradient(${color} 1px, transparent 1px),
          linear-gradient(90deg, ${color} 1px, transparent 1px)
        `,
        backgroundSize: `${gridSize}px ${gridSize}px`,
      }}
      aria-hidden="true"
    />
  );
}

// ═══════════════════════════════════════════════════════════════
// PRINT SAFE AREA / BLEED GUIDES / CROP MARKS RENDERERS
// ═══════════════════════════════════════════════════════════════

function PrintSafeAreaOverlay({ config }: { config: OverlayConfig }) {
  const color = getOverlaySetting<string>(config, 'color', '#22c55e');
  const opacity = getOverlaySetting<number>(config, 'opacity', 0.3);
  const dashPattern = getOverlaySetting<string>(config, 'dashPattern', '8,4');

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        pointerEvents: 'none',
        opacity,
        zIndex: 10,
        border: `2px dashed ${color}`,
        margin: '15%',
      }}
      aria-hidden="true"
    />
  );
}

function BleedGuidesOverlay({ config }: { config: OverlayConfig }) {
  const color = getOverlaySetting<string>(config, 'color', '#ef4444');
  const opacity = getOverlaySetting<number>(config, 'opacity', 0.4);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        pointerEvents: 'none',
        opacity,
        zIndex: 10,
        border: `1px solid ${color}`,
        margin: '5%',
      }}
      aria-hidden="true"
    />
  );
}

function CropMarksOverlay({ config }: { config: OverlayConfig }) {
  const color = getOverlaySetting<string>(config, 'color', '#000000');
  const opacity = getOverlaySetting<number>(config, 'opacity', 0.5);
  const length = getOverlaySetting<number>(config, 'length', 20);

  const markStyle = (top: boolean, left: boolean): React.CSSProperties => ({
    position: 'absolute',
    [top ? 'top' : 'bottom']: '10%',
    [left ? 'left' : 'right']: '10%',
    width: `${length}px`,
    height: `${length}px`,
    borderTop: top ? `2px solid ${color}` : 'none',
    borderBottom: !top ? `2px solid ${color}` : 'none',
    borderLeft: left ? `2px solid ${color}` : 'none',
    borderRight: !left ? `2px solid ${color}` : 'none',
  });

  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', opacity, zIndex: 10 }} aria-hidden="true">
      <div style={markStyle(true, true)} />
      <div style={markStyle(true, false)} />
      <div style={markStyle(false, true)} />
      <div style={markStyle(false, false)} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// GENERIC TEXT OVERLAY (for draft, sample, copyright, etc.)
// ═══════════════════════════════════════════════════════════════

function GenericTextOverlay({ config, textKey, defaultText, rotation = -30 }: {
  config: OverlayConfig;
  textKey: string;
  defaultText: string;
  rotation?: number;
}) {
  const text = getOverlaySetting<string>(config, textKey, defaultText) || defaultText;
  const opacity = getOverlaySetting<number>(config, 'opacity', 0.10);
  const fontSize = getOverlaySetting<number>(config, 'fontSize', 80);

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        pointerEvents: 'none',
        opacity,
        zIndex: 10,
      }}
      aria-hidden="true"
    >
      <span
        style={{
          fontFamily: "'Bebas Neue', 'Oswald', Impact, sans-serif",
          fontSize: `${fontSize}px`,
          fontWeight: 900,
          color: '#ffffff',
          letterSpacing: '0.2em',
          textTransform: 'uppercase',
          transform: `rotate(${rotation}deg)`,
          userSelect: 'none',
          whiteSpace: 'nowrap',
          textShadow: '0 2px 8px rgba(0,0,0,0.5)',
        }}
      >
        {text}
      </span>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// OVERLAY RENDERER DISPATCH
// ═══════════════════════════════════════════════════════════════

function OverlayRenderer({ overlay }: { overlay: OverlayConfig }) {
  switch (overlay.type) {
    case 'watermark':
      return <WatermarkOverlay config={overlay} />;
    case 'alignment-grid':
      return <AlignmentGridOverlay config={overlay} />;
    case 'print-safe-area':
      return <PrintSafeAreaOverlay config={overlay} />;
    case 'bleed-guides':
      return <BleedGuidesOverlay config={overlay} />;
    case 'crop-marks':
      return <CropMarksOverlay config={overlay} />;
    case 'copyright-preview':
      return <GenericTextOverlay config={overlay} textKey="text" defaultText="\u00a9 CUSTOM PRNTS" rotation={0} />;
    case 'draft':
      return <GenericTextOverlay config={overlay} textKey="text" defaultText="DRAFT" rotation={-30} />;
    case 'sample':
      return <GenericTextOverlay config={overlay} textKey="text" defaultText="SAMPLE" rotation={-25} />;
    case 'customer-name':
      return <GenericTextOverlay config={overlay} textKey="name" defaultText="" rotation={-20} />;
    case 'order-number':
      return <GenericTextOverlay config={overlay} textKey="orderNumber" defaultText="" rotation={-20} />;
    case 'measurement-guides':
      return <AlignmentGridOverlay config={{ ...overlay, config: { ...overlay.config, gridSize: 100, opacity: 0.15 } }} />;
    case 'qr-code':
    case 'production-notes':
      // Future: render QR code or notes panel
      return null;
    default:
      return null;
  }
}

// ═══════════════════════════════════════════════════════════════
// MAIN OVERLAY LAYER COMPONENT
// ═══════════════════════════════════════════════════════════════

/**
 * OverlayLayer renders all visible overlays above the artwork.
 * It MUST be placed as a sibling to the artwork element,
 * positioned absolutely to cover the artwork area.
 *
 * pointer-events: none ensures overlays never interfere with editing,
 * zooming, clicking, or touch interactions.
 *
 * The original artwork is NEVER touched, compressed, or modified.
 * Removing overlays is simply hiding this component.
 */
export default function OverlayLayer({ overlays, className, style }: OverlayLayerProps) {
  const visibleOverlays = useMemo(
    () => overlays.filter(o => o.visible),
    [overlays],
  );

  if (visibleOverlays.length === 0) return null;

  return (
    <div
      className={className}
      style={{
        position: 'absolute',
        inset: 0,
        pointerEvents: 'none',
        overflow: 'hidden',
        zIndex: 10,
        ...style,
      }}
      aria-hidden="true"
    >
      {visibleOverlays.map(overlay => (
        <OverlayRenderer key={overlay.id} overlay={overlay} />
      ))}
    </div>
  );
}
