/**
 * CUSTOM PRNTS — Right Panel (v2)
 *
 * Context-sensitive settings panel:
 * - Image selected → Position, Rotation, Scale, Crop, Opacity, Brightness, Contrast, Saturation, Remove BG
 * - Text selected → Font, Font Size, Outline, Shadow, Curve, Letter Spacing, Alignment
 * - Nothing selected → Product, Color, View, Print Area
 *
 * Only show settings for the selected object.
 */

import { useState, useMemo } from 'react';
import type { ProductDefinition, ProductViewpoint, ProductColor } from '../../data/productLibrary';
import { PRODUCT_CATEGORIES, getProductsByCategory } from '../../data/productLibrary';
import { STYLE_PRESETS, type FilterPreset } from '../../utils/imageEdits';

interface SelectedObject {
  id: string;
  type: 'image' | 'text' | 'shape';
  name: string;
  // ... rest same
  left: number;
  top: number;
  width: number;
  height: number;
  scaleX: number;
  scaleY: number;
  angle: number;
  opacity: number;
  flipX: boolean;
  flipY: boolean;
  src?: string;
  brightness?: number;
  contrast?: number;
  saturation?: number;
  text?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: string;
  fontStyle?: string;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  shadowColor?: string;
  shadowBlur?: number;
  letterSpacing?: number;
  textAlign?: string;
}

interface RightPanelProps {
  /** Currently selected object (null if nothing selected) */
  selectedObject: SelectedObject | null;
  /** Current product */
  product: ProductDefinition;
  /** Current view */
  currentView: ProductViewpoint;
  /** Current color */
  currentColor: ProductColor;
  /** Color options for current product */
  colors: ProductColor[];
  /** Placement measurements */
  placement: {
    widthInches: number;
    heightInches: number;
    topOffsetInches: number;
    horizontalOffsetInches: number;
  };
  // Callbacks
  onUpdateObject: (updates: Partial<SelectedObject>) => void;
  onRemoveBackground: () => void;
  onCropStart: () => void;
  onColorChange: (colorId: string) => void;
  onProductChange: (productId: string) => void;
  onPlacementChange: (field: string, value: number) => void;
}

export default function RightPanel({
  selectedObject,
  product,
  currentView,
  currentColor,
  colors,
  placement,
  onUpdateObject,
  onRemoveBackground,
  onCropStart,
  onColorChange,
  onProductChange,
  onPlacementChange,
}: RightPanelProps) {
  const [activeSection, setActiveSection] = useState<string | null>(null);

  // Determine what to show based on selection
  const panelMode = selectedObject
    ? selectedObject.type === 'text' ? 'text' : 'image'
    : 'product';

  return (
    <div className="w-60 bg-[#111111] border-l border-[#2a2a2a] flex flex-col overflow-hidden shrink-0">
      {/* Panel Header */}
      <div className="px-3 py-2.5 border-b border-[#2a2a2a]">
        <span className="font-condensed text-xs font-bold text-[#D4AF37] tracking-wider uppercase">
          {panelMode === 'image' ? 'Image' : panelMode === 'text' ? 'Text' : 'Product'}
        </span>
      </div>

      {/* Panel Content */}
      <div className="flex-1 overflow-y-auto">
        {/* ═══ IMAGE SETTINGS ═══ */}
        {panelMode === 'image' && selectedObject && (
          <div className="p-3 space-y-3">
            {/* Position */}
            <Section title="Position">
              <div className="grid grid-cols-2 gap-2">
                <NumberField
                  label="X"
                  value={Math.round(selectedObject.left)}
                  onChange={(v) => onUpdateObject({ left: v })}
                />
                <NumberField
                  label="Y"
                  value={Math.round(selectedObject.top)}
                  onChange={(v) => onUpdateObject({ top: v })}
                />
              </div>
            </Section>

            {/* Rotation */}
            <Section title="Rotation">
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min={-180}
                  max={180}
                  value={selectedObject.angle}
                  onChange={(e) => onUpdateObject({ angle: Number(e.target.value) })}
                  className="flex-1 accent-[#D4AF37]"
                />
                <span className="text-[10px] text-white font-mono w-10 text-right">
                  {Math.round(selectedObject.angle)}°
                </span>
              </div>
              <div className="flex gap-1 mt-1">
                {[0, 45, 90, 135, 180].map(deg => (
                  <button
                    key={deg}
                    onClick={() => onUpdateObject({ angle: deg })}
                    className="flex-1 py-1 rounded text-[8px] font-condensed font-bold tracking-wider bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white hover:border-[#D4AF37]/30 transition-colors"
                  >
                    {deg}°
                  </button>
                ))}
              </div>
            </Section>

            {/* Scale */}
            <Section title="Scale">
              <div className="grid grid-cols-2 gap-2">
                <NumberField
                  label="W"
                  value={Math.round(selectedObject.width * selectedObject.scaleX)}
                  onChange={(v) => onUpdateObject({ scaleX: v / selectedObject.width })}
                />
                <NumberField
                  label="H"
                  value={Math.round(selectedObject.height * selectedObject.scaleY)}
                  onChange={(v) => onUpdateObject({ scaleY: v / selectedObject.height })}
                />
              </div>
              <div className="flex gap-1 mt-1">
                <button
                  onClick={() => onUpdateObject({ scaleX: 0.5, scaleY: 0.5 })}
                  className="flex-1 py-1 rounded text-[8px] font-condensed font-bold tracking-wider bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white hover:border-[#D4AF37]/30 transition-colors"
                >
                  50%
                </button>
                <button
                  onClick={() => onUpdateObject({ scaleX: 1, scaleY: 1 })}
                  className="flex-1 py-1 rounded text-[8px] font-condensed font-bold tracking-wider bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white hover:border-[#D4AF37]/30 transition-colors"
                >
                  100%
                </button>
                <button
                  onClick={() => onUpdateObject({ scaleX: 1.5, scaleY: 1.5 })}
                  className="flex-1 py-1 rounded text-[8px] font-condensed font-bold tracking-wider bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white hover:border-[#D4AF37]/30 transition-colors"
                >
                  150%
                </button>
              </div>
            </Section>

            {/* Crop */}
            <Section title="Crop">
              <button
                onClick={onCropStart}
                className="w-full py-2 rounded-lg border border-[#2a2a2a] text-[10px] font-condensed font-bold tracking-wider uppercase text-[#737373] hover:text-white hover:bg-[#1a1a1a] hover:border-[#D4AF37]/30 transition-colors"
              >
                ⊞ Start Crop
              </button>
            </Section>

            {/* Opacity */}
            <Section title={`Opacity — ${Math.round(selectedObject.opacity * 100)}%`}>
              <input
                type="range"
                min={0}
                max={100}
                value={Math.round(selectedObject.opacity * 100)}
                onChange={(e) => onUpdateObject({ opacity: Number(e.target.value) / 100 })}
                className="w-full accent-[#D4AF37]"
              />
            </Section>

            {/* Styles */}
            <Section title="Style Presets">
              <div className="grid grid-cols-4 gap-2">
                {STYLE_PRESETS.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => onUpdateObject({ _cpFilterPreset: style.id } as any)}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <div className="w-10 h-10 rounded-lg bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-lg group-hover:border-[#D4AF37]/50 transition-all">
                      {style.thumbnail}
                    </div>
                    <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-[#737373] group-hover:text-white">
                      {style.name}
                    </span>
                  </button>
                ))}
              </div>
            </Section>

            {/* Adjustments (Now a disclosure) */}
            <details className="group">
              <summary className="list-none cursor-pointer flex items-center justify-between py-1">
                <span className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase">Fine Tune</span>
                <span className="text-[10px] text-[#737373] group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <div className="space-y-2 mt-2 pt-2 border-t border-[#2a2a2a]">
                <SliderField
                  label="Brightness"
                  value={selectedObject.brightness ?? 0}
                  min={-100}
                  max={100}
                  onChange={(v) => onUpdateObject({ brightness: v })}
                />
                <SliderField
                  label="Contrast"
                  value={selectedObject.contrast ?? 0}
                  min={-100}
                  max={100}
                  onChange={(v) => onUpdateObject({ contrast: v })}
                />
                <SliderField
                  label="Saturation"
                  value={selectedObject.saturation ?? 0}
                  min={-100}
                  max={100}
                  onChange={(v) => onUpdateObject({ saturation: v })}
                />
              </div>
            </details>

            {/* Remove Background */}
            <Section title="Background">
              <button
                onClick={onRemoveBackground}
                className="w-full py-2 rounded-lg border border-[#2a2a2a] text-[10px] font-condensed font-bold tracking-wider uppercase text-[#737373] hover:text-white hover:bg-[#1a1a1a] hover:border-[#D4AF37]/30 transition-colors"
              >
                ✂ Remove Background
              </button>
            </Section>
          </div>
        )}

        {/* ═══ TEXT SETTINGS ═══ */}
        {panelMode === 'text' && selectedObject && (
          <div className="p-3 space-y-3">
            {/* Font */}
            <Section title="Font">
              <select
                value={selectedObject.fontFamily || 'Oswald'}
                onChange={(e) => onUpdateObject({ fontFamily: e.target.value })}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded text-white text-sm font-body focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]/30"
              >
                {['Oswald', 'Bebas Neue', 'Anton', 'Montserrat', 'Playfair Display', 'Lobster', 'Permanent Marker', 'Poppins', 'Cinzel', 'Teko', 'Luckiest Guy', 'Righteous', 'Barlow Condensed'].map(f => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </Section>

            {/* Font Size */}
            <Section title={`Size — ${selectedObject.fontSize || 36}px`}>
              <input
                type="range"
                min={8}
                max={200}
                value={selectedObject.fontSize || 36}
                onChange={(e) => onUpdateObject({ fontSize: Number(e.target.value) })}
                className="w-full accent-[#D4AF37]"
              />
              <div className="flex gap-1 mt-1">
                {[12, 18, 24, 36, 48, 72].map(size => (
                  <button
                    key={size}
                    onClick={() => onUpdateObject({ fontSize: size })}
                    className="flex-1 py-1 rounded text-[8px] font-condensed font-bold tracking-wider bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white hover:border-[#D4AF37]/30 transition-colors"
                  >
                    {size}
                  </button>
                ))}
              </div>
            </Section>

            {/* Color */}
            <Section title="Color">
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={selectedObject.fill || '#FAFAFA'}
                  onChange={(e) => onUpdateObject({ fill: e.target.value })}
                  className="w-10 h-10 rounded border border-[#2a2a2a] cursor-pointer"
                />
                <span className="text-xs text-white font-mono">{selectedObject.fill || '#FAFAFA'}</span>
              </div>
            </Section>

            {/* Style */}
            <Section title="Style">
              <div className="flex gap-1">
                <button
                  onClick={() => onUpdateObject({ fontWeight: selectedObject.fontWeight === 'bold' ? 'normal' : 'bold' })}
                  className={`flex-1 py-2 rounded text-sm font-bold transition-colors ${
                    selectedObject.fontWeight === 'bold'
                      ? 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30'
                      : 'bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white'
                  }`}
                >
                  B
                </button>
                <button
                  onClick={() => onUpdateObject({ fontStyle: selectedObject.fontStyle === 'italic' ? 'normal' : 'italic' })}
                  className={`flex-1 py-2 rounded text-sm italic transition-colors ${
                    selectedObject.fontStyle === 'italic'
                      ? 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30'
                      : 'bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white'
                  }`}
                >
                  I
                </button>
                <button
                  onClick={() => onUpdateObject({ textTransform: 'uppercase' })}
                  className="flex-1 py-2 rounded text-xs font-condensed font-bold bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white transition-colors"
                >
                  AA
                </button>
              </div>
            </Section>

            {/* Outline */}
            <Section title="Outline">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase block mb-1">Color</label>
                  <input
                    type="color"
                    value={selectedObject.stroke || '#000000'}
                    onChange={(e) => onUpdateObject({ stroke: e.target.value })}
                    className="w-full h-8 rounded border border-[#2a2a2a] cursor-pointer"
                  />
                </div>
                <NumberField
                  label="Width"
                  value={selectedObject.strokeWidth || 0}
                  onChange={(v) => onUpdateObject({ strokeWidth: v })}
                />
              </div>
            </Section>

            {/* Shadow */}
            <Section title="Shadow">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase block mb-1">Color</label>
                  <input
                    type="color"
                    value={selectedObject.shadowColor || '#000000'}
                    onChange={(e) => onUpdateObject({ shadowColor: e.target.value })}
                    className="w-full h-8 rounded border border-[#2a2a2a] cursor-pointer"
                  />
                </div>
                <NumberField
                  label="Blur"
                  value={selectedObject.shadowBlur || 0}
                  onChange={(v) => onUpdateObject({ shadowBlur: v })}
                />
              </div>
            </Section>

            {/* Letter Spacing */}
            <Section title="Letter Spacing">
              <input
                type="range"
                min={-10}
                max={50}
                value={selectedObject.letterSpacing || 0}
                onChange={(e) => onUpdateObject({ letterSpacing: Number(e.target.value) })}
                className="w-full accent-[#D4AF37]"
              />
              <span className="text-[10px] text-white font-mono">{selectedObject.letterSpacing || 0}px</span>
            </Section>

            {/* Alignment */}
            <Section title="Alignment">
              <div className="flex gap-1">
                {[
                  { value: 'left', icon: '≡' },
                  { value: 'center', icon: '≡' },
                  { value: 'right', icon: '≡' },
                ].map(align => (
                  <button
                    key={align.value}
                    onClick={() => onUpdateObject({ textAlign: align.value })}
                    className={`flex-1 py-2 rounded text-sm transition-colors ${
                      selectedObject.textAlign === align.value
                        ? 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30'
                        : 'bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white'
                    }`}
                  >
                    {align.icon}
                  </button>
                ))}
              </div>
            </Section>
          </div>
        )}

        {/* ═══ PRODUCT SETTINGS (nothing selected) ═══ */}
        {panelMode === 'product' && (
          <div className="p-3 space-y-3">
            {/* Product */}
            <Section title="Product">
              <select
                value={product.id}
                onChange={(e) => onProductChange(e.target.value)}
                className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded text-white text-sm font-body focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]/30"
              >
                {PRODUCT_CATEGORIES.map(cat => (
                  <optgroup key={cat.id} label={`${cat.icon} ${cat.name}`}>
                    {getProductsByCategory(cat.id).map(p => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </Section>

            {/* Color */}
            <Section title="Color">
              <div className="flex flex-wrap gap-2">
                {colors.map(color => (
                  <button
                    key={color.id}
                    onClick={() => onColorChange(color.id)}
                    className={`w-8 h-8 rounded-lg border-2 transition-all flex items-center justify-center ${
                      color.id === currentColor.id
                        ? 'border-[#D4AF37] scale-110'
                        : 'border-[#2a2a2a] hover:border-[#D4AF37]/50'
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                    aria-label={`Select ${color.name} color`}
                  >
                    {color.id === currentColor.id && (
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                        stroke={color.isDark ? '#ffffff' : '#111111'} strokeWidth="3"
                      >
                        <path d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </button>
                ))}
              </div>
            </Section>

            {/* View */}
            <Section title="View">
              <div className="grid grid-cols-2 gap-1">
                {product.viewpoints.map(view => (
                  <button
                    key={view.id}
                    onClick={() => onPlacementChange('view', view.id as any)}
                    className={`py-2 px-2 rounded text-[10px] font-condensed font-bold uppercase tracking-wider transition-all ${
                      view.id === currentView.id
                        ? 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30'
                        : 'bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white'
                    }`}
                  >
                    {view.label}
                  </button>
                ))}
              </div>
            </Section>

            {/* Smart Layouts */}
            <Section title="Smart Layouts">
              <div className="space-y-1">
                <button
                  onClick={() => onPlacementChange('smart-layout', 'center-chest' as any)}
                  className="w-full py-2 px-3 rounded bg-[#1a1a1a] border border-[#2a2a2a] text-[10px] font-condensed font-bold text-left hover:border-[#D4AF37]/50 transition-all flex justify-between items-center group/btn"
                >
                  <span>Center Chest</span>
                  <span className="text-[#D4AF37] opacity-60 group-hover/btn:opacity-100">10" Wide</span>
                </button>
                <button
                  onClick={() => onPlacementChange('smart-layout', 'left-chest' as any)}
                  className="w-full py-2 px-3 rounded bg-[#1a1a1a] border border-[#2a2a2a] text-[10px] font-condensed font-bold text-left hover:border-[#D4AF37]/50 transition-all flex justify-between items-center group/btn"
                >
                  <span>Left Chest</span>
                  <span className="text-[#D4AF37] opacity-60 group-hover/btn:opacity-100">3.5" Wide</span>
                </button>
                <button
                  onClick={() => onPlacementChange('smart-layout', 'full-back' as any)}
                  className="w-full py-2 px-3 rounded bg-[#1a1a1a] border border-[#2a2a2a] text-[10px] font-condensed font-bold text-left hover:border-[#D4AF37]/50 transition-all flex justify-between items-center group/btn"
                >
                  <span>Full Back</span>
                  <span className="text-[#D4AF37] opacity-60 group-hover/btn:opacity-100">12" Wide</span>
                </button>
              </div>
            </Section>

            {/* Placement */}
            <Section title="Placement">
              <div className="space-y-2">
                <div>
                  <label className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase block mb-1">
                    Width: {placement.widthInches.toFixed(1)}"
                  </label>
                  <input
                    type="range"
                    min={1}
                    max={currentView.physicalPrintArea.maxWidthInches}
                    step={0.1}
                    value={placement.widthInches}
                    onChange={(e) => onPlacementChange('width', Number(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>
                <div>
                  <label className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase block mb-1">
                    Top Offset: {placement.topOffsetInches.toFixed(1)}"
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={currentView.physicalPrintArea.maxHeightInches}
                    step={0.1}
                    value={placement.topOffsetInches}
                    onChange={(e) => onPlacementChange('topOffset', Number(e.target.value))}
                    className="w-full accent-[#D4AF37]"
                  />
                </div>
              </div>
            </Section>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase mb-1.5">
        {title}
      </h4>
      {children}
    </div>
  );
}

function NumberField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <label className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase block mb-1">{label}</label>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full px-2 py-1.5 bg-[#1a1a1a] border border-[#2a2a2a] rounded text-white text-xs font-mono focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]/30"
      />
    </div>
  );
}

function SliderField({ label, value, min, max, onChange }: {
  label: string; value: number; min: number; max: number; onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <label className="text-[9px] text-[#737373] font-condensed tracking-wider uppercase">{label}</label>
        <span className="text-[10px] text-white font-mono">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-[#D4AF37]"
      />
    </div>
  );
}

function PropRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[10px] text-[#737373] font-condensed uppercase tracking-wider">{label}</span>
      <span className="text-[10px] text-white font-mono">{value}</span>
    </div>
  );
}
