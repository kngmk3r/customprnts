/**
 * CUSTOM PRNTS — Left Toolbar (v2)
 *
 * Minimal toolbar with exactly 5 tools:
 * AI, Upload, Text, Shapes, Layers
 *
 * Progressive disclosure: advanced layer controls (lock, delete, reorder)
 * are only visible when a layer is selected.
 */

import { useState } from 'react';

type ToolId = 'ai' | 'upload' | 'text' | 'shapes' | 'layers';

interface LeftToolbarProps {
  activeTool: ToolId | null;
  onSelectTool: (tool: ToolId | null) => void;
  onAddText: () => void;
  onAddShape: (shape: string) => void;
  onUploadImage: (file: File) => void;
  /** Layer data from canvas */
  layers: Array<{
    id: string;
    name: string;
    type: string;
    visible: boolean;
    locked: boolean;
    selected: boolean;
  }>;
  /** Whether any object is selected on canvas */
  hasSelection: boolean;
  onSelectLayer: (id: string) => void;
  onToggleLayerVisibility: (id: string) => void;
  onToggleLayerLock: (id: string) => void;
  onDeleteLayer: (id: string) => void;
  onReorderLayer: (id: string, direction: 'up' | 'down') => void;
  /** Group/Ungroup — available when 2+ objects are selected */
  onGroupSelected?: () => void;
  onUngroupSelected?: () => void;
  /** Whether multiple objects are selected (for group) */
  hasMultipleSelection?: boolean;
  /** Whether a group is selected (for ungroup) */
  hasGroupSelected?: boolean;
}

const TOOLS: Array<{ id: ToolId; label: string; icon: string; description: string }> = [
  { id: 'ai', label: 'AI', icon: '✨', description: 'Generate designs with AI' },
  { id: 'upload', label: 'Upload', icon: '↑', description: 'Upload your own artwork' },
  { id: 'text', label: 'Text', icon: 'T', description: 'Add custom text' },
  { id: 'shapes', label: 'Shapes', icon: '◆', description: 'Add shapes & elements' },
  { id: 'layers', label: 'Layers', icon: '☰', description: 'Manage layers' },
];

const SHAPES = [
  { id: 'rect', label: 'Rectangle', icon: '□' },
  { id: 'circle', label: 'Circle', icon: '○' },
  { id: 'triangle', label: 'Triangle', icon: '△' },
  { id: 'star', label: 'Star', icon: '☆' },
  { id: 'line', label: 'Line', icon: '—' },
];

export default function LeftToolbar({
  activeTool,
  onSelectTool,
  onAddText,
  onAddShape,
  onUploadImage,
  layers,
  hasSelection,
  onSelectLayer,
  onToggleLayerVisibility,
  onToggleLayerLock,
  onDeleteLayer,
  onReorderLayer,
  onGroupSelected,
  onUngroupSelected,
  hasMultipleSelection = false,
  hasGroupSelected = false,
}: LeftToolbarProps) {
  const [showAIPanel, setShowAIPanel] = useState(false);
  const [refinePrompt, setShowRefinePrompt] = useState('');

  const handleToolClick = (toolId: ToolId) => {
    if (activeTool === toolId) {
      onSelectTool(null);
    } else {
      onSelectTool(toolId);
      // Execute immediate actions
      if (toolId === 'text') {
        onAddText();
        onSelectTool(null);
      }
      if (toolId === 'upload') {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/png,image/jpeg,image/webp,image/svg+xml';
        input.onchange = (e) => {
          const file = (e.target as HTMLInputElement).files?.[0];
          if (file) onUploadImage(file);
        };
        input.click();
        onSelectTool(null);
      }
    }
  };

  const selectedLayer = layers.find(l => l.selected);
  const selectedIndex = selectedLayer ? layers.indexOf(selectedLayer) : -1;

  return (
    <div className="flex h-full">
      {/* Icon Rail — 56px wide, always visible */}
      <div className="w-14 bg-[#0d0d0d] border-r border-[#2a2a2a] flex flex-col items-center py-2 gap-1 shrink-0">
        {TOOLS.map((tool) => (
          <button
            key={tool.id}
            onClick={() => handleToolClick(tool.id)}
            className={`
              w-10 h-10 rounded-lg flex items-center justify-center text-sm font-condensed font-bold
              transition-all duration-150 relative group
              ${activeTool === tool.id
                ? 'bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30'
                : 'text-[#737373] hover:text-white hover:bg-[#1a1a1a] border border-transparent'
              }
            `}
            title={tool.label}
            aria-label={tool.description}
          >
            <span className="text-base">{tool.icon}</span>
            {/* Tooltip */}
            <div className="
              absolute left-full ml-2 px-2 py-1 rounded
              bg-[#1a1a1a] border border-[#2a2a2a]
              text-xs text-white font-condensed tracking-wider uppercase
              whitespace-nowrap opacity-0 pointer-events-none
              group-hover:opacity-100 transition-opacity z-50
            ">
              {tool.label}
            </div>
          </button>
        ))}

        {/* Group/Ungroup Quick Actions (Floating in Rail when applicable) */}
        {(hasMultipleSelection || hasGroupSelected) && (
          <div className="mt-auto mb-2 flex flex-col gap-1">
            {hasMultipleSelection && onGroupSelected && (
              <button
                onClick={onGroupSelected}
                className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#D4AF37] text-[#0d0d0d] hover:bg-[#E8CC6E] transition-all"
                title="Group Selected"
              >
                <span className="text-lg">📂</span>
              </button>
            )}
            {hasGroupSelected && onUngroupSelected && (
              <button
                onClick={onUngroupSelected}
                className="w-10 h-10 rounded-lg flex items-center justify-center bg-[#1a1a1a] border border-[#2a2a2a] text-[#737373] hover:text-white transition-all"
                title="Ungroup"
              >
                <span className="text-lg">🔓</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Panel Area — shows content for active tool */}
      {activeTool && (
        <div className="w-56 bg-[#111111] border-r border-[#2a2a2a] flex flex-col overflow-hidden shrink-0">
          {/* Panel Header */}
          <div className="px-3 py-2.5 border-b border-[#2a2a2a] flex items-center justify-between">
            <span className="font-condensed text-xs font-bold text-[#D4AF37] tracking-wider uppercase">
              {TOOLS.find(t => t.id === activeTool)?.label}
            </span>
            <button
              onClick={() => onSelectTool(null)}
              className="w-6 h-6 flex items-center justify-center rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors"
              aria-label="Close panel"
            >
              ✕
            </button>
          </div>

          {/* Panel Content */}
          <div className="flex-1 overflow-y-auto">
            {/* AI Panel */}
            {activeTool === 'ai' && (
              <div className="p-3 space-y-4">
                <div>
                  <h3 className="font-condensed text-xs font-bold text-white tracking-wider uppercase mb-1.5">Refine with AI</h3>
                  <p className="text-[10px] text-[#737373] font-body leading-relaxed mb-3">
                    Select an object on the canvas and describe how you want to change it.
                  </p>
                  <div className="space-y-2">
                    <textarea
                      placeholder="e.g. Change the cat to a dragon..."
                      value={refinePrompt}
                      onChange={(e) => setShowRefinePrompt(e.target.value)}
                      className="w-full px-3 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg text-white text-sm font-body placeholder:text-[#737373]/50 focus:outline-none focus:border-[#D4AF37] focus:ring-1 focus:ring-[#D4AF37]/30 resize-none"
                      rows={3}
                    />
                    <button 
                      onClick={() => {
                        if (refinePrompt.trim()) {
                          showToast('AI is refining your selection...', 'success');
                          // Simulate AI refinement work
                          setTimeout(() => {
                            showToast('Refinement complete!', 'success');
                            setShowRefinePrompt('');
                          }, 2500);
                        } else {
                          showToast('Please describe the change first', 'error');
                        }
                      }}
                      className="w-full mt-2 py-2.5 px-3 rounded-lg bg-[#D4AF37] text-[#0d0d0d] font-condensed text-xs font-bold tracking-wider uppercase transition-all hover:bg-[#E8CC6E] active:scale-95 disabled:opacity-50"
                      disabled={!hasSelection}
                    >
                      ✨ Refine Selected
                    </button>
                  </div>
                </div>

                <div className="pt-4 border-t border-[#2a2a2a]">
                  <h3 className="font-condensed text-xs font-bold text-white tracking-wider uppercase mb-1.5">Generate New</h3>
                  <button className="w-full py-2 px-3 rounded-lg border border-[#2a2a2a] text-[10px] font-condensed font-bold tracking-wider uppercase text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-all">
                    Restart Interview
                  </button>
                </div>
              </div>
            )}

            {/* Upload Panel */}
            {activeTool === 'upload' && (
              <div className="p-3">
                <div className="
                  border-2 border-dashed border-[#2a2a2a] rounded-xl p-6
                  flex flex-col items-center justify-center text-center
                  hover:border-[#D4AF37]/30 transition-colors cursor-pointer
                " onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = 'image/png,image/jpeg,image/webp,image/svg+xml';
                  input.onchange = (e) => {
                    const file = (e.target as HTMLInputElement).files?.[0];
                    if (file) onUploadImage(file);
                  };
                  input.click();
                }}>
                  <div className="w-12 h-12 rounded-full bg-[#D4AF37]/10 border border-[#D4AF37]/20 flex items-center justify-center mb-3">
                    <span className="text-[#D4AF37] text-xl">↑</span>
                  </div>
                  <p className="font-condensed text-xs font-bold text-white tracking-wider uppercase mb-1">
                    Drop image here
                  </p>
                  <p className="text-[10px] text-[#737373] font-body">
                    PNG, JPG, SVG, or WebP
                  </p>
                </div>
              </div>
            )}

            {/* Shapes Panel */}
            {activeTool === 'shapes' && (
              <div className="p-3">
                <div className="grid grid-cols-2 gap-2">
                  {SHAPES.map(shape => (
                    <button
                      key={shape.id}
                      onClick={() => {
                        onAddShape(shape.id);
                        onSelectTool(null);
                      }}
                      className="
                        py-3 px-2 rounded-lg border border-[#2a2a2a]
                        flex flex-col items-center justify-center gap-1.5
                        text-[#737373] hover:text-white hover:bg-[#1a1a1a] hover:border-[#D4AF37]/30
                        transition-all
                      "
                    >
                      <span className="text-xl">{shape.icon}</span>
                      <span className="text-[9px] font-condensed font-bold tracking-wider uppercase">{shape.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Layers Panel — Progressive Disclosure */}
            {activeTool === 'layers' && (
              <div className="flex flex-col h-full">
                {/* Group/Ungroup Actions — visible only with multi-selection */}
                {(hasMultipleSelection || hasGroupSelected) && (
                  <div className="px-3 py-2 border-b border-[#2a2a2a] flex items-center gap-2">
                    {hasMultipleSelection && onGroupSelected && (
                      <button
                        onClick={onGroupSelected}
                        className="flex-1 py-1.5 px-2 rounded text-[9px] font-condensed font-bold tracking-wider uppercase text-[#D4AF37] bg-[#D4AF37]/10 hover:bg-[#D4AF37]/20 transition-colors"
                      >
                        Group
                      </button>
                    )}
                    {hasGroupSelected && onUngroupSelected && (
                      <button
                        onClick={onUngroupSelected}
                        className="flex-1 py-1.5 px-2 rounded text-[9px] font-condensed font-bold tracking-wider uppercase text-[#737373] bg-[#1a1a1a] hover:bg-[#2a2a2a] transition-colors"
                      >
                        Ungroup
                      </button>
                    )}
                  </div>
                )}

                <div className="flex-1 overflow-y-auto">
                  {layers.length === 0 ? (
                    <div className="p-4 text-center">
                      <p className="text-[10px] text-[#737373] font-condensed uppercase tracking-wider">
                        No layers yet
                      </p>
                    </div>
                  ) : (
                    <div className="py-1">
                      {layers.map((layer, index) => (
                        <div
                          key={layer.id}
                          onClick={() => onSelectLayer(layer.id)}
                          className={`
                            flex items-center gap-2 px-3 py-2 cursor-pointer transition-colors
                            ${layer.selected
                              ? 'bg-[#D4AF37]/10 border-l-2 border-[#D4AF37]'
                              : 'hover:bg-[#1a1a1a] border-l-2 border-transparent'
                            }
                          `}
                        >
                          {/* Visibility toggle — always visible */}
                          <button
                            onClick={(e) => { e.stopPropagation(); onToggleLayerVisibility(layer.id); }}
                            className={`w-5 h-5 flex items-center justify-center rounded text-[10px] transition-colors ${
                              layer.visible ? 'text-[#D4AF37]' : 'text-[#737373]/40'
                            }`}
                            aria-label={layer.visible ? 'Hide layer' : 'Show layer'}
                          >
                            {layer.visible ? '👁' : '—'}
                          </button>

                          {/* Layer info */}
                          <div className="flex-1 min-w-0">
                            <p className={`text-[11px] font-condensed tracking-wider uppercase truncate ${
                              layer.selected ? 'text-white' : 'text-[#737373]'
                            }`}>
                              {layer.name}
                            </p>
                            <p className="text-[9px] text-[#737373]/60 font-body capitalize">
                              {layer.type}
                            </p>
                          </div>

                          {/* Advanced controls — progressive disclosure: only when layer is selected */}
                          {layer.selected && (
                            <>
                              {/* Reorder */}
                              <div className="flex flex-col gap-0.5">
                                <button
                                  onClick={(e) => { e.stopPropagation(); onReorderLayer(layer.id, 'up'); }}
                                  className="w-4 h-4 flex items-center justify-center rounded text-[8px] text-[#737373]/60 hover:text-white transition-colors"
                                  aria-label="Move layer up"
                                >
                                  ▲
                                </button>
                                <button
                                  onClick={(e) => { e.stopPropagation(); onReorderLayer(layer.id, 'down'); }}
                                  className="w-4 h-4 flex items-center justify-center rounded text-[8px] text-[#737373]/60 hover:text-white transition-colors"
                                  aria-label="Move layer down"
                                >
                                  ▼
                                </button>
                              </div>

                              {/* Lock toggle */}
                              <button
                                onClick={(e) => { e.stopPropagation(); onToggleLayerLock(layer.id); }}
                                className={`w-5 h-5 flex items-center justify-center rounded text-[10px] transition-colors ${
                                  layer.locked ? 'text-[#ef4444]' : 'text-[#737373]/40'
                                }`}
                                aria-label={layer.locked ? 'Unlock layer' : 'Lock layer'}
                              >
                                {layer.locked ? '🔒' : '🔓'}
                              </button>

                              {/* Delete */}
                              <button
                                onClick={(e) => { e.stopPropagation(); onDeleteLayer(layer.id); }}
                                className="w-5 h-5 flex items-center justify-center rounded text-[10px] text-[#737373]/40 hover:text-[#ef4444] transition-colors"
                                aria-label="Delete layer"
                              >
                                ✕
                              </button>
                            </>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
