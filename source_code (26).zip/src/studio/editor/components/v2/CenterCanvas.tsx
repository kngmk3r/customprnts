/**
 * CUSTOM PRNTS — Center Canvas (v2)
 *
 * Large product preview with:
 * - Artwork placement
 * - Print boundary visualization
 * - Safe area indicators
 * - Snap guides
 * - Zoom controls
 * - Viewpoint switching bar
 *
 * This is the heart of the editor.
 */

import { useRef, useEffect, useCallback, useState, useMemo } from 'react';
import type { ProductDefinition, ProductViewpoint } from '../../data/productLibrary';
import ViewpointBar from './ViewpointBar';

interface CenterCanvasProps {
  product: ProductDefinition;
  currentViewId: string;
  productColor: string;
  onViewChange: (viewId: string) => void;
  /** Fabric.js canvas ref */
  canvasRef: React.RefObject<HTMLCanvasElement>;
  /** Canvas ready callback */
  onCanvasReady: () => void;
  /** Whether snap guides are enabled */
  snapEnabled: boolean;
  /** Whether to show print boundaries */
  showBoundaries: boolean;
  /** Zoom level */
  zoom: number;
  onZoomChange: (zoom: number) => void;
  /** Whether we're in artwork-only mode (no product overlay) */
  artworkMode: boolean;
}

export default function CenterCanvas({
  product,
  currentViewId,
  productColor,
  onViewChange,
  canvasRef,
  onCanvasReady,
  snapEnabled,
  showBoundaries,
  zoom,
  onZoomChange,
  artworkMode,
}: CenterCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isReady, setIsReady] = useState(false);

  const currentView = useMemo(
    () => product.viewpoints.find(v => v.id === currentViewId) || product.viewpoints[0],
    [product, currentViewId]
  );

  // Canvas dimensions based on current view
  const canvasWidth = currentView.canvasWidth;
  const canvasHeight = currentView.canvasHeight;

  // Calculate display size to fit container while maintaining aspect ratio
  const [displaySize, setDisplaySize] = useState({ width: canvasWidth, height: canvasHeight });

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const updateSize = () => {
      const rect = container.getBoundingClientRect();
      const padding = 48; // 24px padding each side
      const availableWidth = rect.width - padding;
      const availableHeight = rect.height - padding;

      const scaleX = availableWidth / canvasWidth;
      const scaleY = availableHeight / canvasHeight;
      const scale = Math.min(scaleX, scaleY, 1); // Don't scale up beyond 100%

      setDisplaySize({
        width: canvasWidth * scale,
        height: canvasHeight * scale,
      });
    };

    updateSize();
    const observer = new ResizeObserver(updateSize);
    observer.observe(container);
    return () => observer.disconnect();
  }, [canvasWidth, canvasHeight]);

  // Notify canvas ready
  useEffect(() => {
    if (canvasRef.current && !isReady) {
      setIsReady(true);
      onCanvasReady();
    }
  }, [canvasRef.current]); // eslint-disable-line react-hooks/exhaustive-deps

  // Zoom handlers
  const handleZoomIn = useCallback(() => {
    onZoomChange(Math.min(zoom + 0.1, 3));
  }, [zoom, onZoomChange]);

  const handleZoomOut = useCallback(() => {
    onZoomChange(Math.max(zoom - 0.1, 0.2));
  }, [zoom, onZoomChange]);

  const handleZoomFit = useCallback(() => {
    onZoomChange(1);
  }, [onZoomChange]);

  // Keyboard shortcuts for zoom
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === '=' || e.key === '+') { e.preventDefault(); handleZoomIn(); }
        if (e.key === '-') { e.preventDefault(); handleZoomOut(); }
        if (e.key === '0') { e.preventDefault(); handleZoomFit(); }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleZoomIn, handleZoomOut, handleZoomFit]);

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#0d0d0d]">
      {/* Viewpoint Bar */}
      <ViewpointBar
        product={product}
        currentViewId={currentViewId}
        onViewChange={onViewChange}
      />

      {/* Canvas Area */}
      <div
        ref={containerRef}
        className="flex-1 flex items-center justify-center overflow-auto relative"
      >
        {/* Product silhouette background (when in placement mode) */}
        {!artworkMode && (
          <div
            className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03]"
            style={{
              background: `radial-gradient(ellipse at center, ${productColor} 0%, transparent 70%)`,
            }}
          />
        )}

        {/* Canvas Container */}
        <div
          className="relative shadow-2xl"
          style={{
            width: displaySize.width * zoom,
            height: displaySize.height * zoom,
            transition: 'width 0.2s ease, height 0.2s ease',
          }}
        >
          {/* Print Boundary Overlay */}
          {showBoundaries && !artworkMode && (
            <>
              {/* Printable Area */}
              <div
                className="absolute border border-dashed border-[#D4AF37]/30 pointer-events-none z-10"
                style={{
                  left: (currentView.printableArea.x / canvasWidth) * 100 + '%',
                  top: (currentView.printableArea.y / canvasHeight) * 100 + '%',
                  width: (currentView.printableArea.width / canvasWidth) * 100 + '%',
                  height: (currentView.printableArea.height / canvasHeight) * 100 + '%',
                }}
              >
                <span className="absolute -top-4 left-0 text-[8px] text-[#D4AF37]/50 font-condensed tracking-wider uppercase">
                  Print Area
                </span>
              </div>

              {/* Safe Area */}
              <div
                className="absolute border border-dotted border-green-400/20 pointer-events-none z-10"
                style={{
                  left: (currentView.safeArea.x / canvasWidth) * 100 + '%',
                  top: (currentView.safeArea.y / canvasHeight) * 100 + '%',
                  width: (currentView.safeArea.width / canvasWidth) * 100 + '%',
                  height: (currentView.safeArea.height / canvasHeight) * 100 + '%',
                }}
              >
                <span className="absolute -top-4 left-0 text-[8px] text-green-400/40 font-condensed tracking-wider uppercase">
                  Safe Area
                </span>
              </div>

              {/* Center Crosshair */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none z-10">
                <div className="w-px h-6 bg-[#D4AF37]/20 absolute left-1/2 -top-3" />
                <div className="h-px w-6 bg-[#D4AF37]/20 absolute top-1/2 -left-3" />
              </div>

              {/* Snap Guides (when enabled) */}
              {snapEnabled && (
                <>
                  {/* Vertical center line */}
                  <div className="absolute left-1/2 top-0 bottom-0 w-px bg-[#D4AF37]/10 pointer-events-none z-10" />
                  {/* Horizontal center line */}
                  <div className="absolute top-1/2 left-0 right-0 h-px bg-[#D4AF37]/10 pointer-events-none z-10" />
                </>
              )}
            </>
          )}

          {/* Fabric.js Canvas */}
          <div className="relative w-full h-full" style={{ background: artworkMode ? 'transparent' : '#1a1a1a' }}>
            <canvas
              ref={canvasRef}
              width={canvasWidth}
              height={canvasHeight}
              className="w-full h-full"
              style={{
                imageRendering: zoom > 1.5 ? 'pixelated' : 'auto',
              }}
            />
          </div>
        </div>
      </div>

      {/* Bottom Bar — Zoom Controls */}
      <div className="h-10 border-t border-[#2a2a2a] bg-[#111111] flex items-center justify-between px-3">
        {/* Left — View info */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-[#737373] font-condensed tracking-wider uppercase">
            {currentView.label}
          </span>
          <span className="text-[10px] text-[#737373]/50 font-body">
            {currentView.physicalPrintArea.maxWidthInches}" × {currentView.physicalPrintArea.maxHeightInches}" max
          </span>
        </div>

        {/* Center — Zoom controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={handleZoomOut}
            className="w-7 h-7 flex items-center justify-center rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors text-xs"
            aria-label="Zoom out"
          >
            −
          </button>
          <button
            onClick={handleZoomFit}
            className="px-2 py-1 rounded text-[10px] text-[#737373] hover:text-white hover:bg-[#1a1a1a] font-condensed tracking-wider transition-colors"
          >
            {Math.round(zoom * 100)}%
          </button>
          <button
            onClick={handleZoomIn}
            className="w-7 h-7 flex items-center justify-center rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors text-xs"
            aria-label="Zoom in"
          >
            +
          </button>
        </div>

        {/* Right — Snap & Boundary toggles */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {}}
            className={`text-[9px] font-condensed tracking-wider uppercase px-2 py-1 rounded transition-colors ${
              snapEnabled ? 'text-[#D4AF37] bg-[#D4AF37]/10' : 'text-[#737373] hover:text-white'
            }`}
            title="Snap guides"
          >
            Snap
          </button>
          <button
            onClick={() => {}}
            className={`text-[9px] font-condensed tracking-wider uppercase px-2 py-1 rounded transition-colors ${
              showBoundaries ? 'text-[#D4AF37] bg-[#D4AF37]/10' : 'text-[#737373] hover:text-white'
            }`}
            title="Show print boundaries"
          >
            Bounds
          </button>
        </div>
      </div>
    </div>
  );
}
