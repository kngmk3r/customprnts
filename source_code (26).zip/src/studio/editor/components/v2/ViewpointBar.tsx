/**
 * CUSTOM PRNTS — Viewpoint Bar (v2)
 *
 * Clickable viewpoint selector shown above the canvas.
 * Each product has multiple views (Front, Back, Left Sleeve, etc.)
 * Smooth transitions between views.
 *
 * Architecture supports future 360° viewer without redesign.
 */

import type { ProductDefinition } from '../../data/productLibrary';

interface ViewpointBarProps {
  product: ProductDefinition;
  currentViewId: string;
  onViewChange: (viewId: string) => void;
}

export default function ViewpointBar({ product, currentViewId, onViewChange }: ViewpointBarProps) {
  return (
    <div className="h-10 border-b border-[#2a2a2a] bg-[#111111] flex items-center px-3 gap-1 overflow-x-auto">
      {/* Product name */}
      <span className="text-[10px] text-[#737373] font-condensed tracking-wider uppercase mr-3 shrink-0">
        {product.name}
      </span>

      {/* Separator */}
      <div className="w-px h-5 bg-[#2a2a2a] mr-2 shrink-0" />

      {/* View buttons */}
      {product.viewpoints.map((view) => (
        <button
          key={view.id}
          onClick={() => onViewChange(view.id)}
          className={`
            px-3 py-1.5 rounded text-[10px] font-condensed font-bold tracking-wider uppercase
            transition-all duration-150 whitespace-nowrap shrink-0
            ${currentViewId === view.id
              ? 'bg-[#D4AF37] text-[#0d0d0d]'
              : 'text-[#737373] hover:text-white hover:bg-[#1a1a1a]'
            }
          `}
          aria-label={`Switch to ${view.label} view`}
          aria-pressed={currentViewId === view.id}
        >
          {view.label}
        </button>
      ))}
    </div>
  );
}
