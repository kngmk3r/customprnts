/**
 * CUSTOM PRNTS — ADVANCED EDITOR (Fixed ordering)
 */
import { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import type { ProductDefinition, ProductViewpoint, ProductColor } from '../../data/productLibrary';
import { getProductById, getViewpoint, mapBriefToProductId } from '../../data/productLibrary';
import { useEditorCanvas, type CanvasAPI } from '../EditorCanvas';
import { HistoryManager } from '../../utils/HistoryManager';
import LeftToolbar from './LeftToolbar';
import CenterCanvas from './CenterCanvas';
import RightPanel from './RightPanel';
import ProductBrowser from './ProductBrowser';
import type { Project } from '../../../storage';
import type { OverlayConfig } from '../../overlaySystem';
import FloatingToolbar from './FloatingToolbar';
import MockupRenderer from '../MockupRenderer';

let toastEl: HTMLDivElement | null = null;
function showToast(msg: string, type: 'success' | 'error' = 'success') {
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;padding:12px 20px;border-radius:8px;font-family:"Barlow Condensed",sans-serif;font-size:14px;font-weight:600;letter-spacing:0.05em;text-transform:uppercase;color:#FAFAFA;background:#1a1a1a;border:1px solid #D4AF37;box-shadow:0 4px 20px rgba(0,0,0,0.4);opacity:0;transform:translateY(10px);transition:all 0.3s ease;pointer-events:auto;';
    document.body.appendChild(toastEl);
  }
  toastEl.textContent = msg;
  toastEl.style.borderColor = type === 'success' ? '#D4AF37' : '#ef4444';
  toastEl.style.background = type === 'success' ? '#1a1a1a' : '#7f1d1d';
  requestAnimationFrame(() => { toastEl!.style.opacity = '1'; toastEl!.style.transform = 'translateY(0)'; });
  setTimeout(() => { if (toastEl) { toastEl.style.opacity = '0'; toastEl.style.transform = 'translateY(10px)'; } }, 3000);
}

const GOOGLE_FONTS_URL = 'https://fonts.googleapis.com/css2?family=Anton&family=Bebas+Neue&family=Oswald:wght@300;400;500;600;700&family=Barlow+Condensed:wght@300;400;500;600;700&family=Permanent+Marker&family=Playfair+Display:wght@400;500;600;700;800;900&family=Lobster&family=Montserrat:wght@300;400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&family=Cinzel:wght@400;500;600;700;800;900&family=Teko:wght@300;400;500;600;700&family=Luckiest+Guy&family=Righteous&display=swap';
let fontsLoaded = false;
function ensureFonts() {
  if (fontsLoaded) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = GOOGLE_FONTS_URL;
  document.head.appendChild(link);
  fontsLoaded = true;
}

type ToolId = 'ai' | 'upload' | 'text' | 'shapes' | 'layers';

interface EditorLayoutProps {
  project: Project;
  onSave: (project: Project) => void;
  onAutosave: (project: Project) => void;
  onPreview?: () => void;
  onBack: () => void;
  onApprove?: () => void;
  onOpenLocker?: () => void;
  overlays?: OverlayConfig[];
  onToggleOverlay?: (overlayId: string) => void;
  onUnlockDesign?: () => void;
}

interface SelectedObjectState {
  id: string;
  type: 'image' | 'text' | 'shape';
  name: string;
  left: number;
  top: number;
  width: number;
  height: number;
  scaleX: number;
  scaleY: number;
  angle: number;
  opacity: number;
  flipX: boolean;
  flipY: boolean;
  src?: string;
  brightness?: number;
  contrast?: number;
  saturation?: number;
  text?: string;
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: string;
  fontStyle?: string;
  fill?: string;
  stroke?: string;
  strokeWidth?: number;
  shadowColor?: string;
  shadowBlur?: number;
  letterSpacing?: number;
  textAlign?: string;
  textTransform?: string;
}

export default function EditorLayout({
  project,
  onSave,
  onAutosave,
  onPreview,
  onBack,
  onApprove,
  onOpenLocker,
  overlays = [],
  onToggleOverlay,
  onUnlockDesign,
}: EditorLayoutProps) {
  const [activeTool, setActiveTool] = useState<ToolId | null>(null);
  const [selectedObject, setSelectedObject] = useState<SelectedObjectState | null>(null);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [zoom, setZoom] = useState(1);
  const [snapEnabled, setSnapEnabled] = useState(true);
  const [showBoundaries, setShowBoundaries] = useState(true);
  const [showProductBrowser, setShowProductBrowser] = useState(false);
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');

  // Product state
  const [productId, setProductId] = useState(() => project.productId || mapBriefToProductId(project.brief.productType));
  const [colorId, setColorId] = useState(() => project.colorId || project.shirtColor || 'black');
  const [viewId, setViewId] = useState(() => project.viewId || 'front');

  // Refs
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const historyRef = useRef(new HistoryManager(80));
  const autosaveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const projectRef = useRef(project);
  projectRef.current = project;

  // Derived state
  const product = useMemo(() => getProductById(productId) || getProductById('adult-tshirt')!, [productId]);
  const currentView = useMemo(
    () => getViewpoint(product, viewId) || product.viewpoints[0],
    [product, viewId]
  );
  const currentColor = useMemo(() => {
    return product.colors.find(c => c.id === colorId) || product.colors[0];
  }, [product, colorId]);

  // Placement state — safe defaults before currentView is ready
  const [placementWidthInches, setPlacementWidthInches] = useState(() => {
    return project.placement?.widthInches || (product.viewpoints[0]?.physicalPrintArea?.maxWidthInches || 12) * product.defaultPlacement.widthRatio;
  });
  const [topOffsetInches, setTopOffsetInches] = useState(() => {
    return project.placement?.topOffsetInches || (product.viewpoints[0]?.physicalPrintArea?.maxHeightInches || 14) * product.defaultPlacement.topOffsetRatio;
  });
  const [hOffsetInches, setHOffsetInches] = useState(() => project.placement?.horizontalOffsetInches || 0);
  const [rotationDegrees, setRotationDegrees] = useState(() => project.placement?.rotationDegrees || 0);

  // Canvas refs
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [toolbarTrigger, setToolbarTrigger] = useState(0);

  // Autosave — defined BEFORE callbacks that use it
  const triggerAutosave = useCallback(() => {
    if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
    autosaveTimerRef.current = setTimeout(() => {
      setSaveStatus('saving');
      try {
        const canvasApi = canvasApiRef.current;
        const canvasJson = canvasApi?.getSerializedState() || '';
        const thumb = canvasApi?.exportForDisplay() || '';
        const updated = {
          ...projectRef.current,
          canvasJSON: canvasJson,
          canvasThumbnail: thumb,
          productId,
          colorId,
          viewId,
          placement: {
            widthInches: placementWidthInches,
            topOffsetInches: topOffsetInches,
            horizontalOffsetInches: hOffsetInches,
            rotationDegrees: rotationDegrees,
          },
          updatedAt: new Date().toISOString(),
        };
        onAutosave(updated as any);
        setSaveStatus('saved');
        setTimeout(() => setSaveStatus('idle'), 2000);
      } catch {
        setSaveStatus('error');
      }
    }, 2000);
  }, [onAutosave, productId, colorId, viewId, placementWidthInches, topOffsetInches, hOffsetInches, rotationDegrees]);

  const onSelectionChange = useCallback((obj: any) => {
    if (!obj) {
      setSelectedObject(null);
      return;
    }
    setSelectedObject({
      id: obj._storageKey || obj.__uid || 'unknown',
      type: obj.type === 'textbox' ? 'text' : obj.type === 'rect' || obj.type === 'circle' ? 'shape' : 'image',
      name: obj._objectName || obj.type || 'Object',
      left: obj.left || 0,
      top: obj.top || 0,
      width: obj.width || 0,
      height: obj.height || 0,
      scaleX: obj.scaleX || 1,
      scaleY: obj.scaleY || 1,
      angle: obj.angle || 0,
      opacity: obj.opacity ?? 1,
      flipX: obj.flipX || false,
      flipY: obj.flipY || false,
      src: obj.src,
      brightness: obj.brightness,
      contrast: obj.contrast,
      saturation: obj.saturation,
      text: obj.text,
      fontFamily: obj.fontFamily,
      fontSize: obj.fontSize,
      fontWeight: obj.fontWeight,
      fontStyle: obj.fontStyle,
      fill: obj.fill,
      stroke: obj.stroke,
      strokeWidth: obj.strokeWidth,
      shadowColor: obj.shadowColor,
      shadowBlur: obj.shadowBlur,
      letterSpacing: obj.letterSpacing,
      textAlign: obj.textAlign,
      textTransform: obj.textTransform,
    });
  }, []);

  // canvasApiRef declared before onObjectModified but initialized after useEditorCanvas
  const canvasApiRef = useRef<any>(null);

  const onObjectModified = useCallback((grouped: boolean) => {
    if (canvasApiRef.current) {
      const state = canvasApiRef.current.getSerializedState();
      historyRef.current.push(state, grouped);
      triggerAutosave();
      const canvas = canvasApiRef.current.getCanvas();
      const activeObj = canvas?.getActiveObject();
      if (activeObj) {
        onSelectionChange(activeObj);
        if (currentView) {
          const physW = (activeObj.width * activeObj.scaleX / currentView.printableArea.width) * currentView.physicalPrintArea.maxWidthInches;
          setPlacementWidthInches(Math.round(physW * 10) / 10);
          const centerX = canvas.width / 2;
          const hOffset = ((activeObj.left - centerX) / currentView.printableArea.width) * currentView.physicalPrintArea.maxWidthInches;
          setHOffsetInches(Math.round(hOffset * 10) / 10);
          const topOffset = ((activeObj.top - currentView.printableArea.y) / currentView.printableArea.height) * currentView.physicalPrintArea.maxHeightInches;
          setTopOffsetInches(Math.round(topOffset * 10) / 10);
          setRotationDegrees(Math.round(activeObj.angle || 0));
        }
      }
    }
  }, [onSelectionChange, currentView, triggerAutosave]);

  const onCanvasReady = useCallback(() => {
    ensureFonts();
    const canvasApi = canvasApiRef.current;
    if (!canvasApi) return;
    if ((project as any).canvasJSON) {
      canvasApi.loadSerializedState((project as any).canvasJSON).then(() => {
        historyRef.current.save(canvasApi.getSerializedState());
      });
    } else if ((project as any).conceptImageUrl) {
      canvasApi.loadImage(
        (project as any).conceptImageUrl,
        (project as any).selectedConceptId || ''
      ).then(() => {
        historyRef.current.save(canvasApi.getSerializedState());
      });
    } else {
      historyRef.current.save(canvasApi.getSerializedState());
    }
  }, [project]);

  const canvasApi = useEditorCanvas({
    canvasRef,
    productView: currentView as any,
    productColor: currentColor.hex,
    snapEnabled,
    onSelectionChange,
    onObjectModified,
    onCanvasReady,
  });

  // keep ref in sync
  canvasApiRef.current = canvasApi;

  // Sync floating toolbar during transformation
  useEffect(() => {
    const canvas = canvasApi.getCanvas();
    if (!canvas) return;
    const trigger = () => setToolbarTrigger(prev => prev + 1);
    canvas.on('object:moving', trigger);
    canvas.on('object:scaling', trigger);
    canvas.on('object:rotating', trigger);
    return () => {
      canvas.off('object:moving', trigger);
      canvas.off('object:scaling', trigger);
      canvas.off('object:rotating', trigger);
    };
  }, [canvasApi]);

  // Product overlay when view/color changes
  useEffect(() => {
    if (currentView) {
      canvasApi.setProductOverlay(currentView as any, currentColor.hex);
    }
  }, [currentView, currentColor.hex]); // eslint-disable-line react-hooks/exhaustive-deps

  // Load concept image
  const conceptUrlRef = useRef<string | null>(null);
  useEffect(() => {
    const url = (project as any).conceptImageUrl;
    const canvasJson = (project as any).canvasJSON;
    if (canvasJson) {
      conceptUrlRef.current = null;
      const canvasApi = canvasApiRef.current;
      if (canvasApi) {
        canvasApi.loadSerializedState(canvasJson).then(() => {
          historyRef.current.save(canvasApi.getSerializedState());
        });
      }
      return;
    }
    if (!url) return;
    if (url === conceptUrlRef.current) return;
    conceptUrlRef.current = url;
    const tryLoad = () => {
      const canvasApi = canvasApiRef.current;
      const canvas = canvasApi?.getCanvas();
      if (canvas && canvas.getObjects) {
        canvasApi.loadImage(url, (project as any).selectedConceptId || '').then(() => {
          historyRef.current.save(canvasApi.getSerializedState());
        }).catch(() => {});
        return true;
      }
      return false;
    };
    if (tryLoad()) return;
    let attempts = 0;
    const timer = setInterval(() => {
      attempts++;
      if (tryLoad() || attempts >= 30) clearInterval(timer);
    }, 100);
    return () => clearInterval(timer);
  }, [(project as any).conceptImageUrl, (project as any).canvasJSON]); // eslint-disable-line react-hooks/exhaustive-deps

  // Manual save
  const handleSave = useCallback(() => {
    setSaveStatus('saving');
    const canvasApi = canvasApiRef.current;
    const canvasJson = canvasApi?.getSerializedState() || '';
    const thumb = canvasApi?.exportForDisplay() || '';
    const updated = {
      ...projectRef.current,
      canvasJSON: canvasJson,
      canvasThumbnail: thumb,
      productId,
      colorId,
      viewId,
      placement: {
        widthInches: placementWidthInches,
        topOffsetInches: topOffsetInches,
        horizontalOffsetInches: hOffsetInches,
        rotationDegrees: rotationDegrees,
      },
      updatedAt: new Date().toISOString(),
    };
    onSave(updated as any);
    setSaveStatus('saved');
    showToast('Project saved');
    setTimeout(() => setSaveStatus('idle'), 2000);
  }, [onSave, productId, colorId, viewId, placementWidthInches, topOffsetInches, hOffsetInches, rotationDegrees]);

  // Undo / Redo
  const undo = useCallback(() => {
    const canvasApi = canvasApiRef.current;
    if (!canvasApi) return;
    const current = canvasApi.getSerializedState();
    const prev = historyRef.current.undo(current);
    if (prev) {
      canvasApi.loadSerializedState(prev);
      triggerAutosave();
    }
  }, [triggerAutosave]);

  const redo = useCallback(() => {
    const canvasApi = canvasApiRef.current;
    if (!canvasApi) return;
    const next = historyRef.current.redo();
    if (next) {
      canvasApi.loadSerializedState(next);
      triggerAutosave();
    }
  }, [triggerAutosave]);

  const layers = useMemo(() => {
    const canvasApi = canvasApiRef.current;
    if (!canvasApi) return [];
    const objects = canvasApi.getObjects();
    return objects
      .filter((o: any) => !o._isProductOverlay && !o._isPlacementGuide)
      .map((o: any) => ({
        id: o._storageKey || o.__uid || `obj_${objects.indexOf(o)}`,
        name: (o as any)._objectName || o.type || 'Object',
        type: o.type || 'unknown',
        visible: o.visible !== false,
        locked: o.selectable === false,
        selected: o === (canvasApi.getCanvas() as any)?.getActiveObject(),
      }));
  }, [selectedObject]); // eslint-disable-line react-hooks/exhaustive-deps

  const hasSelection = selectedObject !== null;
  const hasMultipleSelection = useMemo(() => {
    const canvas = canvasApiRef.current?.getCanvas();
    if (!canvas) return false;
    const active = canvas.getActiveObject();
    return active?.type === 'activeSelection';
  }, [selectedObject]); // eslint-disable-line react-hooks/exhaustive-deps
  const hasGroupSelected = useMemo(() => {
    const canvas = canvasApiRef.current?.getCanvas();
    if (!canvas) return false;
    const active = canvas.getActiveObject();
    return active?.type === 'group';
  }, [selectedObject]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleGroupSelected = useCallback(() => {
    canvasApi.groupSelected();
    triggerAutosave();
  }, [canvasApi, triggerAutosave]);

  const handleUngroupSelected = useCallback(() => {
    canvasApi.ungroupSelected();
    triggerAutosave();
  }, [canvasApi, triggerAutosave]);

  const nudgeSelected = useCallback((dx: number, dy: number) => {
    const canvas = canvasApi.getCanvas();
    if (!canvas) return;
    const obj = canvas.getActiveObject();
    if (!obj || (obj as any)._isProductOverlay) return;
    obj.set('left', (obj.left || 0) + dx);
    obj.set('top', (obj.top || 0) + dy);
    obj.setCoords();
    canvas.renderAll();
  }, [canvasApi]);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const mod = isMac ? e.metaKey : e.ctrlKey;
      if (mod && e.key === 'z' && !e.shiftKey) { e.preventDefault(); undo(); }
      else if (mod && ((e.key === 'z' && e.shiftKey) || e.key === 'y')) { e.preventDefault(); redo(); }
      else if (mod && e.key === 's') { e.preventDefault(); handleSave(); }
      else if (mod && e.key === 'd') { e.preventDefault(); canvasApi.duplicateSelected(); }
      else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (!mod && !(canvasApi.getCanvas()?.getActiveObject() as any)?.isEditing) {
          e.preventDefault(); canvasApi.deleteSelected();
        }
      }
      else if (e.key === 'Escape') { canvasApi.deselectAll(); setActiveTool(null); }
      else if (mod && e.key === 'g') { e.preventDefault(); if (e.shiftKey) canvasApi.ungroupSelected(); else canvasApi.groupSelected(); triggerAutosave(); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); nudgeSelected(-e.shiftKey ? 10 : 1, 0); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); nudgeSelected(e.shiftKey ? 10 : 1, 0); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); nudgeSelected(0, -e.shiftKey ? 10 : 1); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); nudgeSelected(0, e.shiftKey ? 10 : 1); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [undo, redo, handleSave, canvasApi, triggerAutosave, nudgeSelected]);

  // Warn before leaving
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ''; };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, []);

  // Tool actions
  const handleAddText = useCallback(() => {
    canvasApi.addText();
  }, [canvasApi]);

  const handleAddShape = useCallback((shape: string) => {
    const canvas = canvasApi.getCanvas();
    if (!canvas) return;
    const fabric = (window as any).fabric;
    if (!fabric) return;
    let shapeObj: any;
    const center = canvas.getCenter();
    switch (shape) {
      case 'rect':
        shapeObj = new fabric.Rect({ left: center.left - 75, top: center.top - 50, width: 150, height: 100, fill: 'transparent', stroke: '#FAFAFA', strokeWidth: 2 });
        break;
      case 'circle':
        shapeObj = new fabric.Circle({ left: center.left - 50, top: center.top - 50, radius: 50, fill: 'transparent', stroke: '#FAFAFA', strokeWidth: 2 });
        break;
      case 'triangle':
        shapeObj = new fabric.Triangle({ left: center.left - 50, top: center.top - 50, width: 100, height: 100, fill: 'transparent', stroke: '#FAFAFA', strokeWidth: 2 });
        break;
      case 'star':
        shapeObj = new fabric.Circle({ left: center.left - 40, top: center.top - 40, radius: 40, fill: '#D4AF37', stroke: 'transparent', strokeWidth: 0 });
        break;
      case 'line':
        shapeObj = new fabric.Line([center.left - 75, center.top, center.left + 75, center.top], { stroke: '#FAFAFA', strokeWidth: 2 });
        break;
      default:
        return;
    }
    if (shapeObj) {
      canvas.add(shapeObj);
      canvas.setActiveObject(shapeObj);
      canvas.renderAll();
    }
  }, [canvasApi]);

  const handleUploadImage = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (ev) => {
      canvasApi.addImageFromUrl(ev.target?.result as string, `upload_${Date.now()}`);
    };
    reader.readAsDataURL(file);
  }, [canvasApi]);

  const handleSelectLayer = useCallback((id: string) => {
    const canvas = canvasApi.getCanvas();
    if (!canvas) return;
    const obj = canvas.getObjects().find((o: any) => (o._storageKey || o.__uid || '') === id);
    if (obj) { canvas.setActiveObject(obj); canvas.renderAll(); }
  }, [canvasApi]);

  const handleToggleLayerVisibility = useCallback((id: string) => {
    const canvas = canvasApi.getCanvas();
    if (!canvas) return;
    const obj = canvas.getObjects().find((o: any) => (o._storageKey || o.__uid || '') === id);
    if (obj) { obj.set('visible', !obj.visible); canvas.renderAll(); }
  }, [canvasApi]);

  const handleToggleLayerLock = useCallback((id: string) => {
    const canvas = canvasApi.getCanvas();
    if (!canvas) return;
    const obj = canvas.getObjects().find((o: any) => (o._storageKey || o.__uid || '') === id);
    if (obj) {
      const locked = obj.selectable !== false;
      obj.set({ selectable: !locked, evented: !locked, hasControls: !locked });
      canvas.renderAll();
    }
  }, [canvasApi]);

  const handleDeleteLayer = useCallback(() => {
    canvasApi.deleteSelected();
  }, [canvasApi]);

  const handleReorderLayer = useCallback((_id: string, direction: 'up' | 'down') => {
    if (direction === 'up') canvasApi.bringForward();
    else canvasApi.sendBackward();
  }, [canvasApi]);

  const handleUpdateObject = useCallback((updates: Partial<SelectedObjectState>) => {
    const canvas = canvasApi.getCanvas();
    if (!canvas) return;
    const obj = canvas.getActiveObject();
    if (!obj) return;
    Object.entries(updates).forEach(([key, value]) => {
      if (value !== undefined) obj.set(key, value);
    });
    obj.setCoords();
    canvas.renderAll();
    onSelectionChange(obj);
  }, [canvasApi, onSelectionChange]);

  const handleRemoveBackground = useCallback(async () => {
    try { await canvasApi.removeBackgroundFromSelected(); } catch {}
  }, [canvasApi]);

  const handleCropStart = useCallback(() => {
    canvasApi.startCropMode();
  }, [canvasApi]);

  const handleColorChange = useCallback((newColorId: string) => {
    setColorId(newColorId);
  }, []);

  const handleProductChange = useCallback((newProductId: string) => {
    setProductId(newProductId);
    const tmpl = getProductById(newProductId);
    if (tmpl) {
      setColorId(tmpl.colors[0]?.id || 'black');
      setViewId(tmpl.viewpoints[0]?.viewId || 'front');
    }
  }, []);

  const handlePlacementChange = useCallback((field: string, value: any) => {
    const canvas = canvasApi.getCanvas();
    const active = canvas?.getActiveObject();
    if (field === 'smart-layout') {
      if (!active) { showToast('Select an object first', 'error'); return; }
      showToast(`Applying ${value.replace('-', ' ')} layout`, 'success');
      const layoutMap: Record<string, { width: number, top: number, align: 'center' | 'left' }> = {
        'center-chest': { width: 10, top: 3, align: 'center' },
        'left-chest': { width: 3.5, top: 3, align: 'left' },
        'full-back': { width: 12, top: 4, align: 'center' },
      };
      const config = layoutMap[value];
      if (!config) return;
      const scale = (config.width / currentView.physicalPrintArea.maxWidthInches) * (currentView.printableArea.width / active.width);
      const left = config.align === 'center' ? canvas.width / 2 : currentView.printableArea.x + (active.width * scale) / 2 + 50;
      const top = currentView.printableArea.y + (config.top / currentView.physicalPrintArea.maxHeightInches) * currentView.printableArea.height;
      active.set({ scaleX: scale, scaleY: scale, left, top, originX: 'center', originY: 'center', angle: 0 });
      active.setCoords();
      canvas.renderAll();
      onObjectModified(false);
      return;
    }
    if (field === 'view') { setViewId(value); return; }
    switch (field) {
      case 'width': setPlacementWidthInches(value); break;
      case 'topOffset': setTopOffsetInches(value); break;
      case 'horizontalOffset': setHOffsetInches(value); break;
    }
  }, [canvasApi, currentView, onObjectModified]);

  const [isMobile, setIsMobile] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768);
  const [showLayersMobile, setShowLayersMobile] = useState(false);
  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleFloatingAction = useCallback((action: string) => {
    const canvas = canvasApi.getCanvas();
    const active = canvas?.getActiveObject();
    if (!active) return;
    switch (action) {
      case 'delete': canvasApi.deleteSelected(); break;
      case 'duplicate': canvasApi.duplicateSelected(); break;
      case 'bring-to-front': active.bringToFront(); canvas.renderAll(); break;
      case 'remove-bg': handleRemoveBackground(); break;
    }
  }, [canvasApi, handleRemoveBackground]);

  const handleMobileUpload = useCallback(() => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        canvasApi.addImageFromUrl(ev.target?.result as string, `upload_${Date.now()}`);
      };
      reader.readAsDataURL(file);
    };
    input.click();
  }, [canvasApi]);

  if (isMobile) {
    return (
      <div className="min-h-screen bg-[#0d0d0d] flex flex-col">
        {/* Mobile Top Bar — polished 320px+ */}
        <div className="h-14 border-b border-[#1e1e1e] bg-[#111111] flex items-center justify-between px-3 sticky top-0 z-30">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <button onClick={onBack} className="w-9 h-9 flex items-center justify-center rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#8a8a8a] shrink-0">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
            </button>
            <div className="min-w-0 flex-1">
              <p className="font-condensed text-[11px] font-black text-white tracking-[0.14em] uppercase truncate leading-none">{project.brief.name}</p>
              <p className="font-mono text-[9px] text-[#5a5a5a] mt-1 truncate">{product.name} • {currentColor.name} • {viewId}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 ml-2 shrink-0">
            <button onClick={undo} className="w-8 h-8 flex items-center justify-center rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#5a5a5a] hover:text-white">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"><path d="M3 10h10a5 5 0 015 5v0a5 5 0 01-5 5H8" /><path d="M7 14L3 10l4-4" /></svg>
            </button>
            <button onClick={redo} className="w-8 h-8 flex items-center justify-center rounded-full bg-[#1a1a1a] border border-[#2a2a2a] text-[#5a5a5a] hover:text-white">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2"><path d="M21 10H11a5 5 0 00-5 5v0a5 5 0 005 5h5" /><path d="M17 14l4-4-4-4" /></svg>
            </button>
            <button onClick={handleSave} className={`w-8 h-8 flex items-center justify-center rounded-full border transition-all ${saveStatus==='saved'?'bg-green-500/15 border-green-500/30 text-green-400':'bg-[#D4AF37]/10 border-[#D4AF37]/30 text-[#D4AF37]'}`}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" /><polyline points="17,21 17,13 7,13 7,21" /></svg>
            </button>
          </div>
        </div>

        {/* View toggle + Zoom */}
        <div className="h-9 bg-[#0f0f0f] border-b border-[#1e1e1e] flex items-center justify-between px-3">
          <div className="flex bg-[#1a1a1a] rounded-full p-0.5 border border-[#2a2a2a]">
            <button onClick={()=>setViewMode('edit')} className={`px-2.5 py-1 rounded-full text-[9px] font-condensed font-black tracking-wider uppercase ${viewMode==='edit'?'bg-[#2a2a2a] text-white':'text-[#5a5a5a]'}`}>Editor</button>
            <button onClick={()=>setViewMode('preview')} className={`px-2.5 py-1 rounded-full text-[9px] font-condensed font-black tracking-wider uppercase ${viewMode==='preview'?'bg-[#2a2a2a] text-[#D4AF37]':'text-[#5a5a5a]'}`}>Mockup</button>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[9px] font-mono text-[#3a3a3a]">{Math.round(zoom*100)}%</span>
            <input type="range" min="0.5" max="2" step="0.1" value={zoom} onChange={e=>setZoom(parseFloat(e.target.value))} className="w-16 accent-[#D4AF37]" />
            {hasSelection && <span className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] animate-pulse" />}
          </div>
        </div>

        {/* Canvas or Mockup */}
        <div className="flex-1 relative overflow-hidden bg-[#080808] flex items-center justify-center p-3">
          {viewMode==='edit' ? (
            <div ref={canvasContainerRef} className="w-full h-full flex items-center justify-center">
              <canvas ref={canvasRef} className="max-w-full max-h-full shadow-[0_10px_40px_rgba(0,0,0,0.6)] rounded-sm" />
            </div>
          ) : (
            <div className="w-full max-w-[340px]">
              <MockupRenderer
                productTemplate={{ id: product.id, name: product.name, category: product.categoryId, subcategory: product.subcategory, views: product.viewpoints as any, colors: product.colors, baseImageUrl: product.baseImageUrl, maskUrl: product.maskUrl, supportedPrintMethods: product.supportedPrintMethods }}
                viewId={viewId}
                productColor={currentColor.hex}
                artworkDataUrl={canvasApi.exportForDisplay()}
                placementX={0.5 + hOffsetInches / (currentView?.physicalPrintArea?.maxWidthInches || 12)}
                placementY={0.3 + topOffsetInches / (currentView?.physicalPrintArea?.maxHeightInches || 14)}
                placementWidth={placementWidthInches / (currentView?.physicalPrintArea?.maxWidthInches || 12)}
                baseImageUrl={product.baseImageUrl}
                maskUrl={product.maskUrl}
              />
              <button onClick={()=>setViewMode('edit')} className="mt-4 w-full py-2.5 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] text-[10px] font-condensed font-bold tracking-widest uppercase text-[#8a8a8a]">← Back to Editor</button>
            </div>
          )}

          {/* Floating toolbar mobile */}
          {selectedObject && viewMode==='edit' && canvasApi.getCanvas() && (
            <div className="absolute bottom-20 left-1/2 -translate-x-1/2 bg-[#1a1a1a]/90 backdrop-blur-md border border-[#2a2a2a] rounded-full px-2 py-1.5 flex items-center gap-1 shadow-[0_8px_24px_rgba(0,0,0,0.5)]">
              <button onClick={()=>canvasApi.duplicateSelected()} className="w-8 h-8 rounded-full bg-[#2a2a2a] text-white flex items-center justify-center">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M16 8v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2" /></svg>
              </button>
              <button onClick={()=>canvasApi.bringForward()} className="w-8 h-8 rounded-full bg-[#2a2a2a] text-white flex items-center justify-center">↑</button>
              <button onClick={handleRemoveBackground} className="px-2.5 h-8 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37] text-[9px] font-bold uppercase tracking-wider">Remove BG</button>
              <button onClick={()=>canvasApi.deleteSelected()} className="w-8 h-8 rounded-full bg-red-500/15 border border-red-500/30 text-red-400 flex items-center justify-center">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6m5 0V4a2 2 0 012-2h2a2 2 0 012 2v2" /></svg>
              </button>
            </div>
          )}
        </div>

        {/* Layers sheet */}
        {showLayersMobile && (
          <div className="absolute inset-0 z-40 bg-black/60 backdrop-blur-sm flex flex-col justify-end" onClick={()=>setShowLayersMobile(false)}>
            <div className="bg-[#111111] border-t border-[#2a2a2a] rounded-t-[20px] max-h-[60%] overflow-hidden" onClick={e=>e.stopPropagation()}>
              <div className="p-4 border-b border-[#1e1e1e] flex items-center justify-between">
                <h3 className="font-condensed font-black text-white text-[12px] tracking-[0.15em] uppercase">Layers • {layers.length}</h3>
                <button onClick={()=>setShowLayersMobile(false)} className="w-8 h-8 rounded-full bg-[#1a1a1a] flex items-center justify-center text-[#5a5a5a]">✕</button>
              </div>
              <div className="overflow-y-auto p-3 space-y-1.5 max-h-[300px]">
                {layers.length===0 ? <p className="text-[11px] text-[#5a5a5a] text-center py-8">No layers yet — add text or upload image</p> :
                  layers.map(l=>(
                    <div key={l.id} className={`flex items-center gap-2 p-2.5 rounded-xl border ${l.selected?'bg-[#D4AF37]/10 border-[#D4AF37]/30':'bg-[#0d0d0d] border-[#1e1e1e]'}`}>
                      <div className="w-8 h-8 rounded-lg bg-[#1a1a1a] border border-[#2a2a2a] flex items-center justify-center text-[10px]">{l.type==='textbox'?'T':l.type==='image'?'🖼':'◼'}</div>
                      <span className="flex-1 text-[11px] font-medium text-white truncate">{l.name}</span>
                      <button onClick={()=>handleToggleLayerVisibility(l.id)} className="w-7 h-7 rounded-full bg-[#1a1a1a] text-[#5a5a5a] text-[10px]">{l.visible?'👁':'🚫'}</button>
                      <button onClick={()=>handleSelectLayer(l.id)} className="px-2.5 py-1 rounded-full bg-[#2a2a2a] text-[10px] font-bold uppercase">Select</button>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* Bottom Toolbar — scrollable 320px+ safe */}
        <div className="border-t border-[#1e1e1e] bg-[#111111] safe-pb">
          <div className="flex gap-1 p-2 overflow-x-auto scrollbar-none">
            <button onClick={handleMobileUpload} className="shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] min-w-[56px]">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8a8a8a" strokeWidth="1.8"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3" /></svg>
              <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-[#8a8a8a]">Upload</span>
            </button>
            <button onClick={handleAddText} className="shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] min-w-[56px]">
              <span className="text-[14px] font-serif font-bold text-[#8a8a8a] leading-none">T</span>
              <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-[#8a8a8a]">Text</span>
            </button>
            <button onClick={()=>handleAddShape('rect')} className="shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] min-w-[56px]">
              <div className="w-4 h-3 border border-[#8a8a8a] rounded-[2px]" />
              <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-[#8a8a8a]">Shape</span>
            </button>
            <button onClick={()=>setShowLayersMobile(true)} className="shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] min-w-[56px] relative">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8a8a8a" strokeWidth="1.8"><path d="M12 2L2 7l10 5 10-5-10-5z" /><path d="M2 17l10 5 10-5" /><path d="M2 12l10 5 10-5" /></svg>
              <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-[#8a8a8a]">Layers</span>
              {layers.length>0 && <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#D4AF37] text-black text-[9px] font-black flex items-center justify-center">{layers.length}</span>}
            </button>
            <button onClick={()=>canvasApi.duplicateSelected()} className="shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] min-w-[56px]">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8a8a8a" strokeWidth="1.8"><rect x="8" y="8" width="12" height="12" rx="2" /><path d="M16 8v-2a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2" /></svg>
              <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-[#8a8a8a]">Dup</span>
            </button>
            <button onClick={()=>canvasApi.deleteSelected()} className="shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl bg-red-500/10 border border-red-500/20 min-w-[56px]">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="1.8"><polyline points="3 6 5 6 21 6" /><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6m5 0V4a2 2 0 012-2h2a2 2 0 012 2v2" /></svg>
              <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-red-400">Delete</span>
            </button>
            <div className="w-px h-10 bg-[#1e1e1e] self-center mx-1 shrink-0" />
            <button onClick={()=>setShowProductBrowser(true)} className="shrink-0 flex flex-col items-center gap-1 px-3 py-2 rounded-xl bg-[#1a1a1a] border border-[#2a2a2a] min-w-[56px]">
              <span className="text-[14px]">{product.categoryId==='tops'?'👕':product.categoryId==='headwear'?'🧢':product.categoryId==='drinkware'?'☕':'📦'}</span>
              <span className="text-[8px] font-condensed font-bold tracking-wider uppercase text-[#8a8a8a]">Product</span>
            </button>
            <button onClick={handleSave} className="shrink-0 flex flex-col items-center gap-1 px-4 py-2 rounded-xl bg-[#D4AF37] text-black min-w-[64px] shadow-[0_0_15px_rgba(212,175,55,0.25)]">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" /><polyline points="17,21 17,13 7,13 7,21" /></svg>
              <span className="text-[8px] font-condensed font-black tracking-wider uppercase">Save</span>
            </button>
            <button onClick={onApprove} className="shrink-0 flex flex-col items-center gap-1 px-4 py-2 rounded-xl bg-white text-black min-w-[64px]">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 13l4 4L19 7" /></svg>
              <span className="text-[8px] font-condensed font-black tracking-wider uppercase">Approve</span>
            </button>
          </div>
        </div>

        {showProductBrowser && (
          <ProductBrowser currentProductId={productId} onSelectProduct={handleProductChange} onClose={()=>setShowProductBrowser(false)} />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0d0d0d] flex flex-col">
      <div className="h-12 border-b border-[#2a2a2a] bg-[#111111] flex items-center justify-between px-4 shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <button onClick={onBack} className="flex items-center gap-1.5 px-2 py-1.5 rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors" aria-label="Back to Projects">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
            <span className="text-[10px] font-condensed font-bold tracking-wider uppercase hidden sm:inline">Projects</span>
          </button>
          <div className="w-px h-5 bg-[#2a2a2a]" />
          <span className="font-condensed text-xs font-bold text-white tracking-wider uppercase truncate max-w-[200px]">{project.brief.name}</span>
          {saveStatus !== 'idle' && (
            <span className={`text-[10px] font-condensed px-1.5 py-0.5 rounded ${saveStatus === 'saved' ? 'bg-green-400/10 text-green-400' : saveStatus === 'saving' ? 'bg-yellow-400/10 text-yellow-400' : 'bg-red-400/10 text-red-400'}`}>{saveStatus === 'saved' ? 'Saved' : saveStatus === 'saving' ? 'Saving...' : 'Error'}</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button onClick={undo} className="w-8 h-8 flex items-center justify-center rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors" title="Undo (Ctrl+Z)" aria-label="Undo">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 10h10a5 5 0 015 5v0a5 5 0 01-5 5H8" /><path d="M7 14L3 10l4-4" /></svg>
          </button>
          <button onClick={redo} className="w-8 h-8 flex items-center justify-center rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors" title="Redo (Ctrl+Shift+Z)" aria-label="Redo">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 10H11a5 5 0 00-5 5v0a5 5 0 005 5h5" /><path d="M17 14l4-4-4-4" /></svg>
          </button>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-[#1a1a1a] rounded-lg p-0.5 border border-[#2a2a2a] mr-2">
            <button onClick={() => setViewMode('edit')} className={`px-3 py-1 rounded-md text-[9px] font-condensed font-bold uppercase tracking-wider transition-all ${viewMode === 'edit' ? 'bg-[#2a2a2a] text-[#D4AF37]' : 'text-[#737373] hover:text-white'}`}>Editor</button>
            <button onClick={() => setViewMode('preview')} className={`px-3 py-1 rounded-md text-[9px] font-condensed font-bold uppercase tracking-wider transition-all ${viewMode === 'preview' ? 'bg-[#2a2a2a] text-[#D4AF37]' : 'text-[#737373] hover:text-white'}`}>Mockup</button>
          </div>
          <button onClick={handleSave} className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors" title="Save (Ctrl+S)" aria-label="Save">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z" /><polyline points="17,21 17,13 7,13 7,21" /><polyline points="7,3 7,8 15,8" /></svg>
            <span className="text-[10px] font-condensed font-bold tracking-wider uppercase hidden sm:inline">Save</span>
          </button>
          <button onClick={() => setShowProductBrowser(true)} className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors" title="Change Product">
            <span className="text-sm">{product.categoryId === 'tops' ? '👕' : product.categoryId === 'headwear' ? '🧢' : product.categoryId === 'drinkware' ? '☕' : '📦'}</span>
            <span className="text-[10px] font-condensed font-bold tracking-wider uppercase hidden sm:inline">{product.name}</span>
          </button>
          <button onClick={onApprove} className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#D4AF37] text-[#0d0d0d] transition-all hover:bg-[#E8CC6E] active:scale-95">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M5 13l4 4L19 7" /></svg>
            <span className="text-[10px] font-condensed font-bold tracking-wider uppercase">Approve</span>
          </button>
        </div>
      </div>
      <div className="flex flex-1 overflow-hidden" style={{ height: 'calc(100vh - 48px)' }}>
        <LeftToolbar
          activeTool={activeTool}
          onSelectTool={setActiveTool}
          onAddText={handleAddText}
          onAddShape={handleAddShape}
          onUploadImage={handleUploadImage}
          layers={layers}
          hasSelection={hasSelection}
          onSelectLayer={handleSelectLayer}
          onToggleLayerVisibility={handleToggleLayerVisibility}
          onToggleLayerLock={handleToggleLayerLock}
          onDeleteLayer={handleDeleteLayer}
          onReorderLayer={handleReorderLayer}
          onGroupSelected={handleGroupSelected}
          onUngroupSelected={handleUngroupSelected}
          hasMultipleSelection={hasMultipleSelection}
          hasGroupSelected={hasGroupSelected}
        />
        {selectedObject && canvasApi.getCanvas() && (
          <FloatingToolbar
            selectedObject={canvasApi.getCanvas()?.getActiveObject()}
            canvas={canvasApi.getCanvas()}
            onAction={handleFloatingAction}
            trigger={toolbarTrigger}
          />
        )}
        {viewMode === 'edit' ? (
          <CenterCanvas
            product={product}
            currentViewId={viewId}
            productColor={currentColor.hex}
            onViewChange={setViewId}
            canvasRef={canvasRef}
            onCanvasReady={onCanvasReady}
            snapEnabled={snapEnabled}
            showBoundaries={showBoundaries}
            zoom={zoom}
            onZoomChange={setZoom}
            artworkMode={false}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-[#0d0d0d] p-8 overflow-auto">
            <div className="w-full max-w-lg">
              <MockupRenderer
                productTemplate={{
                  id: product.id,
                  name: product.name,
                  category: product.categoryId,
                  subcategory: product.subcategory,
                  views: product.viewpoints as any,
                  colors: product.colors,
                  baseImageUrl: product.baseImageUrl,
                  maskUrl: product.maskUrl,
                  supportedPrintMethods: product.supportedPrintMethods
                }}
                viewId={viewId}
                productColor={currentColor.hex}
                artworkDataUrl={canvasApi.exportForDisplay()}
                placementX={0.5 + hOffsetInches / (currentView?.physicalPrintArea?.maxWidthInches || 12)}
                placementY={0.3 + topOffsetInches / (currentView?.physicalPrintArea?.maxHeightInches || 14)}
                placementWidth={placementWidthInches / (currentView?.physicalPrintArea?.maxWidthInches || 12)}
                baseImageUrl={product.baseImageUrl}
                maskUrl={product.maskUrl}
              />
              <div className="mt-6 flex justify-center">
                <button onClick={() => setViewMode('edit')} className="px-6 py-2 rounded-full bg-[#1a1a1a] border border-[#D4AF37]/30 text-[#D4AF37] font-condensed font-bold uppercase tracking-widest hover:bg-[#D4AF37]/10 transition-all">← Back to Editor</button>
              </div>
            </div>
          </div>
        )}
        <RightPanel
          selectedObject={selectedObject}
          product={product}
          currentView={currentView}
          currentColor={currentColor}
          colors={product.colors}
          placement={{ widthInches: placementWidthInches, heightInches: placementWidthInches * 0.75, topOffsetInches, horizontalOffsetInches: hOffsetInches }}
          onUpdateObject={handleUpdateObject}
          onRemoveBackground={handleRemoveBackground}
          onCropStart={handleCropStart}
          onColorChange={handleColorChange}
          onProductChange={handleProductChange}
          onPlacementChange={handlePlacementChange}
        />
      </div>
      {showProductBrowser && (
        <ProductBrowser currentProductId={productId} onSelectProduct={handleProductChange} onClose={() => setShowProductBrowser(false)} />
      )}
    </div>
  );
}
