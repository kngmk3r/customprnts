/**
 * CUSTOM PRNTS — Product Browser (v2)
 *
 * Category-based product selection with expandable product database.
 * Customers can browse products by category and select one.
 *
 * The architecture allows unlimited products to be added later.
 */

import { useState } from 'react';
import type { ProductDefinition, ProductCategory } from '../../data/productLibrary';
import { PRODUCT_CATEGORIES, getProductsByCategory } from '../../data/productLibrary';

interface ProductBrowserProps {
  currentProductId: string;
  onSelectProduct: (productId: string) => void;
  onClose: () => void;
}

export default function ProductBrowser({ currentProductId, onSelectProduct, onClose }: ProductBrowserProps) {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const handleCategoryClick = (catId: string) => {
    setExpandedCategory(expandedCategory === catId ? null : catId);
  };

  const handleProductSelect = (productId: string) => {
    onSelectProduct(productId);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-[#111111] rounded-2xl border border-[#2a2a2a] w-full max-w-2xl max-h-[80vh] overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#2a2a2a] flex items-center justify-between">
          <div>
            <h2 className="font-condensed text-lg font-bold text-white tracking-wider uppercase">
              Choose Product
            </h2>
            <p className="text-xs text-[#737373] font-body mt-0.5">
              Select a product to place your artwork on
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-lg text-[#737373] hover:text-white hover:bg-[#1a1a1a] transition-colors"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Category Grid */}
        <div className="p-4 overflow-y-auto max-h-[calc(80vh-80px)]">
          <div className="grid grid-cols-2 gap-2">
            {PRODUCT_CATEGORIES.map((cat) => {
              const products = getProductsByCategory(cat.id);
              const isExpanded = expandedCategory === cat.id;
              const hasCurrentProduct = products.some(p => p.id === currentProductId);

              return (
                <div key={cat.id} className="col-span-2">
                  {/* Category Header */}
                  <button
                    onClick={() => handleCategoryClick(cat.id)}
                    className={`
                      w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all
                      ${isExpanded
                        ? 'bg-[#D4AF37]/10 border border-[#D4AF37]/30'
                        : 'bg-[#1a1a1a] border border-[#2a2a2a] hover:border-[#D4AF37]/20'
                      }
                    `}
                  >
                    <span className="text-xl">{cat.icon}</span>
                    <div className="flex-1 text-left">
                      <span className={`font-condensed text-sm font-bold tracking-wider uppercase ${
                        isExpanded ? 'text-[#D4AF37]' : 'text-white'
                      }`}>
                        {cat.name}
                      </span>
                      <span className="text-[10px] text-[#737373] font-body ml-2">
                        {products.length} {products.length === 1 ? 'product' : 'products'}
                      </span>
                    </div>
                    {hasCurrentProduct && (
                      <span className="text-[9px] text-[#D4AF37] font-condensed tracking-wider uppercase">
                        Current
                      </span>
                    )}
                    <svg
                      width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
                      className={`text-[#737373] transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                    >
                      <path d="M6 9l6 6 6-6" />
                    </svg>
                  </button>

                  {/* Products in Category */}
                  {isExpanded && (
                    <div className="mt-2 ml-6 grid grid-cols-2 gap-2">
                      {products.map((product) => (
                        <button
                          key={product.id}
                          onClick={() => handleProductSelect(product.id)}
                          className={`
                            flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left
                            ${product.id === currentProductId
                              ? 'bg-[#D4AF37]/15 border border-[#D4AF37]/30'
                              : 'bg-[#0d0d0d] border border-[#2a2a2a] hover:border-[#D4AF37]/20 hover:bg-[#1a1a1a]'
                            }
                          `}
                        >
                          {/* Product preview placeholder */}
                          <div className={`
                            w-12 h-12 rounded-lg flex items-center justify-center text-lg shrink-0
                            ${product.id === currentProductId
                              ? 'bg-[#D4AF37]/10'
                              : 'bg-[#1a1a1a]'
                            }
                          `}>
                            {cat.icon}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={`font-condensed text-xs font-bold tracking-wider uppercase truncate ${
                              product.id === currentProductId ? 'text-[#D4AF37]' : 'text-white'
                            }`}>
                              {product.name}
                            </p>
                            <p className="text-[9px] text-[#737373] font-body truncate">
                              {product.viewpoints.length} views · {product.colors.length} colors
                            </p>
                          </div>
                          {product.id === currentProductId && (
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#D4AF37" strokeWidth="3">
                              <path d="M5 13l4 4L19 7" />
                            </svg>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
