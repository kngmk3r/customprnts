/**
 * CUSTOM PRNTS — Floating Toolbar (v2)
 *
 * Contextual floating menu that appears near the selected object.
 * Focuses on high-frequency "Intent-based" actions.
 */

import { useMemo } from 'react';

interface FloatingToolbarProps {
  selectedObject: any;
  canvas: any;
  onAction: (action: string, payload?: any) => void;
  trigger?: number; // Added trigger
}

export default function FloatingToolbar({ selectedObject, canvas, onAction, trigger }: FloatingToolbarProps) {
  const position = useMemo(() => {
    if (!selectedObject || !canvas) return null;
// ... rest same

    // Get the object's bounding rect in canvas pixel coordinates
    const rect = selectedObject.getBoundingRect(true, true);
    
    // Convert canvas coordinates to screen coordinates (CSS pixels)
    // We need to account for canvas scaling/retina display
    const zoom = canvas.getZoom();
    const vpt = canvas.viewportTransform;
    
    // Top-left of the bounding box
    const left = rect.left * zoom + vpt[4];
    const top = rect.top * zoom + vpt[5];
    const width = rect.width * zoom;

    // Positioning the toolbar above the object, centered
    return {
      left: left + width / 2,
      top: top - 48, // 48px offset above
    };
  }, [selectedObject, canvas]);

  if (!position) return null;

  const isText = selectedObject.type === 'textbox';
  const isImage = selectedObject.type === 'image';

  return (
    <div
      className="fixed z-50 flex items-center gap-1 p-1 bg-[#1a1a1a] border border-[#D4AF37]/40 rounded-xl shadow-2xl backdrop-blur-md -translate-x-1/2 animate-in fade-in zoom-in duration-150"
      style={{
        left: position.left,
        top: position.top,
      }}
    >
      {/* Universal Quick Actions */}
      <ActionButton icon="🗑️" label="Delete" onClick={() => onAction('delete')} danger />
      <div className="w-px h-6 bg-[#2a2a2a] mx-0.5" />

      {isText && (
        <>
          <ActionButton icon="🖋️" label="Edit" onClick={() => {
            selectedObject.enterEditing();
            canvas.renderAll();
          }} />
          <ActionButton icon="🎨" label="Color" onClick={() => onAction('focus-tab', 'text')} />
        </>
      )}

      {isImage && (
        <>
          <ActionButton icon="✂️" label="Remove BG" onClick={() => onAction('remove-bg')} />
          <ActionButton icon="🌈" label="Styles" onClick={() => onAction('focus-tab', 'styles')} />
        </>
      )}

      <ActionButton icon="📋" label="Clone" onClick={() => onAction('duplicate')} />
      
      {/* Quick Layer Reorder */}
      <div className="w-px h-6 bg-[#2a2a2a] mx-0.5" />
      <ActionButton icon="🔝" label="Front" onClick={() => onAction('bring-to-front')} />
    </div>
  );
}

function ActionButton({ icon, label, onClick, danger }: { icon: string; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      className={`
        flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg transition-all group
        ${danger 
          ? 'hover:bg-red-500/20 text-red-400' 
          : 'hover:bg-[#D4AF37]/20 text-[#737373] hover:text-white'
        }
      `}
      title={label}
    >
      <span className="text-base leading-none">{icon}</span>
      <span className="text-[10px] font-condensed font-bold tracking-wider uppercase hidden group-hover:inline">
        {label}
      </span>
    </button>
  );
}
