/**
 * CUSTOM PRNTS — Mockup Renderer
 *
 * Renders a realistic 2.5D product mockup.
 * When a `baseImageUrl` is provided, overlays the artwork PNG onto the actual
 * product image using the `maskUrl` for clipping. Otherwise falls back to
 * canvas-drawn product silhouettes (colored rectangles with t-shirt/hoodie shapes).
 */

import { useEffect, useRef, useCallback, useState } from 'react';
import type { ProductTemplate } from '../types';

interface MockupRendererProps {
  productTemplate: ProductTemplate;
  viewId: string;
  productColor: string;
  artworkDataUrl: string | null;
  placementX: number;
  placementY: number;
  placementWidth: number;
  /** Real product image URL — when provided, composites artwork onto actual image */
  baseImageUrl?: string | null;
  /** SVG/image mask for clipping artwork onto product shape */
  maskUrl?: string | null;
  className?: string;
  onRetry?: () => void;
}

function getTShirtPath(w: number, h: number): Path2D {
  const p = new Path2D();
  const cx = w / 2;
  p.moveTo(cx - w * 0.15, h * 0.02);
  p.lineTo(cx - w * 0.12, h * 0.04);
  p.lineTo(cx + w * 0.12, h * 0.04);
  p.lineTo(cx + w * 0.15, h * 0.02);
  p.lineTo(cx * 1.85, h * 0.12);
  p.lineTo(w * 0.98, h * 0.25);
  p.lineTo(w * 0.85, h * 0.32);
  p.lineTo(cx + w * 0.25, h * 0.28);
  p.lineTo(cx + w * 0.25, h * 0.95);
  p.lineTo(cx - w * 0.25, h * 0.95);
  p.lineTo(cx - w * 0.25, h * 0.28);
  p.lineTo(w * 0.15, h * 0.32);
  p.lineTo(w * 0.02, h * 0.25);
  p.lineTo(w * 0.15, h * 0.12);
  p.closePath();
  return p;
}

function getHoodiePath(w: number, h: number): Path2D {
  const p = new Path2D();
  const cx = w / 2;
  p.moveTo(cx - w * 0.18, h * 0.0);
  p.quadraticCurveTo(cx - w * 0.2, h * -0.02, cx - w * 0.15, h * -0.05);
  p.quadraticCurveTo(cx, h * -0.08, cx + w * 0.15, h * -0.05);
  p.quadraticCurveTo(cx + w * 0.2, h * -0.02, cx + w * 0.18, h * 0.0);
  p.lineTo(cx + w * 0.2, h * 0.04);
  p.lineTo(cx * 1.85, h * 0.14);
  p.lineTo(w * 0.96, h * 0.26);
  p.lineTo(w * 0.84, h * 0.34);
  p.lineTo(cx + w * 0.25, h * 0.30);
  p.lineTo(cx + w * 0.25, h * 0.95);
  p.lineTo(cx - w * 0.25, h * 0.95);
  p.lineTo(cx - w * 0.25, h * 0.30);
  p.lineTo(w * 0.16, h * 0.34);
  p.lineTo(w * 0.04, h * 0.26);
  p.lineTo(w * 0.15, h * 0.14);
  p.lineTo(cx - w * 0.2, h * 0.04);
  p.closePath();
  return p;
}

function getGenericPath(w: number, h: number): Path2D {
  const p = new Path2D();
  const r = Math.min(20, w * 0.04, h * 0.04);
  p.moveTo(r, 0);
  p.lineTo(w - r, 0);
  p.quadraticCurveTo(w, 0, w, r);
  p.lineTo(w, h - r);
  p.quadraticCurveTo(w, h, w - r, h);
  p.lineTo(r, h);
  p.quadraticCurveTo(0, h, 0, h - r);
  p.lineTo(0, r);
  p.quadraticCurveTo(0, 0, r, 0);
  p.closePath();
  return p;
}

export default function MockupRenderer({
  productTemplate, viewId, productColor, artworkDataUrl,
  placementX, placementY, placementWidth, baseImageUrl, maskUrl,
  className = '', onRetry,
}: MockupRendererProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const artworkImgRef = useRef<HTMLImageElement | null>(null);
  const baseImgRef = useRef<HTMLImageElement | null>(null);
  const maskImgRef = useRef<HTMLImageElement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);

  // Track mount
  useEffect(() => { setMounted(true); }, []);

  // Load base product image (when provided)
  useEffect(() => {
    if (!baseImageUrl) {
      baseImgRef.current = null;
      return;
    }
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => { baseImgRef.current = img; };
    img.onerror = () => { baseImgRef.current = null; };
    img.src = baseImageUrl;
  }, [baseImageUrl]);

  // Load mask image (when provided)
  useEffect(() => {
    if (!maskUrl) {
      maskImgRef.current = null;
      return;
    }
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => { maskImgRef.current = img; };
    img.onerror = () => { maskImgRef.current = null; };
    img.src = maskUrl;
  }, [maskUrl]);

  // Load artwork image with retry
  useEffect(() => {
    if (!artworkDataUrl) {
      artworkImgRef.current = null;
      setLoading(false);
      requestAnimationFrame(() => renderMockup());
      return;
    }
    setLoading(true);
    setError(null);
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      artworkImgRef.current = img;
      setLoading(false);
      requestAnimationFrame(() => renderMockup());
    };
    img.onerror = () => {
      setError('Failed to load artwork for mockup preview');
      setLoading(false);
      artworkImgRef.current = null;
      renderMockup();
    };
    img.src = artworkDataUrl;
  }, [artworkDataUrl]); // eslint-disable-line react-hooks/exhaustive-deps

  // Re-render when dependencies change
  useEffect(() => {
    if (mounted && productTemplate) renderMockup();
  }, [productColor, viewId, placementX, placementY, placementWidth, mounted, productTemplate, baseImageUrl, maskUrl]); // eslint-disable-line react-hooks/exhaustive-deps

  const renderMockup = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) { setError('Canvas context unavailable'); return; }

    if (!productTemplate) {
      console.error('[MockupRenderer] productTemplate is null/undefined');
      setError('Product template not loaded');
      return;
    }

    try {
      const w = canvas.width;
      const h = canvas.height;

      // Clear
      ctx.clearRect(0, 0, w, h);

      // Background
      ctx.fillStyle = '#111111';
      ctx.fillRect(0, 0, w, h);

      // Get product shape
      let shape: Path2D;
      const cat = productTemplate.category;
      if (cat === 'garment') {
        const sub = productTemplate.subcategory.toLowerCase();
        if (sub.includes('hoodie')) shape = getHoodiePath(w, h);
        else shape = getTShirtPath(w, h);
      } else {
        shape = getGenericPath(w, h);
      }

      // ═══ COMPOSITING MODE ═══
      // When baseImageUrl is available, composite artwork onto the real product image.
      // When maskUrl is available, use it to clip the artwork to the product shape.
      const hasRealProduct = baseImgRef.current !== null;

      if (hasRealProduct) {
        // ── Real Product Image Mode ──
        ctx.save();

        // Draw the product base image
        const baseImg = baseImgRef.current!;
        const baseAspect = baseImg.naturalWidth / baseImg.naturalHeight;
        const canvasAspect = w / h;
        let drawW: number, drawH: number, drawX: number, drawY: number;
        if (baseAspect > canvasAspect) {
          drawW = w;
          drawH = w / baseAspect;
          drawX = 0;
          drawY = (h - drawH) / 2;
        } else {
          drawH = h;
          drawW = h * baseAspect;
          drawX = (w - drawW) / 2;
          drawY = 0;
        }
        ctx.drawImage(baseImg, drawX, drawY, drawW, drawH);

        // Overlay artwork if present
        if (artworkImgRef.current) {
          ctx.save();

          // ── Composite artwork onto product ──
          const artW = w * placementWidth;
          const artRatio = artworkImgRef.current.naturalHeight / artworkImgRef.current.naturalWidth;
          const artH = artW * artRatio;
          const artX = w * placementX - artW / 2;
          const artY = h * placementY - artH / 2;

          if (maskImgRef.current) {
            // High-fidelity masking using offscreen canvas
            const maskCanvas = document.createElement('canvas');
            maskCanvas.width = w;
            maskCanvas.height = h;
            const mctx = maskCanvas.getContext('2d')!;

            // 1. Draw the mask
            mctx.drawImage(maskImgRef.current, drawX, drawY, drawW, drawH);
            
            // 2. Composite the artwork using 'source-in'
            mctx.globalCompositeOperation = 'source-in';
            mctx.globalAlpha = 0.95;
            mctx.drawImage(artworkImgRef.current, artX, artY, artW, artH);
            
            // 3. Render result to main canvas
            ctx.drawImage(maskCanvas, 0, 0);
          } else {
            // Fallback to silhouette clip
            ctx.clip(shape);
            ctx.globalAlpha = 0.92;
            ctx.drawImage(artworkImgRef.current, artX, artY, artW, artH);
          }

          ctx.restore();
        }

        // Subtle highlight
        ctx.save();
        ctx.clip(shape);
        const highlightGrad = ctx.createLinearGradient(0, 0, w * 0.3, h * 0.3);
        highlightGrad.addColorStop(0, 'rgba(255,255,255,0.06)');
        highlightGrad.addColorStop(0.5, 'rgba(255,255,255,0.02)');
        highlightGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = highlightGrad;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();

        ctx.restore();
      } else {
        // ── Fallback: Colored Shape Mode ──

        // 1. Product base color
        ctx.save();
        ctx.fillStyle = productColor;
        ctx.fill(shape);

        // 2. Fabric texture (subtle noise)
        ctx.globalAlpha = 0.06;
        const pixelCount = Math.min(2000, w * h / 100);
        for (let i = 0; i < pixelCount; i++) {
          const x = Math.random() * w;
          const y = Math.random() * h;
          ctx.fillStyle = Math.random() > 0.5 ? '#ffffff' : '#000000';
          ctx.fillRect(x, y, 1, 1);
        }
        ctx.globalAlpha = 1;
        ctx.restore();

        // 3. Shadow / wrinkle effect
        ctx.save();
        ctx.clip(shape);
        ctx.globalAlpha = 0.12;

        // Vertical fold line
        const grad = ctx.createLinearGradient(w * 0.48, 0, w * 0.52, 0);
        grad.addColorStop(0, 'transparent');
        grad.addColorStop(0.5, 'rgba(0,0,0,0.15)');
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);

        // Shoulder shadows
        const shoulderGrad = ctx.createRadialGradient(w * 0.5, h * 0.08, 0, w * 0.5, h * 0.08, w * 0.4);
        shoulderGrad.addColorStop(0, 'rgba(0,0,0,0.1)');
        shoulderGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = shoulderGrad;
        ctx.fillRect(0, 0, w, h);

        // Bottom hem shadow
        const hemGrad = ctx.createLinearGradient(0, h * 0.85, 0, h);
        hemGrad.addColorStop(0, 'transparent');
        hemGrad.addColorStop(1, 'rgba(0,0,0,0.15)');
        ctx.fillStyle = hemGrad;
        ctx.fillRect(0, 0, w, h);

        ctx.restore();

        // 4. Artwork
        if (artworkImgRef.current) {
          ctx.save();
          ctx.clip(shape);

          const artW = w * placementWidth;
          const artRatio = artworkImgRef.current.naturalHeight / artworkImgRef.current.naturalWidth;
          const artH = artW * artRatio;
          const artX = w * placementX - artW / 2;
          const artY = h * placementY - artH / 2;

          ctx.globalAlpha = 0.95;
          ctx.drawImage(artworkImgRef.current, artX, artY, artW, artH);
          ctx.globalAlpha = 1;

          ctx.restore();
        }

        // 5. Highlight overlay
        ctx.save();
        ctx.clip(shape);
        const highlightGrad2 = ctx.createLinearGradient(0, 0, w * 0.3, h * 0.3);
        highlightGrad2.addColorStop(0, 'rgba(255,255,255,0.08)');
        highlightGrad2.addColorStop(0.5, 'rgba(255,255,255,0.02)');
        highlightGrad2.addColorStop(1, 'transparent');
        ctx.fillStyle = highlightGrad2;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();

        // 6. Subtle edge outline
        ctx.save();
        ctx.strokeStyle = 'rgba(255,255,255,0.08)';
        ctx.lineWidth = 1;
        ctx.stroke(shape);
        ctx.restore();
      }

      setError(null);
    } catch (err) {
      console.error('[MockupRenderer] Render error:', err);
      setError('Mockup rendering failed');
    }
  }, [productColor, productTemplate, viewId, placementX, placementY, placementWidth, baseImageUrl, maskUrl]); // eslint-disable-line react-hooks/exhaustive-deps

  // Retry handler
  const handleRetry = useCallback(() => {
    setError(null);
    setLoading(true);
    requestAnimationFrame(() => {
      setLoading(false);
      renderMockup();
    });
  }, [renderMockup]);

  if (error && !onRetry) {
    return (
      <div className={`relative ${className}`}>
        <div className="bg-studio-surface rounded-lg border border-studio-border p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <line x1="15" y1="9" x2="9" y2="15" />
              <line x1="9" y1="9" x2="15" y2="15" />
            </svg>
          </div>
          <p className="text-studio-muted text-sm font-condensed uppercase tracking-wider mb-4">{error}</p>
          <button onClick={handleRetry} className="studio-btn-primary !px-4 !py-2 !text-xs">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="inline mr-1">
              <path d="M1 4v6h6M23 20v-6h-6" />
              <path d="M20.49 9A9 9 0 005.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 013.51 15" />
            </svg>
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative ${className}`}>
      {loading && (
        <div className="absolute inset-0 flex items-center justify-center z-10 bg-studio-bg/80 rounded-lg">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-studio-gold border-t-transparent rounded-full animate-spin mx-auto mb-2" />
            <p className="text-studio-muted text-xs font-condensed uppercase tracking-wider">Loading mockup…</p>
          </div>
        </div>
      )}
      <canvas
        ref={canvasRef}
        width={500}
        height={620}
        className="w-full h-auto rounded-lg"
        style={{ imageRendering: 'auto' }}
      />
      {!artworkDataUrl && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <p className="text-studio-muted/50 text-xs font-condensed uppercase tracking-wider">No artwork to preview</p>
        </div>
      )}
    </div>
  );
}
