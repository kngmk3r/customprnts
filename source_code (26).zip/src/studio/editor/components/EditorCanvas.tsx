/**
 * CUSTOM PRNTS — Editor Canvas
 *
 * Fabric.js integration with:
 * - Snap guides
 * - Product overlay rendering
 * - Object serialization
 * - Selection management
 * - Touch support
 * - Zoom/pan
 */

import { useEffect, useRef, useCallback, useState } from 'react';
import type { ProductView, ProductTemplate } from '../types';
import { snapValue, getSnapPoints } from '../utils/measurementUtils';
import {
  isFabricImage,
  ensureOriginalSnapshot,
  removeBackground,
  makeTransparentByColorKey,
  restoreOriginal,
  applyAdjustments,
  applyPreset,
  type FilterPreset,
} from '../utils/imageEdits';

/* global fabric */
declare const fabric: any;
declare global { interface Window { fabric: any; } }

export interface CanvasAPI {
  getCanvas: () => any;
  loadImage: (url: string, storageKey: string) => Promise<void>;
  addText: (options?: Record<string, any>) => void;
  addImageFromUrl: (url: string, storageKey: string) => Promise<void>;
  getObjects: () => any[];
  deleteSelected: () => void;
  duplicateSelected: () => void;
  bringForward: () => void;
  sendBackward: () => void;
  bringToFront: () => void;
  sendToBack: () => void;
  selectAll: () => void;
  deselectAll: () => void;
  groupSelected: () => void;
  ungroupSelected: () => void;
  getSerializedState: () => string;
  loadSerializedState: (json: string) => Promise<void>;
  setProductOverlay: (view: ProductView, color: string) => void;
  clearProductOverlay: () => void;
  toggleSnap: (enabled: boolean) => void;
  exportTransparent: () => string;
  exportForDisplay: () => string;
  centerSelected: (axis: 'horizontal' | 'vertical' | 'both') => void;
  flipSelected: (axis: 'horizontal' | 'vertical') => void;
  resetTransform: () => void;
  // ── NEW: Image editing methods ──
  removeBackgroundFromSelected: (tolerance?: number, feather?: number) => Promise<boolean>;
  makeTransparentByKey: (r: number, g: number, b: number, tolerance?: number, feather?: number) => Promise<boolean>;
  restoreSelectedOriginal: () => Promise<boolean>;
  setSelectedOpacity: (opacity: number) => void;
  setSelectedAdjustments: (adj: { brightness: number; contrast: number; saturation: number }) => void;
  applyFilterPreset: (preset: 'none' | 'bw' | 'vintage' | 'vivid') => void;
  startCropMode: () => void;
  confirmCrop: () => void;
  cancelCrop: () => void;
  isInCropMode: () => boolean;
}

interface UseEditorCanvasParams {
  canvasRef: React.RefObject<HTMLCanvasElement>;
  productView: ProductView | null;
  productColor: string;
  snapEnabled: boolean;
  onSelectionChange: (obj: any) => void;
  onObjectModified: (grouped: boolean) => void;
  onCanvasReady: () => void;
}

export function useEditorCanvas({
  canvasRef,
  productView,
  productColor,
  snapEnabled,
  onSelectionChange,
  onObjectModified,
  onCanvasReady,
}: UseEditorCanvasParams): CanvasAPI {
  const fabricRef = useRef<any>(null);
  const productOverlayRef = useRef<any[]>([]);
  const snapRef = useRef(snapEnabled);
  const onCanvasReadyRef = useRef(onCanvasReady);
  const [ready, setReady] = useState(false);

  snapRef.current = snapEnabled;
  onCanvasReadyRef.current = onCanvasReady;

  // ── Initialize canvas ──
  useEffect(() => {
    if (!canvasRef.current || fabricRef.current) return;

    const canvas = new fabric.Canvas(canvasRef.current, {
      width: 800,
      height: 600,
      backgroundColor: 'transparent',
      selection: true,
      preserveObjectStacking: true,
      stopContextMenu: true,
      fireRightClick: true,
    });

    fabricRef.current = canvas;

    // Selection events
    canvas.on('selection:created', (e: any) => onSelectionChange(e.selected?.[0] || null));
    canvas.on('selection:updated', (e: any) => onSelectionChange(e.selected?.[0] || null));
    canvas.on('selection:cleared', () => onSelectionChange(null));

    // Object modification — grouped drag/resize
    let modGroupTimer: ReturnType<typeof setTimeout> | null = null;
    canvas.on('object:modified', () => {
      if (modGroupTimer) clearTimeout(modGroupTimer);
      modGroupTimer = setTimeout(() => onObjectModified(true), 50);
    });
    canvas.on('object:added', () => {
      // Skip initial load adds
      if ((canvas as any)._loaded) {
        onObjectModified(false);
      }
    });

    // Snap guides during object movement
    canvas.on('object:moving', (e: any) => {
      if (!snapRef.current || !productView) return;
      const obj = e.target;
      if (!obj || obj._isProductOverlay || obj._isPlacementGuide) return;

      const snapPts = getSnapPoints(
        productView.canvasWidth, productView.canvasHeight,
        productView.printableArea, productView.safeArea,
        productView.anchors
      );

      const tolerance = 8;
      const objCenterX = obj.left + (obj.width * obj.scaleX) / 2;
      const objCenterY = obj.top + (obj.height * obj.scaleY) / 2;

      const { snapped: snapX } = snapValue(objCenterX, snapPts.horizontal, tolerance);
      const { snapped: snapY } = snapValue(objCenterY, snapPts.vertical, tolerance);

      if (Math.abs(snapX - objCenterX) < tolerance) {
        obj.set('left', snapX - (obj.width * obj.scaleX) / 2);
      }
      if (Math.abs(snapY - objCenterY) < tolerance) {
        obj.set('top', snapY - (obj.height * obj.scaleY) / 2);
      }
    });

    (canvas as any)._loaded = false;
    setReady(true);
    console.log('[EditorCanvas] Canvas initialized, calling onCanvasReady');
    onCanvasReadyRef.current();

    return () => {
      canvas.dispose();
      fabricRef.current = null;
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Resize to container ──
  useEffect(() => {
    if (!fabricRef.current) return;
    const canvas = fabricRef.current;

    const handleResize = () => {
      const container = canvasRef.current?.parentElement;
      if (!container) return;
      const w = Math.min(container.clientWidth - 16, 900);
      const h = Math.min(w * 0.8, 700);
      canvas.setDimensions({ width: w, height: h });
      canvas.renderAll();
    };

    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, [ready]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── API methods ──

  const loadImage = useCallback(async (url: string, storageKey: string) => {
    const canvas = fabricRef.current;
    console.log('[EditorCanvas] loadImage called:', { url: url?.substring(0, 80), hasCanvas: !!canvas });
    if (!canvas) {
      console.error('[EditorCanvas] loadImage: canvas is null!');
      return;
    }

    return new Promise<void>((resolve) => {
      const imgEl = new Image();
      imgEl.crossOrigin = 'anonymous';
      imgEl.onload = () => {
        const fabricImg = new fabric.Image(imgEl, {
          left: canvas.width / 2,
          top: canvas.height / 2,
          originX: 'center',
          originY: 'center',
          selectable: true,
          hasControls: true,
          hasBorders: true,
        });

        // Scale to fit
        const maxW = canvas.width * 0.7;
        const maxH = canvas.height * 0.7;
        const scale = Math.min(maxW / imgEl.naturalWidth, maxH / imgEl.naturalHeight, 1);
        fabricImg.scale(scale);

        (fabricImg as any)._storageKey = storageKey;
        (fabricImg as any)._originalWidth = imgEl.naturalWidth;
        (fabricImg as any)._originalHeight = imgEl.naturalHeight;
        (fabricImg as any)._objectName = 'Generated Artwork';

        canvas.add(fabricImg);
        canvas.setActiveObject(fabricImg);
        canvas.renderAll();
        (canvas as any)._loaded = true;
        resolve();
      };
      imgEl.onerror = () => {
        (canvas as any)._loaded = true;
        resolve();
      };
      imgEl.src = url;
    });
  }, []);

  const addImageFromUrl = useCallback(async (url: string, storageKey: string) => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    return new Promise<void>((resolve) => {
      const imgEl = new Image();
      imgEl.crossOrigin = 'anonymous';
      imgEl.onload = () => {
        const fabricImg = new fabric.Image(imgEl, {
          left: canvas.width / 2,
          top: canvas.height / 2,
          originX: 'center',
          originY: 'center',
        });
        const maxW = canvas.width * 0.5;
        const maxH = canvas.height * 0.5;
        const scale = Math.min(maxW / imgEl.naturalWidth, maxH / imgEl.naturalHeight, 1);
        fabricImg.scale(scale);

        (fabricImg as any)._storageKey = storageKey;
        (fabricImg as any)._originalWidth = imgEl.naturalWidth;
        (fabricImg as any)._originalHeight = imgEl.naturalHeight;
        (fabricImg as any)._objectName = 'Uploaded Logo';

        canvas.add(fabricImg);
        canvas.setActiveObject(fabricImg);
        canvas.renderAll();
        resolve();
      };
      imgEl.onerror = () => resolve();
      imgEl.src = url;
    });
  }, []);

  const addText = useCallback((options?: Record<string, any>) => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const text = new fabric.Textbox('Your Text', {
      left: canvas.width / 2,
      top: canvas.height / 2,
      originX: 'center',
      originY: 'center',
      width: 300,
      fontSize: 48,
      fontFamily: 'Oswald',
      fill: '#FAFAFA',
      textAlign: 'center',
      ...options,
    });
    (text as any)._objectName = 'Text';
    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();
  }, []);

  const deleteSelected = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (active && !(active as any)._isProductOverlay) {
      canvas.remove(active);
      canvas.discardActiveObject();
      canvas.renderAll();
    }
  }, []);

  const duplicateSelected = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active) return;
    active.clone((cloned: any) => {
      cloned.set({ left: (active.left || 0) + 20, top: (active.top || 0) + 20 });
      (cloned as any)._objectName = ((active as any)._objectName || 'Object') + ' Copy';
      canvas.add(cloned);
      canvas.setActiveObject(cloned);
      canvas.renderAll();
    });
  }, []);

  const bringForward = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (active) { canvas.bringObjectForward(active); canvas.renderAll(); }
  }, []);

  const sendBackward = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (active) { canvas.sendObjectBackwards(active); canvas.renderAll(); }
  }, []);

  const bringToFront = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (active) { canvas.bringObjectToFront(active); canvas.renderAll(); }
  }, []);

  const sendToBack = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (active) { canvas.sendObjectToBack(active); canvas.renderAll(); }
  }, []);

  const selectAll = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    canvas.discardActiveObject();
    const sel = new fabric.ActiveSelection(canvas.getObjects(), { canvas });
    canvas.setActiveObject(sel);
    canvas.renderAll();
  }, []);

  const deselectAll = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    canvas.discardActiveObject();
    canvas.renderAll();
  }, []);

  // ── Group / Ungroup ──
  const groupSelected = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active || active.type !== 'activeSelection') return;

    const group = active.toGroup();
    (group as any)._objectName = 'Group';
    (group as any)._isGroup = true;
    canvas.renderAll();
  }, []);

  const ungroupSelected = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active || active.type !== 'group') return;

    const items = active.toActiveSelection();
    canvas.renderAll();
  }, []);

  const getSerializedState = useCallback((): string => {
    const canvas = fabricRef.current;
    if (!canvas) return '{}';
    return JSON.stringify(canvas.toJSON([
      '_storageKey', '_originalWidth', '_originalHeight', '_objectName',
      '_isProductOverlay', '_isPlacementGuide',
      '_cpOriginalSrc', '_cpBgRemoved', '_cpTransparencyKey',
      '_cpAdjustments', '_cpFilterPreset',
    ]));
  }, []);

  const loadSerializedState = useCallback(async (json: string): Promise<void> => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    return new Promise<void>((resolve) => {
      canvas.loadFromJSON(json, () => {
        (canvas as any)._loaded = true;
        canvas.renderAll();
        resolve();
      });
    });
  }, []);

  const setProductOverlay = useCallback((view: ProductView, color: string) => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    // Clear old overlays
    clearProductOverlayFn(canvas);

    const { canvasWidth, canvasHeight, printableArea, safeArea, anchors } = view;

    // Resize canvas to match product view
    const container = canvasRef.current?.parentElement;
    if (container) {
      const maxW = Math.min(container.clientWidth - 16, 900);
      const ratio = canvasHeight / canvasWidth;
      const w = maxW;
      const h = Math.min(w * ratio, 700);
      canvas.setDimensions({ width: w, height: h });
    }

    // Background tint
    canvas.backgroundColor = '#0d0d0d';
    canvas.setWidth(view.canvasWidth);
    canvas.setHeight(view.canvasHeight);

    // Product body (t-shirt shape approximation)
    const body = new fabric.Rect({
      left: 0, top: 0, width: canvasWidth, height: canvasHeight,
      fill: color, selectable: false, evented: false,
    });
    (body as any)._isProductOverlay = true;
    canvas.add(body);
    productOverlayRef.current.push(body);

    // Printable area boundary (dashed)
    const printBoundary = new fabric.Rect({
      left: printableArea.x, top: printableArea.y,
      width: printableArea.width, height: printableArea.height,
      fill: 'transparent', stroke: '#D4AF37', strokeWidth: 1,
      strokeDashArray: [8, 4], selectable: false, evented: false,
    });
    (printBoundary as any)._isPlacementGuide = true;
    (printBoundary as any)._objectName = 'Printable Area';
    canvas.add(printBoundary);
    productOverlayRef.current.push(printBoundary);

    // Safe area (lighter dashed)
    const safeBoundary = new fabric.Rect({
      left: safeArea.x, top: safeArea.y,
      width: safeArea.width, height: safeArea.height,
      fill: 'transparent', stroke: 'rgba(212,175,55,0.3)', strokeWidth: 1,
      strokeDashArray: [4, 4], selectable: false, evented: false,
    });
    (safeBoundary as any)._isPlacementGuide = true;
    canvas.add(safeBoundary);
    productOverlayRef.current.push(safeBoundary);

    // Center lines
    const hCenter = new fabric.Line(
      [canvasWidth / 2, printableArea.y, canvasWidth / 2, printableArea.y + printableArea.height],
      { stroke: 'rgba(212,175,55,0.15)', strokeWidth: 1, strokeDashArray: [4, 4], selectable: false, evented: false }
    );
    (hCenter as any)._isPlacementGuide = true;
    canvas.add(hCenter);
    productOverlayRef.current.push(hCenter);

    const vCenter = new fabric.Line(
      [printableArea.x, canvasHeight / 2, printableArea.x + printableArea.width, canvasHeight / 2],
      { stroke: 'rgba(212,175,55,0.15)', strokeWidth: 1, strokeDashArray: [4, 4], selectable: false, evented: false }
    );
    (vCenter as any)._isPlacementGuide = true;
    canvas.add(vCenter);
    productOverlayRef.current.push(vCenter);

    // Anchor points
    for (const anchor of Object.values(anchors)) {
      const dot = new fabric.Circle({
        left: anchor.x - 3, top: anchor.y - 3,
        radius: 3, fill: '#D4AF37', selectable: false, evented: false,
      });
      (dot as any)._isPlacementGuide = true;
      canvas.add(dot);
      productOverlayRef.current.push(dot);
    }

    canvas.renderAll();
  }, []);

  function clearProductOverlayFn(canvas: any) {
    const toRemove = canvas.getObjects().filter((o: any) => o._isProductOverlay || o._isPlacementGuide);
    toRemove.forEach((o: any) => canvas.remove(o));
    productOverlayRef.current = [];
  }

  const clearProductOverlay = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    clearProductOverlayFn(canvas);
    canvas.renderAll();
  }, []);

  const toggleSnap = useCallback((enabled: boolean) => {
    snapRef.current = enabled;
  }, []);

  const exportTransparent = useCallback((): string => {
    const canvas = fabricRef.current;
    if (!canvas) return '';
    const origBg = canvas.backgroundColor;
    const origBgImg = canvas.backgroundImage;
    canvas.backgroundColor = 'transparent';
    canvas.backgroundImage = null;
    const toRemove = canvas.getObjects().filter((o: any) => o._isProductOverlay || o._isPlacementGuide);
    toRemove.forEach((o: any) => canvas.remove(o));
    canvas.renderAll();
    const dataUrl = canvas.toDataURL({ format: 'png', multiplier: 2 });
    canvas.backgroundColor = origBg;
    canvas.backgroundImage = origBgImg;
    toRemove.forEach((o: any) => canvas.add(o));
    canvas.renderAll();
    return dataUrl;
  }, []);

  const exportForDisplay = useCallback((): string => {
    const canvas = fabricRef.current;
    if (!canvas) return '';
    return canvas.toDataURL({ format: 'png', multiplier: 1 });
  }, []);

  const centerSelected = useCallback((axis: 'horizontal' | 'vertical' | 'both') => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active) return;
    if (axis === 'horizontal' || axis === 'both') {
      active.set('left', canvas.width / 2);
      active.set('originX', 'center');
    }
    if (axis === 'vertical' || axis === 'both') {
      active.set('top', canvas.height / 2);
      active.set('originY', 'center');
    }
    active.setCoords();
    canvas.renderAll();
  }, []);

  const flipSelected = useCallback((axis: 'horizontal' | 'vertical') => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active) return;
    if (axis === 'horizontal') active.set('flipX', !active.flipX);
    else active.set('flipY', !active.flipY);
    canvas.renderAll();
  }, []);

  const resetTransform = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active) return;
    active.set({
      scaleX: 1, scaleY: 1, angle: 0, flipX: false, flipY: false,
    });
    active.setCoords();
    canvas.renderAll();
  }, []);

  // ── Crop mode state ──
  const cropModeRef = useRef(false);
  const cropOverlayRef = useRef<any>(null);

  const startCropMode = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active || !isFabricImage(active)) return;

    cropModeRef.current = true;

    // Draw crop overlay rectangle over the image bounds
    const br = active.getBoundingRect(true, true);
    const cropRect = new fabric.Rect({
      left: br.left,
      top: br.top,
      width: br.width,
      height: br.height,
      fill: 'rgba(212,175,55,0.1)',
      stroke: '#D4AF37',
      strokeWidth: 2,
      strokeDashArray: [8, 4],
      cornerColor: '#D4AF37',
      cornerStyle: 'circle',
      cornerSize: 12,
      transparentCorners: false,
      hasRotatingPoint: false,
      lockRotation: true,
      _isCropOverlay: true,
    });
    cropOverlayRef.current = cropRect;
    canvas.add(cropRect);
    canvas.setActiveObject(cropRect);
    canvas.renderAll();
  }, []);

  const confirmCrop = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas || !cropOverlayRef.current) return;

    const cropRect = cropOverlayRef.current;
    const objects = canvas.getObjects();
    const image = objects.find((o: any) => isFabricImage(o) && !o._isProductOverlay && !o._isPlacementGuide);
    if (!image) { cancelCrop(); return; }

    // Calculate crop relative to image
    const imgBr = image.getBoundingRect(true, true);
    const crLeft = cropRect.left;
    const crTop = cropRect.top;
    const crW = cropRect.width * (cropRect.scaleX || 1);
    const crH = cropRect.height * (cropRect.scaleY || 1);

    // Compute crop in image-local coordinates
    const scale = image.scaleX || 1;
    const newCropX = (image.cropX || 0) + (crLeft - imgBr.left) / scale;
    const newCropY = (image.cropY || 0) + (crTop - imgBr.top) / scale;
    const newW = crW / scale;
    const newH = crH / scale;

    // Apply crop
    ensureOriginalSnapshot(image);
    image.set({
      cropX: Math.max(0, newCropX),
      cropY: Math.max(0, newCropY),
      width: newW,
      height: newH,
    });
    image.setCoords();

    // Remove crop overlay
    canvas.remove(cropRect);
    cropOverlayRef.current = null;
    cropModeRef.current = false;
    canvas.setActiveObject(image);
    canvas.renderAll();
  }, []);

  const cancelCrop = useCallback(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    if (cropOverlayRef.current) {
      canvas.remove(cropOverlayRef.current);
      cropOverlayRef.current = null;
    }
    cropModeRef.current = false;
    canvas.renderAll();
  }, []);

  const isInCropMode = useCallback((): boolean => cropModeRef.current, []);

  // ── Image editing methods ──

  const removeBackgroundFromSelected = useCallback(async (tolerance = 30, feather = 1): Promise<boolean> => {
    const canvas = fabricRef.current;
    if (!canvas) return false;
    const active = canvas.getActiveObject();
    if (!active || !isFabricImage(active)) return false;
    const result = await removeBackground(active, { tolerance, feather });
    if (result) {
      canvas.renderAll();
      onObjectModified(false);
    }
    return result;
  }, [onObjectModified]);

  const makeTransparentByKey = useCallback(async (r: number, g: number, b: number, tolerance = 30, feather = 1): Promise<boolean> => {
    const canvas = fabricRef.current;
    if (!canvas) return false;
    const active = canvas.getActiveObject();
    if (!active || !isFabricImage(active)) return false;
    const result = await makeTransparentByColorKey(active, { r, g, b, tolerance, feather });
    if (result) {
      canvas.renderAll();
      onObjectModified(false);
    }
    return result;
  }, [onObjectModified]);

  const restoreSelectedOriginal = useCallback(async (): Promise<boolean> => {
    const canvas = fabricRef.current;
    if (!canvas) return false;
    const active = canvas.getActiveObject();
    if (!active || !isFabricImage(active)) return false;
    const result = await restoreOriginal(active);
    if (result) {
      canvas.renderAll();
      onObjectModified(false);
    }
    return result;
  }, [onObjectModified]);

  const setSelectedOpacity = useCallback((opacity: number) => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active) return;
    active.set('opacity', Math.max(0, Math.min(1, opacity)));
    canvas.renderAll();
  }, []);

  const setSelectedAdjustments = useCallback((adj: { brightness: number; contrast: number; saturation: number }) => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active || !isFabricImage(active)) return;
    ensureOriginalSnapshot(active);
    applyAdjustments(active, adj);
    canvas.renderAll();
  }, []);

  const applyFilterPreset = useCallback((preset: FilterPreset) => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const active = canvas.getActiveObject();
    if (!active || !isFabricImage(active)) return;
    ensureOriginalSnapshot(active);
    applyPreset(active, preset);
    canvas.renderAll();
  }, []);

  return {
    getCanvas: () => fabricRef.current,
    loadImage,
    addText,
    addImageFromUrl,
    getObjects: () => fabricRef.current?.getObjects() || [],
    deleteSelected,
    duplicateSelected,
    bringForward,
    sendBackward,
    bringToFront,
    sendToBack,
    selectAll,
    deselectAll,
    groupSelected,
    ungroupSelected,
    getSerializedState,
    loadSerializedState,
    setProductOverlay,
    clearProductOverlay,
    toggleSnap,
    exportTransparent,
    exportForDisplay,
    centerSelected,
    flipSelected,
    resetTransform,
    // ── NEW: Image editing methods ──
    removeBackgroundFromSelected,
    makeTransparentByKey,
    restoreSelectedOriginal,
    setSelectedOpacity,
    setSelectedAdjustments,
    applyFilterPreset,
    startCropMode,
    confirmCrop,
    cancelCrop,
    isInCropMode,
  };
}
