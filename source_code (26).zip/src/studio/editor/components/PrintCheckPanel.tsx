/**
 * CUSTOM PRNTS — Print Check Panel
 *
 * Shows quality warnings, DPI status, boundary checks, and print-readiness.
 */

import type { QualityState, QualityWarning } from '../types';
import { formatDpi } from '../utils/measurementUtils';
import { getQualitySummary } from '../utils/qualityChecker';

interface PrintCheckPanelProps {
  quality: QualityState;
  projectName: string;
}

const SEVERITY_COLORS: Record<string, string> = {
  excellent: 'text-green-400 bg-green-400/10 border-green-400/20',
  good: 'text-blue-400 bg-blue-400/10 border-blue-400/20',
  caution: 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20',
  poor: 'text-red-400 bg-red-400/10 border-red-400/20',
};

const SEVERITY_DOTS: Record<string, string> = {
  excellent: 'bg-green-400',
  good: 'bg-blue-400',
  caution: 'bg-yellow-400',
  poor: 'bg-red-400',
};

const CATEGORY_ICONS: Record<string, string> = {
  resolution: '🔍',
  boundary: '📐',
  'safe-area': '🛡',
  background: '🎨',
  transparency: '👁',
  distortion: '↗',
  contrast: '◐',
  'text-size': 'Aa',
  general: 'ℹ',
};

export default function PrintCheckPanel({ quality, projectName }: PrintCheckPanelProps) {
  const summary = getQualitySummary(quality);
  const hasIssues = quality.warnings.some(w => w.severity === 'poor' || w.severity === 'caution');

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-3 py-2 border-b border-studio-border">
        <h3 className="font-condensed text-xs font-bold text-studio-gold tracking-wider uppercase">
          Print Check
        </h3>
      </div>

      {/* Status Summary */}
      <div className={`
        mx-3 mt-3 px-3 py-2.5 rounded-lg border
        ${hasIssues
          ? 'bg-yellow-400/5 border-yellow-400/20'
          : 'bg-green-400/5 border-green-400/20'
        }
      `}>
        <div className="flex items-center gap-2 mb-1">
          <div className={`w-2 h-2 rounded-full ${hasIssues ? 'bg-yellow-400' : 'bg-green-400'}`} />
          <span className="text-xs font-condensed font-bold text-white uppercase tracking-wider">
            {hasIssues ? 'Review Needed' : 'Print Ready'}
          </span>
        </div>
        <p className="text-[11px] text-studio-muted font-body">{summary}</p>
      </div>

      {/* DPI Badge */}
      <div className="mx-3 mt-3 px-3 py-2 bg-studio-surface rounded-lg border border-studio-border">
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-studio-muted font-condensed uppercase tracking-wider">
            Effective DPI
          </span>
          <div className="flex items-center gap-1.5">
            <div className={`w-2 h-2 rounded-full ${SEVERITY_DOTS[quality.dpiRating]}`} />
            <span className="text-xs font-mono text-white">
              {formatDpi(quality.effectiveDpi)}
            </span>
          </div>
        </div>
      </div>

      {/* Status Indicators */}
      <div className="mx-3 mt-2 space-y-1">
        <StatusDot
          label="Printable Area"
          ok={quality.withinPrintableArea}
          okText="Within bounds"
          failText="Exceeds boundary"
        />
        <StatusDot
          label="Safe Area"
          ok={quality.withinSafeArea}
          okText="Protected"
          failText="Content at risk"
        />
        <StatusDot
          label="Transparency"
          ok={quality.hasTransparency}
          okText="Transparent"
          warnText="Solid background"
        />
      </div>

      {/* Warnings List */}
      {quality.warnings.length > 0 && (
        <div className="px-3 mt-3 flex-1 overflow-y-auto">
          <h4 className="font-condensed text-[10px] font-bold text-studio-muted tracking-wider uppercase mb-2">
            Warnings ({quality.warnings.length})
          </h4>
          <div className="space-y-2">
            {quality.warnings.map(warning => (
              <WarningCard key={warning.id} warning={warning} />
            ))}
          </div>
        </div>
      )}

      {/* No warnings */}
      {quality.warnings.length === 0 && (
        <div className="px-3 mt-4 text-center">
          <p className="text-studio-muted text-[11px] font-condensed uppercase tracking-wider">
            All checks passed
          </p>
        </div>
      )}
    </div>
  );
}

function StatusDot({ label, ok, okText, failText, warnText }: {
  label: string;
  ok: boolean;
  okText: string;
  failText: string;
  warnText?: string;
}) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-[10px] text-studio-muted font-condensed uppercase tracking-wider">{label}</span>
      <span className={`text-[10px] font-condensed ${ok ? 'text-green-400' : 'text-yellow-400'}`}>
        {ok ? okText : (warnText || failText)}
      </span>
    </div>
  );
}

function WarningCard({ warning }: { warning: QualityWarning }) {
  return (
    <div className={`
      px-2.5 py-2 rounded-lg border
      ${SEVERITY_COLORS[warning.severity]}
    `}>
      <div className="flex items-start gap-2">
        <span className="text-xs shrink-0 mt-0.5">{CATEGORY_ICONS[warning.category] || 'ℹ'}</span>
        <div className="flex-1 min-w-0">
          <p className="text-[11px] font-body leading-tight">{warning.message}</p>
          {warning.suggestion && (
            <p className="text-[10px] font-body mt-1 opacity-70 leading-tight">{warning.suggestion}</p>
          )}
        </div>
      </div>
    </div>
  );
}
