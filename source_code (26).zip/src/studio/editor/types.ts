/**
 * CUSTOM PRNTS Editor — Core Type Definitions
 *
 * All editor state, product templates, placement, and production types.
 */

// ═══════════════════════════════════════════════════════════════
// PRODUCT TEMPLATES
// ═══════════════════════════════════════════════════════════════

export interface ProductArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface ProductAnchor {
  x: number;
  y: number;
  label: string;
}

export interface ProductPhysicalDimensions {
  maxWidthInches: number;
  maxHeightInches: number;
}

export interface ProductView {
  viewId: string; // 'front' | 'back' | 'left-sleeve' | 'right-sleeve'
  label: string;
  canvasWidth: number;
  canvasHeight: number;
  printableArea: ProductArea;
  safeArea: ProductArea;
  physicalPrintArea: ProductPhysicalDimensions;
  anchors: Record<string, ProductAnchor>;
}

export interface PlacementPreset {
  id: string;
  name: string;
  viewId: string;
  defaultWidthRatio: number; // fraction of printable area width
  maxWidthRatio: number;
  defaultTopOffsetRatio: number;
  horizontalAnchor: 'center' | 'left' | 'right';
  verticalAnchor: 'top' | 'center' | 'bottom';
  allowedPrintMethods: string[];
}

export interface ProductColor {
  id: string;
  name: string;
  hex: string;
  isDark: boolean;
}

export interface ProductTemplate {
  id: string;
  name: string;
  category: 'garment' | 'accessory' | 'print' | 'drinkware';
  subcategory: string;
  views: ProductView[];
  colors: ProductColor[];
  placementPresets: PlacementPreset[];
  supportedPrintMethods: string[];
  maskUrl?: string;       // SVG/canvas mask for mockup
  baseImageUrl?: string;  // base product image for mockup
}

// ═══════════════════════════════════════════════════════════════
// EDITOR OBJECTS
// ═══════════════════════════════════════════════════════════════

export type EditorObjectType = 'image' | 'text' | 'group' | 'shape';

export interface EditorObjectBase {
  id: string;
  type: EditorObjectType;
  name: string;
  visible: boolean;
  locked: boolean;
  left: number;
  top: number;
  width: number;
  height: number;
  scaleX: number;
  scaleY: number;
  angle: number;
  opacity: number;
  flipX: boolean;
  flipY: boolean;
}

export interface EditorImageObject extends EditorObjectBase {
  type: 'image';
  src: string;            // current URL (may be signed)
  storageKey: string;     // permanent storage key
  originalWidth: number;  // natural pixel width
  originalHeight: number; // natural pixel height
}

export interface EditorTextObject extends EditorObjectBase {
  type: 'text';
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: string;
  fontStyle: string;
  textDecoration: string;
  textTransform: 'none' | 'uppercase' | 'lowercase';
  fill: string;
  stroke: string;
  strokeWidth: number;
  shadowColor: string;
  shadowBlur: number;
  shadowOffsetX: number;
  shadowOffsetY: number;
  letterSpacing: number;
  lineHeight: number;
  textAlign: string;
  curveType: 'none' | 'arc-up' | 'arc-down';
  charSpacing: number;
}

export type EditorObject = EditorImageObject | EditorTextObject | EditorObjectBase;

// ═══════════════════════════════════════════════════════════════
// PLACEMENT & MEASUREMENTS
// ═══════════════════════════════════════════════════════════════

export interface PlacementState {
  presetId: string | null;
  presetName: string | null;
  widthInches: number;
  heightInches: number;
  topOffsetInches: number;
  horizontalOffsetInches: number;
  rotationDegrees: number;
  centered: boolean;
  viewId: string;
}

// ═══════════════════════════════════════════════════════════════
// QUALITY / PRINT CHECK
// ═══════════════════════════════════════════════════════════════

export type WarningSeverity = 'excellent' | 'good' | 'caution' | 'poor';

export interface QualityWarning {
  id: string;
  category: 'resolution' | 'boundary' | 'safe-area' | 'background' | 'transparency' | 'text-size' | 'distortion' | 'contrast' | 'general';
  severity: WarningSeverity;
  message: string;
  suggestion?: string;
}

export interface QualityState {
  effectiveDpi: number;
  dpiRating: WarningSeverity;
  withinPrintableArea: boolean;
  withinSafeArea: boolean;
  hasTransparency: boolean;
  warnings: QualityWarning[];
}

// ═══════════════════════════════════════════════════════════════
// CANVAS STATE — viewport, objects, UI hints
// ═══════════════════════════════════════════════════════════════

export type EditorViewMode = 'artwork' | 'placement' | 'mockup' | 'production';
export type ProductViewId = 'front' | 'back' | 'left-sleeve' | 'right-sleeve';

export interface CanvasState {
  width: number;
  height: number;
  zoom: number;
  panX: number;
  panY: number;
  objects: EditorObject[];
  snapEnabled: boolean;
  showGuides: boolean;
  rulerUnits: 'inches' | 'mm';
}

// ═══════════════════════════════════════════════════════════════
// PRODUCT STATE — which product, color, viewpoint
// ═══════════════════════════════════════════════════════════════

export interface ProductState {
  productId: string;
  colorId: string;
  viewId: ProductViewId;
}

// ═══════════════════════════════════════════════════════════════
// EDITOR STATE (composed)
// ═══════════════════════════════════════════════════════════════

export interface EditorState {
  /** Project identity — immutable within an editing session */
  projectId: string;
  sourceDesignId: string | null;
  activeRevisionId: string;
  /** Product selection (surface for placement) — independent of artwork */
  product: ProductState;
  /** Canvas viewport, layers, and UI settings */
  canvas: CanvasState;
  /** Artwork placement measurements on the product */
  placement: PlacementState;
  /** Print-quality checks */
  quality: QualityState;
  viewMode: EditorViewMode;
  lastSavedAt: string | null;
  revisionNumber: number;
}

// ═══════════════════════════════════════════════════════════════
// REVISIONS
// ═══════════════════════════════════════════════════════════════

export type RevisionStatus = 'generated' | 'editing' | 'saved' | 'superseded' | 'approved' | 'production_ready';

export interface DesignRevision {
  id: string;
  projectId: string;
  sourceDesignId: string;
  status: RevisionStatus;
  editorState: EditorState;
  mockupFrontUrl: string | null;
  mockupBackUrl: string | null;
  createdAt: string;
  updatedAt: string;
  approvedAt: string | null;
}

// ═══════════════════════════════════════════════════════════════
// PRODUCTION SPEC
// ═══════════════════════════════════════════════════════════════

export interface ProductionSpec {
  projectId: string;
  revisionId: string;
  product: string;
  productVariant: string;
  garmentColor: string;
  garmentColorHex: string;
  printSide: string;
  placementPreset: string;
  artworkWidthInches: number;
  artworkHeightInches: number;
  topOffsetInches: number;
  horizontalOffsetInches: number;
  rotationDegrees: number;
  horizontalAlignment: string;
  printMethod: string;
  effectiveDpi: number;
  transparentBackground: boolean;
  approvedAt: string;
  approvedByUserId: string;
}

// ═══════════════════════════════════════════════════════════════
// PRODUCTION PACKAGE
// ═══════════════════════════════════════════════════════════════

export interface ProductionPackage {
  artworkMasterPng: Blob | null;
  artworkPrintSizedPng: Blob | null;
  customerMockupFront: Blob | null;
  customerMockupBack: Blob | null;
  placementProof: Blob | null;
  editorProjectJson: string;
  productionSpecJson: string;
}
