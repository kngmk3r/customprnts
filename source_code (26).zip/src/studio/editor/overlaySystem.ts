/**
 * CUSTOM PRNTS — Overlay System
 *
 * Generic, extensible overlay registry for non-destructive UI layers
 * rendered above artwork. The original image is NEVER modified.
 *
 * Each overlay exists only as a CSS/HTML layer in the UI.
 * Removing an overlay simply hides that layer — no image processing ever.
 */

// ═══════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════

export type OverlayType =
  | 'watermark'
  | 'copyright-preview'
  | 'draft'
  | 'sample'
  | 'customer-name'
  | 'order-number'
  | 'print-safe-area'
  | 'bleed-guides'
  | 'crop-marks'
  | 'alignment-grid'
  | 'measurement-guides'
  | 'qr-code'
  | 'production-notes';

export interface OverlayConfig {
  /** Unique identifier for this overlay instance */
  id: string;
  /** The type of overlay */
  type: OverlayType;
  /** Whether this overlay is currently visible */
  visible: boolean;
  /** Type-specific configuration */
  config: Record<string, unknown>;
}

export interface OverlayRegistryEntry {
  type: OverlayType;
  label: string;
  description: string;
  /** Default config values when creating a new overlay of this type */
  defaultConfig: Record<string, unknown>;
}

// ═══════════════════════════════════════════════════════════════
// REGISTRY — all supported overlay types
// ═══════════════════════════════════════════════════════════════

export const OVERLAY_REGISTRY: OverlayRegistryEntry[] = [
  {
    type: 'watermark',
    label: 'Preview Watermark',
    description: 'Repeating diagonal text overlay to protect preview artwork',
    defaultConfig: {
      text: 'CUSTOM PRNTS',
      rotation: -40,       // degrees
      opacity: 0.10,       // 10%
      fontSize: 48,        // px
      color: '#ffffff',
      spacingX: 320,       // px horizontal spacing
      spacingY: 200,       // px vertical spacing
    },
  },
  {
    type: 'copyright-preview',
    label: 'Copyright Preview',
    description: 'Copyright notice overlay',
    defaultConfig: { text: '\u00a9 CUSTOM PRNTS \u2014 All Rights Reserved', opacity: 0.15 },
  },
  {
    type: 'draft',
    label: 'Draft Watermark',
    description: 'Large "DRAFT" stamp',
    defaultConfig: { text: 'DRAFT', opacity: 0.08, fontSize: 120 },
  },
  {
    type: 'sample',
    label: 'Sample Watermark',
    description: '"SAMPLE" overlay for proofs',
    defaultConfig: { text: 'SAMPLE', opacity: 0.10, fontSize: 100 },
  },
  {
    type: 'customer-name',
    label: 'Customer Name',
    description: 'Displays customer name on the artwork',
    defaultConfig: { name: '', opacity: 0.12 },
  },
  {
    type: 'order-number',
    label: 'Order Number',
    description: 'Displays order number',
    defaultConfig: { orderNumber: '', opacity: 0.12 },
  },
  {
    type: 'print-safe-area',
    label: 'Print Safe Area',
    description: 'Shows the safe printable area boundary',
    defaultConfig: { color: '#22c55e', opacity: 0.3, dashPattern: '8,4' },
  },
  {
    type: 'bleed-guides',
    label: 'Bleed Guides',
    description: 'Shows bleed margin lines',
    defaultConfig: { color: '#ef4444', opacity: 0.4, bleedInches: 0.125 },
  },
  {
    type: 'crop-marks',
    label: 'Crop Marks',
    description: 'Print crop marks at corners',
    defaultConfig: { color: '#000000', opacity: 0.5, length: 20 },
  },
  {
    type: 'alignment-grid',
    label: 'Alignment Grid',
    description: 'Grid overlay for alignment',
    defaultConfig: { gridSize: 50, color: '#ffffff', opacity: 0.08 },
  },
  {
    type: 'measurement-guides',
    label: 'Measurement Guides',
    description: 'Ruler/measurement overlay',
    defaultConfig: { color: '#ffffff', opacity: 0.15 },
  },
  {
    type: 'qr-code',
    label: 'QR Code',
    description: 'QR code overlay for production',
    defaultConfig: { url: '', opacity: 0.8 },
  },
  {
    type: 'production-notes',
    label: 'Production Notes',
    description: 'Internal notes overlay',
    defaultConfig: { notes: '', opacity: 0.2 },
  },
];

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

/** Get the registry entry for a given overlay type */
export function getOverlayEntry(type: OverlayType): OverlayRegistryEntry | undefined {
  return OVERLAY_REGISTRY.find(r => r.type === type);
}

/** Create a new OverlayConfig with sensible defaults */
export function createOverlayConfig(
  type: OverlayType,
  overrides?: Partial<OverlayConfig>,
): OverlayConfig {
  const entry = getOverlayEntry(type);
  return {
    id: `overlay_${type}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    type,
    visible: true,
    config: entry ? { ...entry.defaultConfig } : {},
    ...overrides,
  };
}

/** Create the default watermark overlay config */
export function createWatermarkOverlay(overrides?: Partial<OverlayConfig>): OverlayConfig {
  return createOverlayConfig('watermark', overrides);
}

/** Check if any overlay in the array is visible */
export function hasVisibleOverlays(overlays: OverlayConfig[]): boolean {
  return overlays.some(o => o.visible);
}

/** Get visible overlays only */
export function getVisibleOverlays(overlays: OverlayConfig[]): OverlayConfig[] {
  return overlays.filter(o => o.visible);
}

/** Check if a specific overlay type exists and is visible */
export function isOverlayVisible(overlays: OverlayConfig[], type: OverlayType): boolean {
  return overlays.some(o => o.type === type && o.visible);
}

/** Get overlay config values with type safety */
export function getOverlaySetting<T = unknown>(
  overlay: OverlayConfig,
  key: string,
  fallback: T,
): T {
  return (overlay.config[key] as T) ?? fallback;
}
