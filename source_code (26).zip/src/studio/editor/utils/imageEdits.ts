/**
 * CUSTOM PRNTS — Fabric Image Edit Helpers
 *
 * Glue layer between pixel operations and Fabric.js images.
 * Handles: background removal, color-key, adjustments, filters, restore original.
 */

/* global fabric */
declare const fabric: any;

import {
  loadImageToImageData,
  applyColorKey,
  removeBackgroundAuto,
  imageDataToDataUrl,
  type ColorKeyOptions,
  type BgRemovalOptions,
} from './imagePixelOps';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

export interface ImageAdjustments {
  brightness: number;  // -1 to 1
  contrast: number;    // -1 to 1
  saturation: number;  // -1 to 1
}

export type FilterPreset = 'none' | 'bw' | 'vintage' | 'vivid' | 'sepia' | 'technicolor' | 'polaroid' | 'kodachrome';

export interface StylePreset {
  id: FilterPreset;
  name: string;
  description: string;
  thumbnail: string; // Emoji or CSS pattern
}

export const STYLE_PRESETS: StylePreset[] = [
  { id: 'none', name: 'Original', description: 'No effects', thumbnail: '🖼️' },
  { id: 'vivid', name: 'Vivid', description: 'High saturation and pop', thumbnail: '🌈' },
  { id: 'vintage', name: 'Vintage', description: 'Retro film look', thumbnail: '🎞️' },
  { id: 'bw', name: 'Noir', description: 'Classic black and white', thumbnail: '🌚' },
  { id: 'sepia', name: 'Sepia', description: 'Warm antique tone', thumbnail: '📜' },
  { id: 'technicolor', name: 'Tech', description: 'Extreme color vibrancy', thumbnail: '🕹️' },
  { id: 'polaroid', name: 'Instant', description: 'Soft, faded colors', thumbnail: '📸' },
  { id: 'kodachrome', name: 'Chrome', description: 'Deep reds and greens', thumbnail: '💎' },
];

// ═══════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════

export function isFabricImage(obj: any): obj is any {
  return obj && obj.type === 'image';
}

/**
 * Ensure we have an original snapshot for undo/restore.
 * Only snapshots if _cpOriginalSrc is not already set.
 */
export function ensureOriginalSnapshot(fImg: any): void {
  if (fImg._cpOriginalSrc) return;
  try {
    fImg._cpOriginalSrc = fImg.toDataURL({ format: 'png', multiplier: 1 });
  } catch {
    // CORS may prevent toDataURL — store the current src as fallback
    fImg._cpOriginalSrc = fImg.getSrc?.() || fImg.src;
  }
}

/**
 * Safely set a Fabric image's source with CORS handling.
 */
export function setFabricImageSrc(fImg: any, src: string): Promise<void> {
  return new Promise((resolve) => {
    fImg.setSrc(src, () => resolve(), { crossOrigin: 'anonymous' });
  });
}

// ═══════════════════════════════════════════════════════════════════
// BACKGROUND REMOVAL
// ═══════════════════════════════════════════════════════════════════

/**
 * Auto-remove background from a Fabric image.
 * Uses edge flood-fill estimation.
 */
export async function removeBackground(
  fImg: any,
  options: BgRemovalOptions = { tolerance: 30, feather: 1 }
): Promise<boolean> {
  if (!isFabricImage(fImg)) return false;

  ensureOriginalSnapshot(fImg);
  const src = fImg.getSrc?.() || fImg.src;
  if (!src) return false;

  const imageData = await loadImageToImageData(src, 2048);
  if (!imageData) return false;

  removeBackgroundAuto(imageData, options);
  const newDataUrl = imageDataToDataUrl(imageData);

  return new Promise((resolve) => {
    fImg.setSrc(newDataUrl, () => {
      fImg._cpBgRemoved = true;
      resolve(true);
    }, { crossOrigin: 'anonymous' });
  });
}

/**
 * Apply color-key transparency to a Fabric image.
 */
export async function makeTransparentByColorKey(
  fImg: any,
  options: ColorKeyOptions
): Promise<boolean> {
  if (!isFabricImage(fImg)) return false;

  ensureOriginalSnapshot(fImg);
  const src = fImg.getSrc?.() || fImg.src;
  if (!src) return false;

  const imageData = await loadImageToImageData(src, 2048);
  if (!imageData) return false;

  applyColorKey(imageData, options);
  const newDataUrl = imageDataToDataUrl(imageData);

  return new Promise((resolve) => {
    fImg.setSrc(newDataUrl, () => {
      fImg._cpBgRemoved = true;
      fImg._cpTransparencyKey = options;
      resolve(true);
    }, { crossOrigin: 'anonymous' });
  });
}

/**
 * Restore a Fabric image to its original state.
 */
export async function restoreOriginal(fImg: any): Promise<boolean> {
  if (!isFabricImage(fImg) || !fImg._cpOriginalSrc) return false;

  return new Promise((resolve) => {
    fImg.setSrc(fImg._cpOriginalSrc, () => {
      fImg._cpBgRemoved = false;
      fImg._cpTransparencyKey = null;
      fImg._cpAdjustments = null;
      fImg._cpFilterPreset = 'none';
      fImg.filters = [];
      fImg.applyFilters();
      resolve(true);
    }, { crossOrigin: 'anonymous' });
  });
}

// ═══════════════════════════════════════════════════════════════════
// IMAGE ADJUSTMENTS
// ═══════════════════════════════════════════════════════════════════

/**
 * Apply brightness/contrast/saturation adjustments to a Fabric image.
 * Uses Fabric's built-in filter system which exports correctly.
 */
export function applyAdjustments(fImg: any, adj: ImageAdjustments): void {
  if (!isFabricImage(fImg)) return;

  fImg._cpAdjustments = adj;
  fImg._cpFilterPreset = 'custom';

  // Build filters from adjustments + any active preset
  const filters: any[] = [];

  // Brightness
  if (adj.brightness !== 0) {
    filters.push(new fabric.Image.filters.Brightness({ brightness: adj.brightness }));
  }

  // Contrast
  if (adj.contrast !== 0) {
    filters.push(new fabric.Image.filters.Contrast({ contrast: adj.contrast }));
  }

  // Saturation
  if (adj.saturation !== 0) {
    filters.push(new fabric.Image.filters.Saturation({ saturation: adj.saturation }));
  }

  fImg.filters = filters;
  fImg.applyFilters();
}

/**
 * Apply a one-tap filter preset.
 */
export function applyPreset(fImg: any, preset: FilterPreset): void {
  if (!isFabricImage(fImg)) return;

  fImg._cpFilterPreset = preset;
  const filters: any[] = [];

  // Preserve user adjustments
  const adj = fImg._cpAdjustments || { brightness: 0, contrast: 0, saturation: 0 };

  switch (preset) {
    case 'none':
      // Just apply user adjustments
      break;

    case 'bw':
      filters.push(new fabric.Image.filters.Grayscale());
      break;

    case 'vintage':
      filters.push(new fabric.Image.filters.Sepia());
      filters.push(new fabric.Image.filters.Brightness({ brightness: -0.05 }));
      filters.push(new fabric.Image.filters.Contrast({ contrast: 0.1 }));
      break;

    case 'vivid':
      filters.push(new fabric.Image.filters.Saturation({ saturation: 0.5 }));
      filters.push(new fabric.Image.filters.Contrast({ contrast: 0.15 }));
      filters.push(new fabric.Image.filters.Brightness({ brightness: 0.05 }));
      break;

    case 'sepia':
      filters.push(new fabric.Image.filters.Sepia());
      break;

    case 'technicolor':
      filters.push(new fabric.Image.filters.Technicolor());
      break;

    case 'polaroid':
      filters.push(new fabric.Image.filters.Polaroid());
      break;

    case 'kodachrome':
      filters.push(new fabric.Image.filters.Kodachrome());
      break;
  }

  // Add user adjustments on top of preset
  if (adj.brightness !== 0) {
    filters.push(new fabric.Image.filters.Brightness({ brightness: adj.brightness }));
  }
  if (adj.contrast !== 0) {
    filters.push(new fabric.Image.filters.Contrast({ contrast: adj.contrast }));
  }
  if (adj.saturation !== 0 && preset !== 'vivid') {
    filters.push(new fabric.Image.filters.Saturation({ saturation: adj.saturation }));
  }

  fImg.filters = filters;
  fImg.applyFilters();
}
