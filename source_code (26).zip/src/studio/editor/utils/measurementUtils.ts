/**
 * CUSTOM PRNTS — Measurement Utilities
 *
 * Converts between canvas pixels, product-relative percentages,
 * and physical inches. All production measurements use inches.
 */

// Standard DPI used for physical conversion
export const PRODUCTION_DPI = 300;

// Canvas coordinate system baseline (pixels per inch at design time)
export const DESIGN_PPI = 100;

/**
 * Convert pixels to inches using the product's physical dimensions ratio.
 * The canvas represents the full product print area at a known pixel dimension
 * mapped to physical size.
 */
export function pixelsToInches(
  pixels: number,
  canvasDimension: number,
  physicalDimensionInches: number
): number {
  return (pixels / canvasDimension) * physicalDimensionInches;
}

/**
 * Convert inches to canvas pixels.
 */
export function inchesToPixels(
  inches: number,
  canvasDimension: number,
  physicalDimensionInches: number
): number {
  return (inches / physicalDimensionInches) * canvasDimension;
}

/**
 * Calculate effective DPI from artwork pixel dimensions and intended print size.
 */
export function calculateDpi(artworkPixelWidth: number, printWidthInches: number): number {
  if (printWidthInches <= 0) return 0;
  return Math.round(artworkPixelWidth / printWidthInches);
}

/**
 * Rate DPI quality.
 */
export function rateDpi(dpi: number): 'excellent' | 'good' | 'caution' | 'poor' {
  if (dpi >= 300) return 'excellent';
  if (dpi >= 200) return 'good';
  if (dpi >= 150) return 'caution';
  return 'poor';
}

/**
 * Get DPI warning message.
 */
export function getDpiWarning(dpi: number, widthInches: number): string | null {
  if (dpi >= 200) return null;
  const suggestedWidth = Math.round((dpi / 200) * widthInches * 10) / 10;
  if (dpi < 150) {
    return `This design may print blurry at ${widthInches.toFixed(1)}" wide. Reduce to ${suggestedWidth.toFixed(1)}" or less, or use a higher-resolution file.`;
  }
  return `Resolution is moderate at ${widthInches.toFixed(1)}" wide. For best results, reduce to ${suggestedWidth.toFixed(1)}" or less.`;
}

/**
 * Check if a bounding box is within an area.
 */
export function isWithinArea(
  objX: number, objY: number, objW: number, objH: number,
  areaX: number, areaY: number, areaW: number, areaH: number
): boolean {
  return (
    objX >= areaX &&
    objY >= areaY &&
    objX + objW <= areaX + areaW &&
    objY + objH <= areaY + areaH
  );
}

/**
 * Calculate overlap percentage between two rectangles.
 */
export function overlapPercentage(
  objX: number, objY: number, objW: number, objH: number,
  areaX: number, areaY: number, areaW: number, areaH: number
): number {
  const xOverlap = Math.max(0, Math.min(objX + objW, areaX + areaW) - Math.max(objX, areaX));
  const yOverlap = Math.max(0, Math.min(objY + objH, areaY + areaH) - Math.max(objY, areaY));
  const overlapArea = xOverlap * yOverlap;
  const objArea = objW * objH;
  if (objArea <= 0) return 0;
  return Math.round((overlapArea / objArea) * 100);
}

/**
 * Snap a value to the nearest snap point within tolerance.
 */
export function snapValue(
  value: number,
  snapPoints: number[],
  tolerance: number = 5
): { snapped: number; snappedTo: number | null } {
  let bestDist = Infinity;
  let bestSnap: number | null = null;

  for (const point of snapPoints) {
    const dist = Math.abs(value - point);
    if (dist < bestDist && dist <= tolerance) {
      bestDist = dist;
      bestSnap = point;
    }
  }

  return bestSnap !== null
    ? { snapped: bestSnap, snappedTo: bestSnap }
    : { snapped: value, snappedTo: null };
}

/**
 * Generate snap points for a product view.
 */
export function getSnapPoints(
  canvasWidth: number,
  canvasHeight: number,
  printableArea: { x: number; y: number; width: number; height: number },
  safeArea: { x: number; y: number; width: number; height: number },
  anchors: Record<string, { x: number; y: number }>
): { horizontal: number[]; vertical: number[] } {
  const horizontal = [
    canvasWidth / 2,                          // canvas center
    printableArea.x,                          // printable left
    printableArea.x + printableArea.width,    // printable right
    safeArea.x,                               // safe left
    safeArea.x + safeArea.width,              // safe right
  ];

  const vertical = [
    canvasHeight / 2,                         // canvas center
    printableArea.y,                          // printable top
    printableArea.y + printableArea.height,   // printable bottom
    safeArea.y,                               // safe top
    safeArea.y + safeArea.height,             // safe bottom
  ];

  // Add anchor points
  for (const anchor of Object.values(anchors)) {
    horizontal.push(anchor.x);
    vertical.push(anchor.y);
  }

  return { horizontal, vertical };
}

/**
 * Clamp a position so the object stays within bounds.
 */
export function clampPosition(
  x: number, y: number, w: number, h: number,
  boundsX: number, boundsY: number, boundsW: number, boundsH: number
): { x: number; y: number } {
  return {
    x: Math.max(boundsX, Math.min(x, boundsX + boundsW - w)),
    y: Math.max(boundsY, Math.min(y, boundsY + boundsH - h)),
  };
}

/**
 * Calculate the bounding box of a rotated rectangle.
 */
export function rotatedBoundingBox(
  x: number, y: number, w: number, h: number, angleDeg: number
): { x: number; y: number; width: number; height: number } {
  const rad = (angleDeg * Math.PI) / 180;
  const cos = Math.abs(Math.cos(rad));
  const sin = Math.abs(Math.sin(rad));
  const newW = w * cos + h * sin;
  const newH = w * sin + h * cos;
  return {
    x: x + (w - newW) / 2,
    y: y + (h - newH) / 2,
    width: newW,
    height: newH,
  };
}

/**
 * Format a measurement for display.
 */
export function formatInches(value: number, decimals: number = 2): string {
  return `${value.toFixed(decimals)}"`;
}

/**
 * Format DPI for display.
 */
export function formatDpi(dpi: number): string {
  return `${dpi} DPI`;
}
