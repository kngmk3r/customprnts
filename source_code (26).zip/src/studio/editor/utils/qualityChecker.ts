/**
 * CUSTOM PRNTS — Quality Checker
 *
 * Evaluates artwork against print requirements and generates warnings.
 */

import type { QualityWarning, QualityState } from '../types';
import { calculateDpi, rateDpi, isWithinArea, overlapPercentage } from './measurementUtils';

let warningCounter = 0;

function warn(
  category: QualityWarning['category'],
  severity: QualityWarning['severity'],
  message: string,
  suggestion?: string
): QualityWarning {
  return {
    id: `qw_${++warningCounter}`,
    category,
    severity,
    message,
    suggestion,
  };
}

/**
 * Run all quality checks on the current editor state.
 */
export function runQualityChecks(params: {
  artworkPixelWidth: number;
  artworkPixelHeight: number;
  artworkHasTransparency: boolean;
  artworkHasSolidBackground: boolean;
  printableArea: { x: number; y: number; width: number; height: number };
  safeArea: { x: number; y: number; width: number; height: number };
  physicalMaxWidth: number;
  physicalMaxHeight: number;
  objectX: number;
  objectY: number;
  objectWidth: number;
  objectHeight: number;
  objectAngle: number;
  scaleX: number;
  scaleY: number;
  productColorHex: string;
  artworkAverageLuminance: number; // 0-255
  currentWidthInches: number;
}): QualityState {
  const warnings: QualityWarning[] = [];

  // ── Resolution / DPI ──
  const effectiveDpi = calculateDpi(params.artworkPixelWidth, params.currentWidthInches);
  const dpiRating = rateDpi(effectiveDpi);

  if (effectiveDpi < 150) {
    warnings.push(warn('resolution', 'poor',
      `Resolution is too low (${effectiveDpi} DPI) at ${params.currentWidthInches.toFixed(1)}" wide.`,
      `Reduce width to ${(effectiveDpi / 150 * params.currentWidthInches).toFixed(1)}" or use a higher-resolution file.`
    ));
  } else if (effectiveDpi < 200) {
    warnings.push(warn('resolution', 'caution',
      `Resolution is moderate (${effectiveDpi} DPI) at ${params.currentWidthInches.toFixed(1)}" wide.`,
      `For best quality, reduce to ${(effectiveDpi / 200 * params.currentWidthInches).toFixed(1)}" or less.`
    ));
  }

  // ── Printable boundary ──
  const objInPrintArea = isWithinArea(
    params.objectX, params.objectY, params.objectWidth, params.objectHeight,
    params.printableArea.x, params.printableArea.y, params.printableArea.width, params.printableArea.height
  );

  if (!objInPrintArea) {
    const overlap = overlapPercentage(
      params.objectX, params.objectY, params.objectWidth, params.objectHeight,
      params.printableArea.x, params.printableArea.y, params.printableArea.width, params.printableArea.height
    );
    if (overlap < 10) {
      warnings.push(warn('boundary', 'poor',
        'Artwork is entirely outside the printable area.',
        'Move the artwork within the printable boundary to ensure it prints.'
      ));
    } else {
      warnings.push(warn('boundary', 'caution',
        `Artwork extends beyond the printable area. Only ${overlap}% overlaps.`,
        'Move or resize the artwork to fit within the printable area.'
      ));
    }
  }

  // ── Safe area ──
  const objInSafeArea = isWithinArea(
    params.objectX, params.objectY, params.objectWidth, params.objectHeight,
    params.safeArea.x, params.safeArea.y, params.safeArea.width, params.safeArea.height
  );

  if (!objInSafeArea && objInPrintArea) {
    warnings.push(warn('safe-area', 'caution',
      'Some artwork is outside the safe area but within the printable area.',
      'Move important content inside the safe area to prevent trimming.'
    ));
  }

  // ── Background detection ──
  if (params.artworkHasSolidBackground) {
    warnings.push(warn('background', 'caution',
      'The artwork may have a solid white or rectangular background.',
      'Consider removing the background for cleaner printing.'
    ));
  }

  // ── Transparency ──
  if (!params.artworkHasTransparency) {
    warnings.push(warn('transparency', 'good',
      'Artwork does not have transparency. A solid background may print.',
    ));
  }

  // ── Aspect ratio distortion ──
  const scaleX = Math.abs(params.scaleX);
  const scaleY = Math.abs(params.scaleY);
  if (Math.abs(scaleX - scaleY) > 0.05) {
    warnings.push(warn('distortion', 'caution',
      `Artwork aspect ratio is distorted (${(scaleX / scaleY * 100).toFixed(0)}% stretch).`,
      'Reset the aspect ratio for undistorted printing.'
    ));
  }

  // ── Product color contrast ──
  const isDarkProduct = isColorDark(params.productColorHex);
  const isLightArtwork = params.artworkAverageLuminance > 180;
  const isDarkArtwork = params.artworkAverageLuminance < 80;

  if (isDarkProduct && isLightArtwork) {
    // Light artwork on dark product is generally fine
  } else if (!isDarkProduct && isDarkArtwork) {
    // Dark artwork on light product is generally fine
  } else if (isDarkProduct && isDarkArtwork) {
    warnings.push(warn('contrast', 'caution',
      'Dark artwork on a dark product may have low contrast.',
      'Consider using a lighter product color or lighter artwork colors.'
    ));
  } else if (!isDarkProduct && isLightArtwork) {
    warnings.push(warn('contrast', 'caution',
      'Light artwork on a light product may have low contrast.',
      'Consider using a darker product color or darker artwork colors.'
    ));
  }

  return {
    effectiveDpi,
    dpiRating,
    withinPrintableArea: objInPrintArea,
    withinSafeArea: objInSafeArea,
    hasTransparency: params.artworkHasTransparency,
    warnings,
  };
}

/**
 * Simple hex color darkness check.
 */
function isColorDark(hex: string): boolean {
  const h = hex.replace('#', '');
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return (r * 299 + g * 587 + b * 114) / 1000 < 128;
}

/**
 * Get a summary string for the quality state.
 */
export function getQualitySummary(q: QualityState): string {
  if (q.warnings.length === 0) return 'All checks passed';
  const poor = q.warnings.filter(w => w.severity === 'poor').length;
  const caution = q.warnings.filter(w => w.severity === 'caution').length;
  if (poor > 0) return `${poor} issue${poor > 1 ? 's' : ''} need attention`;
  if (caution > 0) return `${caution} warning${caution > 1 ? 's' : ''}`;
  return 'Good to go';
}
