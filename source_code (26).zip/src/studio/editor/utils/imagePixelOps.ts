/**
 * CUSTOM PRNTS — Image Pixel Operations
 *
 * Pure canvas pixel manipulation utilities for:
 * - Background removal (edge flood-fill estimation)
 * - Color-key transparency
 * - Alpha feathering
 * - No external packages required
 */

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

export interface ColorKeyOptions {
  /** RGB color to make transparent */
  r: number;
  g: number;
  b: number;
  /** Tolerance (0-255) — how close a pixel must be to the target color */
  tolerance: number;
  /** Feather radius in pixels (0 = no feathering) */
  feather: number;
}

export interface BgRemovalOptions {
  tolerance: number;
  feather: number;
}

// ═══════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════

function colorDistance(r1: number, g1: number, b1: number, r2: number, g2: number, b2: number): number {
  const dr = r1 - r2;
  const dg = g1 - g2;
  const db = b1 - b2;
  return Math.sqrt(0.299 * dr * dr + 0.587 * dg * dg + 0.114 * db * db);
}

/**
 * Estimate background color from the border region of an ImageData.
 */
function estimateBackgroundColor(imageData: ImageData): { r: number; g: number; b: number } {
  const { data, width, height } = imageData;
  const samples: Array<{ r: number; g: number; b: number }> = [];
  const stripWidth = Math.max(2, Math.floor(Math.min(width, height) * 0.02));

  for (let x = 0; x < width; x++) {
    for (let dy = 0; dy < stripWidth; dy++) {
      const topIdx = (dy * width + x) * 4;
      samples.push({ r: data[topIdx], g: data[topIdx + 1], b: data[topIdx + 2] });
      const botIdx = ((height - 1 - dy) * width + x) * 4;
      samples.push({ r: data[botIdx], g: data[botIdx + 1], b: data[botIdx + 2] });
    }
  }
  for (let y = 0; y < height; y++) {
    for (let dx = 0; dx < stripWidth; dx++) {
      const leftIdx = (y * width + dx) * 4;
      samples.push({ r: data[leftIdx], g: data[leftIdx + 1], b: data[leftIdx + 2] });
      const rightIdx = (y * width + (width - 1 - dx)) * 4;
      samples.push({ r: data[rightIdx], g: data[rightIdx + 1], b: data[rightIdx + 2] });
    }
  }

  const rs = samples.map(s => s.r).sort((a, b) => a - b);
  const gs = samples.map(s => s.g).sort((a, b) => a - b);
  const bs = samples.map(s => s.b).sort((a, b) => a - b);
  const mid = Math.floor(samples.length / 2);

  return { r: rs[mid], g: gs[mid], b: bs[mid] };
}

// ═══════════════════════════════════════════════════════════════════
// CORE OPERATIONS
// ═══════════════════════════════════════════════════════════════════

/**
 * Load an image source into an offscreen canvas and return ImageData.
 */
export function loadImageToImageData(src: string, maxSize?: number): Promise<ImageData | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      let w = img.naturalWidth;
      let h = img.naturalHeight;
      if (maxSize && (w > maxSize || h > maxSize)) {
        const scale = maxSize / Math.max(w, h);
        w = Math.round(w * scale);
        h = Math.round(h * scale);
      }
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0, w, h);
      resolve(ctx.getImageData(0, 0, w, h));
    };
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

/**
 * Apply color-key transparency: make all pixels within tolerance of a target color transparent.
 */
export function applyColorKey(imageData: ImageData, options: ColorKeyOptions): ImageData {
  const { data } = imageData;
  const { r: tr, g: tg, b: tb, tolerance } = options;

  for (let i = 0; i < data.length; i += 4) {
    const dist = colorDistance(data[i], data[i + 1], data[i + 2], tr, tg, tb);
    if (dist <= tolerance) {
      const alpha = dist > tolerance * 0.7 ? Math.round(255 * (1 - (dist - tolerance * 0.7) / (tolerance * 0.3))) : 0;
      data[i + 3] = alpha;
    }
  }

  if (options.feather > 0) {
    featherAlpha(imageData, options.feather);
  }

  return imageData;
}

/**
 * Auto-remove background using edge flood-fill estimation.
 */
export function removeBackgroundAuto(imageData: ImageData, options: BgRemovalOptions): ImageData {
  const { data, width, height } = imageData;
  const bgColor = estimateBackgroundColor(imageData);
  const { tolerance, feather } = options;

  const mask = new Uint8Array(width * height);
  const visited = new Uint8Array(width * height);
  const queue: number[] = [];

  function checkAndSeed(x: number, y: number) {
    const idx = y * width + x;
    if (visited[idx]) return;
    const pIdx = idx * 4;
    const dist = colorDistance(data[pIdx], data[pIdx + 1], data[pIdx + 2], bgColor.r, bgColor.g, bgColor.b);
    if (dist <= tolerance) {
      visited[idx] = 1;
      mask[idx] = 1;
      queue.push(idx);
    }
  }

  for (let x = 0; x < width; x++) {
    checkAndSeed(x, 0);
    checkAndSeed(x, height - 1);
  }
  for (let y = 0; y < height; y++) {
    checkAndSeed(0, y);
    checkAndSeed(width - 1, y);
  }

  let head = 0;
  while (head < queue.length) {
    const idx = queue[head++];
    const x = idx % width;
    const y = (idx - x) / width;

    const neighbors = [
      x > 0 ? idx - 1 : -1,
      x < width - 1 ? idx + 1 : -1,
      y > 0 ? idx - width : -1,
      y < height - 1 ? idx + width : -1,
    ];

    for (const nIdx of neighbors) {
      if (nIdx < 0 || nIdx >= width * height || visited[nIdx]) continue;
      visited[nIdx] = 1;
      const pIdx = nIdx * 4;
      const dist = colorDistance(data[pIdx], data[pIdx + 1], data[pIdx + 2], bgColor.r, bgColor.g, bgColor.b);
      if (dist <= tolerance) {
        mask[nIdx] = 1;
        queue.push(nIdx);
      }
    }
  }

  for (let i = 0; i < width * height; i++) {
    if (mask[i]) {
      data[i * 4 + 3] = 0;
    }
  }

  if (feather > 0) {
    featherAlpha(imageData, feather);
  }

  return imageData;
}

/**
 * Feather the alpha channel for smoother edges (box blur).
 */
export function featherAlpha(imageData: ImageData, radius: number): ImageData {
  const { data, width, height } = imageData;
  const r = Math.max(1, Math.round(radius));

  const alpha = new Uint8Array(width * height);
  for (let i = 0; i < alpha.length; i++) {
    alpha[i] = data[i * 4 + 3];
  }

  const temp = new Float32Array(width * height);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let sum = 0;
      let count = 0;
      for (let dx = -r; dx <= r; dx++) {
        const nx = x + dx;
        if (nx >= 0 && nx < width) {
          sum += alpha[y * width + nx];
          count++;
        }
      }
      temp[y * width + x] = sum / count;
    }
  }

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let sum = 0;
      let count = 0;
      for (let dy = -r; dy <= r; dy++) {
        const ny = y + dy;
        if (ny >= 0 && ny < height) {
          sum += temp[ny * width + x];
          count++;
        }
      }
      data[(y * width + x) * 4 + 3] = Math.round(sum / count);
    }
  }

  return imageData;
}

/**
 * Convert ImageData back to a PNG dataURL.
 */
export function imageDataToDataUrl(imageData: ImageData): string {
  const canvas = document.createElement('canvas');
  canvas.width = imageData.width;
  canvas.height = imageData.height;
  const ctx = canvas.getContext('2d')!;
  ctx.putImageData(imageData, 0, 0);
  return canvas.toDataURL('image/png');
}
