/**
 * CUSTOM PRNTS — History Manager
 *
 * Manages undo/redo with grouped steps.
 * Drag and resize actions are grouped into single history entries
 * using a debounce timer rather than saving every pixel movement.
 */

const GROUP_DEBOUNCE_MS = 400;

export class HistoryManager {
  private stack: string[] = [];
  private index: number = -1;
  private groupTimer: ReturnType<typeof setTimeout> | null = null;
  private maxSize: number;

  constructor(maxSize: number = 80) {
    this.maxSize = maxSize;
  }

  /**
   * Push a new state. If within the grouping window, replaces the current
   * entry instead of creating a new one (for drag/resize grouping).
   */
  push(state: string, group: boolean = false): void {
    // If we're not at the end of the stack, truncate forward history
    if (this.index < this.stack.length - 1) {
      this.stack = this.stack.slice(0, this.index + 1);
    }

    if (group && this.groupTimer !== null && this.stack.length > 0) {
      // Replace the current entry (grouped action)
      this.stack[this.index] = state;
    } else {
      // New history entry
      this.stack.push(state);
      this.index = this.stack.length - 1;

      // Enforce max size
      if (this.stack.length > this.maxSize) {
        this.stack.shift();
        this.index--;
      }
    }

    // Reset group timer
    if (this.groupTimer !== null) {
      clearTimeout(this.groupTimer);
    }
    this.groupTimer = setTimeout(() => {
      this.groupTimer = null;
    }, GROUP_DEBOUNCE_MS);
  }

  /**
   * Undo — returns the previous state or null if at beginning.
   */
  undo(currentState: string): string | null {
    if (this.index <= 0) return null;

    // If current state differs from the stored state at current index, save it first
    if (this.stack[this.index] !== currentState) {
      this.stack[this.index] = currentState;
    }

    this.index--;
    return this.stack[this.index] ?? null;
  }

  /**
   * Redo — returns the next state or null if at end.
   */
  redo(): string | null {
    if (this.index >= this.stack.length - 1) return null;
    this.index++;
    return this.stack[this.index] ?? null;
  }

  /**
   * Save current state without moving index (for initial save).
   */
  save(state: string): void {
    this.stack = [state];
    this.index = 0;
    this.groupTimer = null;
  }

  canUndo(): boolean {
    return this.index > 0;
  }

  canRedo(): boolean {
    return this.index < this.stack.length - 1;
  }

  clear(): void {
    this.stack = [];
    this.index = -1;
    this.groupTimer = null;
  }

  /**
   * Restore from saved state (e.g., after reloading from storage).
   */
  restore(states: string[], currentIndex: number): void {
    this.stack = [...states];
    this.index = currentIndex;
    this.groupTimer = null;
  }
}
