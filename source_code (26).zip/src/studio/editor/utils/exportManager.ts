/**
 * CUSTOM PRNTS — Export Manager
 *
 * Handles all export operations:
 * - Transparent artwork master (no product, no background)
 * - Sized production artwork (at 300 DPI)
 * - Customer mockup image
 * - Placement proof
 * - Production specification JSON
 * - Editor project JSON
 */

import type { ProductionSpec, EditorState } from '../types';

/* ─── Toast helper ─── */
let toastEl: HTMLDivElement | null = null;

function showToast(message: string, type: 'success' | 'error' = 'success') {
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;padding:12px 20px;border-radius:8px;font-family:"Barlow Condensed",sans-serif;font-size:14px;font-weight:600;letter-spacing:0.05em;text-transform:uppercase;color:#FAFAFA;background:#1a1a1a;border:1px solid #D4AF37;box-shadow:0 4px 20px rgba(0,0,0,0.4);opacity:0;transform:translateY(10px);transition:all 0.3s ease;pointer-events:auto;';
    document.body.appendChild(toastEl);
  }
  toastEl.textContent = message;
  toastEl.style.borderColor = type === 'success' ? '#D4AF37' : '#ef4444';
  toastEl.style.background = type === 'success' ? '#1a1a1a' : '#7f1d1d';
  requestAnimationFrame(() => { toastEl!.style.opacity = '1'; toastEl!.style.transform = 'translateY(0)'; });
  setTimeout(() => {
    if (toastEl) { toastEl.style.opacity = '0'; toastEl.style.transform = 'translateY(10px)'; }
  }, 3000);
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function dataUrlToBlob(dataUrl: string): Blob {
  const parts = dataUrl.split(',');
  const mime = parts[0].match(/:(.*?);/)?.[1] || 'image/png';
  const binary = atob(parts[1]);
  const array = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) array[i] = binary.charCodeAt(i);
  return new Blob([array], { type: mime });
}

/**
 * Export transparent artwork master — only the design, no product.
 */
export function exportTransparentMaster(
  fabricCanvas: any,
  projectName: string
): boolean {
  try {
    // Save state, remove background, export, restore
    const origBg = fabricCanvas.backgroundColor;
    const origBgImage = fabricCanvas.backgroundImage;
    fabricCanvas.backgroundColor = 'transparent';
    fabricCanvas.backgroundImage = null;

    // Remove any product/overlay objects
    const objectsToRemove: any[] = [];
    fabricCanvas.getObjects().forEach((obj: any) => {
      if (obj._isProductOverlay || obj._isPlacementGuide) {
        objectsToRemove.push(obj);
        fabricCanvas.remove(obj);
      }
    });

    fabricCanvas.renderAll();

    const dataUrl = fabricCanvas.toDataURL({
      format: 'png',
      multiplier: 2, // 2x for quality
    });

    // Restore
    fabricCanvas.backgroundColor = origBg;
    fabricCanvas.backgroundImage = origBgImage;
    objectsToRemove.forEach(obj => fabricCanvas.add(obj));
    fabricCanvas.renderAll();

    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    const blob = dataUrlToBlob(dataUrl);
    triggerDownload(blob, `${safeName}_artwork-master.png`);
    showToast('Transparent artwork master exported', 'success');
    return true;
  } catch (err) {
    showToast('Failed to export artwork master', 'error');
    return false;
  }
}

/**
 * Export sized production artwork at 300 DPI.
 */
export function exportProductionArtwork(
  fabricCanvas: any,
  projectName: string,
  printWidthInches: number,
  printHeightInches: number,
  currentDpi: number
): boolean {
  try {
    const targetDpi = 300;
    const targetWidthPx = Math.round(printWidthInches * targetDpi);
    const targetHeightPx = Math.round(printHeightInches * targetDpi);

    const origBg = fabricCanvas.backgroundColor;
    fabricCanvas.backgroundColor = 'transparent';

    // Remove product overlays
    const objectsToRemove: any[] = [];
    fabricCanvas.getObjects().forEach((obj: any) => {
      if (obj._isProductOverlay || obj._isPlacementGuide) {
        objectsToRemove.push(obj);
        fabricCanvas.remove(obj);
      }
    });
    fabricCanvas.renderAll();

    const dataUrl = fabricCanvas.toDataURL({
      format: 'png',
      multiplier: targetWidthPx / fabricCanvas.width,
    });

    // Restore
    fabricCanvas.backgroundColor = origBg;
    objectsToRemove.forEach(obj => fabricCanvas.add(obj));
    fabricCanvas.renderAll();

    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    const blob = dataUrlToBlob(dataUrl);
    triggerDownload(blob, `${safeName}_production_${printWidthInches}x${printHeightInches}in.png`);

    if (currentDpi < 200) {
      showToast(`Production artwork exported (${currentDpi} DPI — consider higher resolution)`, 'success');
    } else {
      showToast('Production artwork exported at 300 DPI', 'success');
    }
    return true;
  } catch {
    showToast('Failed to export production artwork', 'error');
    return false;
  }
}

/**
 * Generate production specification JSON.
 */
export function buildProductionSpec(editorState: EditorState): ProductionSpec {
  const { product, placement, quality } = editorState;
  return {
    projectId: editorState.projectId,
    revisionId: editorState.activeRevisionId,
    product: product.productId,
    productVariant: 'standard',
    garmentColor: product.colorId,
    garmentColorHex: '', // filled by caller from template
    printSide: product.viewId,
    placementPreset: placement.presetId || 'custom',
    artworkWidthInches: placement.widthInches,
    artworkHeightInches: placement.heightInches,
    topOffsetInches: placement.topOffsetInches,
    horizontalOffsetInches: placement.horizontalOffsetInches,
    rotationDegrees: placement.rotationDegrees,
    horizontalAlignment: placement.centered ? 'center' : 'custom',
    printMethod: 'DTF',
    effectiveDpi: quality.effectiveDpi,
    transparentBackground: true,
    approvedAt: new Date().toISOString(),
    approvedByUserId: '',
  };
}

/**
 * Export production spec as JSON file.
 */
export function exportProductionSpec(editorState: EditorState, projectName: string): boolean {
  try {
    const spec = buildProductionSpec(editorState);
    const blob = new Blob([JSON.stringify(spec, null, 2)], { type: 'application/json' });
    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    triggerDownload(blob, `${safeName}_production-spec.json`);
    showToast('Production specification exported', 'success');
    return true;
  } catch {
    showToast('Failed to export production spec', 'error');
    return false;
  }
}

/**
 * Export editor project JSON.
 */
export function exportEditorProject(editorState: EditorState, projectName: string): boolean {
  try {
    const blob = new Blob([JSON.stringify(editorState, null, 2)], { type: 'application/json' });
    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    triggerDownload(blob, `${safeName}_editor-project.json`);
    showToast('Editor project exported', 'success');
    return true;
  } catch {
    showToast('Failed to export project', 'error');
    return false;
  }
}

/**
 * Capture mockup from a canvas element.
 */
export function captureMockup(canvasElement: HTMLCanvasElement, projectName: string, side: string): boolean {
  try {
    const dataUrl = canvasElement.toDataURL('image/png', 1.0);
    const blob = dataUrlToBlob(dataUrl);
    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    triggerDownload(blob, `${safeName}_mockup_${side}.png`);
    showToast(`${side} mockup exported`, 'success');
    return true;
  } catch {
    showToast('Failed to export mockup', 'error');
    return false;
  }
}

/**
 * Export transparent artwork at full resolution (300 DPI for print).
 * Respects crop, transparency, and filters.
 */
export function exportTransparentFullRes(
  fabricCanvas: any,
  projectName: string,
  options: { targetDpi?: number; printWidthInches?: number; multiplier?: number } = {}
): boolean {
  try {
    const { targetDpi = 300, printWidthInches, multiplier: explicitMultiplier } = options;

    const origBg = fabricCanvas.backgroundColor;
    const origBgImage = fabricCanvas.backgroundImage;
    fabricCanvas.backgroundColor = 'transparent';
    fabricCanvas.backgroundImage = null;

    // Remove product/overlay objects
    const objectsToRemove: any[] = [];
    fabricCanvas.getObjects().forEach((obj: any) => {
      if (obj._isProductOverlay || obj._isPlacementGuide) {
        objectsToRemove.push(obj);
        fabricCanvas.remove(obj);
      }
    });
    fabricCanvas.renderAll();

    // Calculate multiplier for full resolution
    let multiplier = explicitMultiplier || 2;
    if (printWidthInches && !explicitMultiplier) {
      multiplier = (printWidthInches * targetDpi) / fabricCanvas.width;
    }

    const dataUrl = fabricCanvas.toDataURL({
      format: 'png',
      multiplier: Math.max(multiplier, 1),
    });

    // Restore
    fabricCanvas.backgroundColor = origBg;
    fabricCanvas.backgroundImage = origBgImage;
    objectsToRemove.forEach(obj => fabricCanvas.add(obj));
    fabricCanvas.renderAll();

    const safeName = projectName.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    const blob = dataUrlToBlob(dataUrl);
    const sizeKb = Math.round(blob.size / 1024);
    triggerDownload(blob, `${safeName}_transparent_${targetDpi}dpi.png`);
    showToast(`Transparent PNG exported (${targetDpi} DPI, ${sizeKb} KB)`, 'success');
    return true;
  } catch (err) {
    showToast('Failed to export transparent PNG', 'error');
    return false;
  }
}
