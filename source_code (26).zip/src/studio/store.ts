/**
 * Studio Store — Project state management
 *
 * Canonical createProject: calls /api/generate-batch via studioFetch (authenticated),
 * saves remoteProjectId, persists to IndexedDB, sets concepts in state.
 *
 * All network / auth errors are surfaced as customer-facing GenerationError objects.
 * Exceptions are never silently swallowed.
 */

import { useState, useCallback, useRef } from 'react';
import type { Project } from './storage';
import { saveProject as saveToStorage, getAllProjects, getProject, deleteProject as deleteFromStorage, duplicateProject as duplicateInStorage, createNewProject, type ProjectBrief } from './storage';
import { ConceptGenerationError, getDesignsForProject, type Concept, type GenerationError } from './conceptGenerator';
import { studioFetch } from './edgesparkClient';
import type { OverlayConfig } from './editor/overlaySystem';
import { createWatermarkOverlay } from './editor/overlaySystem';

export interface StudioState {
  projects: Project[];
  currentProject: Project | null;
  concepts: Concept[];
  isLoading: boolean;
  error: string | null;
  generationError: GenerationError | null;
  /** Last attempted tier — preserved for retry to avoid silent downgrade */
  lastTier: 'free' | 'premium' | null;
  /** Non-destructive overlay layers — never merged into artwork */
  overlays: OverlayConfig[];
}

export function useStudioStore() {
  const [state, setState] = useState<StudioState>({
    projects: [],
    currentProject: null,
    concepts: [],
    isLoading: false,
    error: null,
    generationError: null,
    lastTier: null,
    overlays: [createWatermarkOverlay()],
  });

  const autosaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadProjects = useCallback(async () => {
    setState(s => ({ ...s, isLoading: true }));
    try {
      const projects = await getAllProjects();
      setState(s => ({ ...s, projects, isLoading: false }));
    } catch {
      setState(s => ({ ...s, isLoading: false, error: 'Failed to load projects' }));
    }
  }, []);

  // ── helpers ────────────────────────────────────────────────

  /** Convert a studioFetch failure into a safe customer-facing ConceptGenerationError. */
  function toGenerationError(err: unknown): ConceptGenerationError {
    if (err instanceof ConceptGenerationError) return err;

    // Network / fetch errors (TypeError from fetch, abort, etc.)
    if (err instanceof TypeError) {
      return new ConceptGenerationError({
        code: 'NETWORK_ERROR',
        message: "We couldn't reach the design-generation service. Please try again.",
        retryable: true,
      });
    }

    // Any other unexpected error — preserve a safe message
    const msg = err instanceof Error ? err.message : 'Unexpected error occurred.';
    return new ConceptGenerationError({
      code: 'UNKNOWN_ERROR',
      message: msg || 'An unexpected error occurred. Please try again.',
      retryable: true,
    });
  }

  /** Parse a non-ok Response into a ConceptGenerationError, with 401 specificity. */
  async function parseResponseError(res: Response): Promise<ConceptGenerationError> {
    if (res.status === 401) {
      return new ConceptGenerationError({
        code: 'SESSION_EXPIRED',
        message: 'Your private workspace session expired or could not be created. Please try again.',
        retryable: true,
      });
    }

    let body: any;
    try { body = await res.json(); } catch { body = {}; }

    const err: GenerationError = body.error || {
      code: 'SERVER_ERROR',
      message: `Server error ${res.status}`,
      retryable: res.status === 429 || res.status >= 500,
    };

    // Surface safe customer text for common codes
    if (err.code === 'RATE_LIMITED' || res.status === 429) {
      return new ConceptGenerationError({
        code: 'RATE_LIMITED',
        message: 'Too many requests. Please wait a moment and try again.',
        retryable: true,
      });
    }

    return new ConceptGenerationError(err);
  }

  // ═══════════════════════════════════════════════════════════════
  // CANONICAL createProject — single path, uses authenticated studioFetch
  // ═══════════════════════════════════════════════════════════════

  const createProject = useCallback(async (brief: ProjectBrief, tier: 'free' | 'premium' = 'free') => {
    const project = createNewProject(brief);

    let concepts: Concept[];
    try {
      const res = await studioFetch('/api/generate-batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: brief.name, description: brief.description, productType: brief.productType,
          preferredColors: brief.preferredColors, mainWording: brief.mainWording, notes: brief.notes,
          tier,
        }),
      });

      if (!res.ok) {
        throw await parseResponseError(res);
      }

      const data = await res.json();
      if (!data.success || !data.designs?.length) {
        throw new ConceptGenerationError(data.error || { code: 'GENERATION_FAILED', message: 'No designs generated.', retryable: true });
      }

      concepts = data.designs.map((d: any) => ({
        id: d.id, name: d.conceptName, imageUrl: d.signedPreviewUrl, storageKey: d.storageKey,
        provider: data.metadata?.provider, model: data.metadata?.model, meta: data.metadata,
      }));

      if (data.projectId) (project as any).remoteProjectId = data.projectId;
    } catch (err) {
      if (err instanceof ConceptGenerationError) {
        // Preserve the project brief locally even when generation fails
        await saveToStorage(project);
        setState(s => ({
          ...s, currentProject: project, projects: [...s.projects, project],
          generationError: { code: err.code, message: err.message, retryable: err.retryable },
          lastTier: tier,
        }));
        return project;
      }
      // Wrap any unknown error
      const wrapped = toGenerationError(err);
      await saveToStorage(project);
      setState(s => ({
        ...s, currentProject: project, projects: [...s.projects, project],
        generationError: { code: wrapped.code, message: wrapped.message, retryable: wrapped.retryable },
        lastTier: tier,
      }));
      return project;
    }

    await saveToStorage(project);
    setState(s => ({ ...s, currentProject: project, concepts, projects: [...s.projects, project], generationError: null, lastTier: tier }));
    return project;
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // OPEN PROJECT — load fresh designs from server if remoteProjectId exists
  // ═══════════════════════════════════════════════════════════════

  const openProject = useCallback(async (id: string) => {
    setState(s => ({ ...s, isLoading: true }));
    try {
      const project = await getProject(id);
      if (!project) { setState(s => ({ ...s, isLoading: false })); return; }

      const remoteId = (project as any).remoteProjectId;
      if (remoteId) {
        try {
          const concepts = await getDesignsForProject(remoteId);
          if (concepts.length > 0) {
            if (project.selectedConceptId) {
              const selected = concepts.find(c => c.id === project.selectedConceptId);
              if (selected) { (project as any).conceptImageUrl = selected.imageUrl; await saveToStorage(project); }
            }
            setState(s => ({ ...s, currentProject: project, concepts, isLoading: false }));
            return;
          }
        } catch { /* server unavailable — still show local data */ }
      }
      setState(s => ({ ...s, currentProject: project, isLoading: false }));
    } catch {
      setState(s => ({ ...s, isLoading: false, error: 'Failed to open project' }));
    }
  }, []);

  const selectConcept = useCallback(async (conceptId: string) => {
    setState(s => {
      if (!s.currentProject) return s;
      return { ...s, currentProject: { ...s.currentProject, selectedConceptId: conceptId } };
    });
  }, []);

  const saveProject = useCallback(async (project: Project) => {
    await saveToStorage(project);
    setState(s => ({ ...s, currentProject: project, projects: s.projects.map(p => p.id === project.id ? project : p) }));
  }, []);

  const autosaveProject = useCallback((project: Project) => {
    if (autosaveTimer.current) clearTimeout(autosaveTimer.current);
    autosaveTimer.current = setTimeout(async () => {
      await saveToStorage(project);
      setState(s => ({ ...s, projects: s.projects.map(p => p.id === project.id ? { ...project, updatedAt: new Date().toISOString() } : p) }));
    }, 1000);
  }, []);

  const deleteProject = useCallback(async (id: string) => {
    await deleteFromStorage(id);
    setState(s => ({ ...s, projects: s.projects.filter(p => p.id !== id), currentProject: s.currentProject?.id === id ? null : s.currentProject }));
  }, []);

  const duplicateProject = useCallback(async (project: Project) => {
    const dup = await duplicateInStorage(project);
    setState(s => ({ ...s, projects: [dup, ...s.projects] }));
    return dup;
  }, []);

  // ═══════════════════════════════════════════════════════════════
  // REGENERATE — uses authenticated studioFetch
  // ═══════════════════════════════════════════════════════════════

  const regenerateConcept = useCallback(async (index: number, brief: ProjectBrief) => {
    const existingConcept = state.concepts[index];
    if (!existingConcept) return;

    try {
      const res = await studioFetch('/api/regenerate-design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          designId: existingConcept.id,
          brief: { name: brief.name, description: brief.description, productType: brief.productType, preferredColors: brief.preferredColors, mainWording: brief.mainWording, notes: brief.notes },
        }),
      });

      if (!res.ok) {
        throw await parseResponseError(res);
      }

      const data = await res.json();
      if (!data.success || !data.design) {
        throw new ConceptGenerationError(data.error || { code: 'GENERATION_FAILED', message: 'Regeneration failed.', retryable: true });
      }

      const newConcept: Concept = {
        id: data.design.id, name: data.design.conceptName, imageUrl: data.design.signedPreviewUrl,
        storageKey: data.design.storageKey, provider: data.metadata?.provider, model: data.metadata?.model, meta: data.metadata,
      };

      setState(s => {
        const concepts = [...s.concepts];
        concepts[index] = newConcept;
        return { ...s, concepts, generationError: null };
      });
    } catch (err) {
      const wrapped = toGenerationError(err);
      setState(s => ({ ...s, generationError: { code: wrapped.code, message: wrapped.message, retryable: wrapped.retryable } }));
    }
  }, [state.concepts]);

  // ═══════════════════════════════════════════════════════════════
  // RETRY — uses existing remoteProjectId via studioFetch, preserves tier
  // BUG FIX: Previously dropped tier field → silently downgraded premium → free
  // Now accepts explicit tier param and falls back to lastTier / meta / backend inference
  // ═══════════════════════════════════════════════════════════════

  const retryGeneration = useCallback(async (brief: ProjectBrief, tier?: 'free' | 'premium') => {
    const existingProject = state.currentProject;
    const existingRemoteId = existingProject ? (existingProject as any).remoteProjectId : null;
    // Tier inference order: explicit param > lastTier state > meta from current concepts > free
    const inferredTier: 'free' | 'premium' = tier
      || state.lastTier
      || (state.concepts[0] as any)?.meta?.tier
      || 'free';

    setState(s => ({ ...s, generationError: null, concepts: [], lastTier: inferredTier }));

    try {
      const res = await studioFetch('/api/generate-batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: brief.name, description: brief.description, productType: brief.productType,
          preferredColors: brief.preferredColors, mainWording: brief.mainWording, notes: brief.notes,
          projectId: existingRemoteId || undefined,
          tier: inferredTier,
        }),
      });

      if (!res.ok) {
        throw await parseResponseError(res);
      }

      const data = await res.json();
      if (!data.success || !data.designs?.length) {
        throw new ConceptGenerationError(data.error || { code: 'GENERATION_FAILED', message: 'No designs generated.', retryable: true });
      }

      const concepts = data.designs.map((d: any) => ({
        id: d.id, name: d.conceptName, imageUrl: d.signedPreviewUrl, storageKey: d.storageKey,
        provider: data.metadata?.provider, model: data.metadata?.model, meta: data.metadata,
      }));

      if (existingProject) {
        const updated = { ...existingProject };
        if (data.projectId && !existingRemoteId) (updated as any).remoteProjectId = data.projectId;
        await saveToStorage(updated);
        setState(s => ({ ...s, currentProject: updated, concepts, generationError: null, lastTier: (data.metadata?.tier as any) || inferredTier }));
      } else {
        setState(s => ({ ...s, concepts, generationError: null, lastTier: (data.metadata?.tier as any) || inferredTier }));
      }
    } catch (err) {
      const wrapped = toGenerationError(err);
      setState(s => ({ ...s, generationError: { code: wrapped.code, message: wrapped.message, retryable: wrapped.retryable } }));
    }
  }, [state.currentProject, state.lastTier, state.concepts]);

  const clearGenerationError = useCallback(() => { setState(s => ({ ...s, generationError: null })); }, []);

  const updateProject = useCallback((updater: (p: Project) => Project) => {
    setState(s => {
      if (!s.currentProject) return s;
      const updated = updater(s.currentProject);
      autosaveProject(updated);
      return { ...s, currentProject: updated };
    });
  }, [autosaveProject]);

  // ═══════════════════════════════════════════════════════════════
  // OVERLAY MANAGEMENT — non-destructive UI layers
  // ═══════════════════════════════════════════════════════════════

  /** Toggle visibility of a specific overlay by id */
  const toggleOverlay = useCallback((overlayId: string) => {
    setState(s => ({
      ...s,
      overlays: s.overlays.map(o =>
        o.id === overlayId ? { ...o, visible: !o.visible } : o
      ),
    }));
  }, []);

  /** Show or hide a specific overlay type */
  const setOverlayVisible = useCallback((overlayId: string, visible: boolean) => {
    setState(s => ({
      ...s,
      overlays: s.overlays.map(o =>
        o.id === overlayId ? { ...o, visible } : o
      ),
    }));
  }, []);

  /** Add a new overlay */
  const addOverlay = useCallback((overlay: OverlayConfig) => {
    setState(s => ({ ...s, overlays: [...s.overlays, overlay] }));
  }, []);

  /** Remove an overlay by id */
  const removeOverlay = useCallback((overlayId: string) => {
    setState(s => ({ ...s, overlays: s.overlays.filter(o => o.id !== overlayId) }));
  }, []);

  /**
   * Unlock design — hides the watermark overlay to reveal the original artwork.
   * No image processing, no regeneration, no quality loss.
   * The original image was never modified; we just remove the UI overlay layer.
   */
  const unlockDesign = useCallback(() => {
    setState(s => ({
      ...s,
      overlays: s.overlays.map(o =>
        o.type === 'watermark' ? { ...o, visible: false } : o
      ),
    }));
  }, []);

  /** Re-lock — re-enable all overlays */
  const lockDesign = useCallback(() => {
    setState(s => ({
      ...s,
      overlays: s.overlays.map(o => ({ ...o, visible: true })),
    }));
  }, []);

  return {
    ...state,
    loadProjects, createProject, openProject, selectConcept,
    saveProject, autosaveProject, deleteProject, duplicateProject,
    regenerateConcept, retryGeneration, clearGenerationError,
    updateProject, setState,
    toggleOverlay, setOverlayVisible, addOverlay, removeOverlay,
    unlockDesign, lockDesign,
  };
}
