import SiteHeader from '../components/SiteHeader';
import Footer from '../components/Footer';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-cp-black text-cp-white">
      <SiteHeader mode="marketing" />
      <div className="pt-8 pb-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <h1 className="stencil-text text-4xl md:text-5xl tracking-[0.15em] text-cp-white mb-4">
          ABOUT
        </h1>
        <p className="font-body text-cp-grey-400 text-lg max-w-2xl mb-12">
          CUSTOM PRNTS — Turn your idea into a design.
        </p>

        <div className="space-y-8">
          <div className="bg-cp-grey-900 border border-cp-grey-800 rounded-lg p-8">
            <h2 className="stencil-text text-2xl tracking-[0.1em] text-cp-blue mb-4">OUR STORY</h2>
            <p className="font-body text-cp-grey-400 leading-relaxed">
              CUSTOM PRNTS started as a print shop with a simple mission: make custom apparel accessible to everyone. 
              Today, we've evolved into a design-first platform where the creative process matters as much as the final product. 
              Our Design Studio puts professional-grade tools in your hands — no design experience required.
            </p>
          </div>

          <div className="bg-cp-grey-900 border border-cp-grey-800 rounded-lg p-8">
            <h2 className="stencil-text text-2xl tracking-[0.1em] text-cp-blue mb-4">THE STUDIO</h2>
            <p className="font-body text-cp-grey-400 leading-relaxed mb-4">
              The Design Studio is a free, browser-based creative tool that helps you go from idea to finished design. 
              Describe your vision, choose from AI-generated concepts, customize on a full canvas editor, preview on realistic shirt mockups, 
              and export or order when you're ready.
            </p>
            <a href="/studio" className="btn-primary inline-flex">
              Open the Studio
            </a>
          </div>

          <div className="bg-cp-grey-900 border border-cp-grey-800 rounded-lg p-8">
            <h2 className="stencil-text text-2xl tracking-[0.1em] text-cp-blue mb-4">CONTACT</h2>
            <div className="space-y-2 font-body text-cp-grey-400">
              <p>123 Print Street, Downtown Arts District</p>
              <p>(555) 123-PRINT</p>
              <p>hello@customprnts.com</p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
