import SiteHeader from '../components/SiteHeader';
import Footer from '../components/Footer';

export default function GalleryPage() {
  return (
    <div className="min-h-screen bg-cp-black text-cp-white">
      <SiteHeader mode="marketing" />
      <div className="pt-8 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <h1 className="stencil-text text-4xl md:text-5xl tracking-[0.15em] text-cp-white mb-4">
          GALLERY
        </h1>
        <p className="font-body text-cp-grey-400 text-lg max-w-2xl mb-12">
          Explore designs made in the CUSTOM PRNTS Design Studio. Get inspired and start creating your own.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {['Bold Statement', 'Minimal Classic', 'Urban Streetwear', 'Retro Vibes', 'Abstract Art', 'Typography'].map((name) => (
            <div key={name} className="bg-cp-grey-900 border border-cp-grey-800 rounded-lg overflow-hidden hover:border-cp-blue transition-colors">
              <div className="aspect-square bg-gradient-to-br from-cp-grey-800 to-cp-grey-900 flex items-center justify-center">
                <span className="stencil-text text-2xl text-cp-grey-600">{name}</span>
              </div>
              <div className="p-4">
                <h3 className="font-condensed font-bold text-cp-white tracking-wider uppercase">{name}</h3>
                <p className="font-body text-sm text-cp-grey-500 mt-1">Made in the Studio</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-16 text-center">
          <a href="/studio" className="btn-primary">
            Create Your Own
          </a>
        </div>
      </div>
      <Footer />
    </div>
  );
}
