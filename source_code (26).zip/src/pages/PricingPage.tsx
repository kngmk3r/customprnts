import SiteHeader from '../components/SiteHeader';
import Footer from '../components/Footer';

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-cp-black text-cp-white">
      <SiteHeader mode="marketing" />
      <div className="pt-8 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <h1 className="stencil-text text-4xl md:text-5xl tracking-[0.15em] text-cp-white mb-4">
          PRICING
        </h1>
        <p className="font-body text-cp-grey-400 text-lg max-w-2xl mb-12">
          Design Studio is free to use. Pay only when you order printed products.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl">
          {/* Design Studio */}
          <div className="bg-cp-grey-900 border border-cp-grey-800 rounded-lg p-8 text-center">
            <h3 className="stencil-text text-xl tracking-[0.1em] text-cp-blue mb-3">DESIGN STUDIO</h3>
            <p className="font-condensed text-3xl font-bold text-cp-white mb-2">FREE</p>
            <p className="font-body text-sm text-cp-grey-500 mb-6">Unlimited designs, forever</p>
            <ul className="space-y-3 text-left font-body text-sm text-cp-grey-400">
              <li>✓ AI concept generation</li>
              <li>✓ Full canvas editor</li>
              <li>✓ Shirt mockup preview</li>
              <li>✓ Export transparent PNG</li>
              <li>✓ Save unlimited projects</li>
            </ul>
            <a href="/studio" className="btn-primary w-full mt-8 !text-sm">
              Start Creating
            </a>
          </div>

          {/* Pickup */}
          <div className="bg-cp-grey-900 border border-cp-blue rounded-lg p-8 text-center relative">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-cp-blue text-cp-white px-3 py-1 text-xs font-condensed font-bold tracking-wider uppercase">
              POPULAR
            </div>
            <h3 className="stencil-text text-xl tracking-[0.1em] text-cp-blue mb-3">PICKUP</h3>
            <p className="font-condensed text-3xl font-bold text-cp-white mb-2">$25–$45</p>
            <p className="font-body text-sm text-cp-grey-500 mb-6">Ready in 3 hours</p>
            <ul className="space-y-3 text-left font-body text-sm text-cp-grey-400">
              <li>✓ Premium quality print</li>
              <li>✓ 3-hour rush available</li>
              <li>✓ In-store pickup</li>
              <li>✓ All apparel types</li>
              <li>✓ Eco-friendly inks</li>
            </ul>
            <a href="/studio" className="btn-primary w-full mt-8 !text-sm">
              Design Now
            </a>
          </div>

          {/* Delivery */}
          <div className="bg-cp-grey-900 border border-cp-grey-800 rounded-lg p-8 text-center">
            <h3 className="stencil-text text-xl tracking-[0.1em] text-cp-blue mb-3">DELIVERY</h3>
            <p className="font-condensed text-3xl font-bold text-cp-white mb-2">$35–$55</p>
            <p className="font-body text-sm text-cp-grey-500 mb-6">2–5 business days</p>
            <ul className="space-y-3 text-left font-body text-sm text-cp-grey-400">
              <li>✓ Premium quality print</li>
              <li>✓ Nationwide shipping</li>
              <li>✓ Track your order</li>
              <li>✓ All apparel types</li>
              <li>✓ Eco-friendly inks</li>
            </ul>
            <a href="/studio" className="btn-primary w-full mt-8 !text-sm">
              Design Now
            </a>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
