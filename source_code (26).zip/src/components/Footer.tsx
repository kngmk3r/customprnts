const footerLinks = {
  studio: [
    { label: 'Design Studio', href: '/studio' },
    { label: 'My Projects', href: '/studio' },
    { label: 'Gallery', href: '/gallery' },
    { label: 'How It Works', href: '/about' },
  ],
  company: [
    { label: 'About', href: '/about' },
    { label: 'Pricing', href: '/pricing' },
    { label: 'Gallery', href: '/gallery' },
    { label: 'Design Studio', href: '/studio' },
  ],
};

import Wordmark from './Wordmark';

export default function Footer() {
  return (
    <footer className="bg-cp-black border-t border-cp-grey-800">
      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {/* Brand column */}
          <div>
            <div className="mb-6">
              <Wordmark size="md" />
            </div>
            <p className="font-body text-sm text-cp-grey-400 leading-relaxed mb-6">
              Turn your idea into a design. AI-powered design studio for custom apparel.
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <svg className="w-4 h-4 text-cp-blue flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
                  <polyline points="22,6 12,13 2,6" />
                </svg>
                <span className="font-body text-sm text-cp-grey-400">hello@customprnts.com</span>
              </div>
            </div>
          </div>

          {/* Studio column */}
          <div>
            <h3 className="stencil-text text-lg tracking-[0.2em] text-cp-white mb-6">STUDIO</h3>
            <ul className="space-y-3">
              {footerLinks.studio.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="font-body text-sm text-cp-grey-400 hover:text-cp-blue transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company column */}
          <div>
            <h3 className="stencil-text text-lg tracking-[0.2em] text-cp-white mb-6">COMPANY</h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="font-body text-sm text-cp-grey-400 hover:text-cp-blue transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-cp-grey-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-body text-xs text-cp-grey-500">
            © 2026 CUSTOM PRNTS. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="font-body text-xs text-cp-grey-500 hover:text-cp-blue transition-colors duration-300">
              Privacy Policy
            </a>
            <a href="#" className="font-body text-xs text-cp-grey-500 hover:text-cp-blue transition-colors duration-300">
              Terms of Service
            </a>
          </div>
          {/* Social icons */}
          <div className="flex items-center gap-4">
            {/* Instagram */}
            <a href="#" className="text-cp-grey-500 hover:text-cp-blue transition-colors duration-300" aria-label="Instagram">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <rect x="2" y="2" width="20" height="20" rx="5" />
                <circle cx="12" cy="12" r="5" />
                <circle cx="17.5" cy="6.5" r="1.5" fill="currentColor" stroke="none" />
              </svg>
            </a>
            {/* TikTok */}
            <a href="#" className="text-cp-grey-500 hover:text-cp-blue transition-colors duration-300" aria-label="TikTok">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.11V9a6.33 6.33 0 00-.79-.05A6.34 6.34 0 003.15 15.3a6.34 6.34 0 0010.86 4.48V13.2a8.16 8.16 0 005.58 2.17V12a4.85 4.85 0 01-5.58-2.63V6.69h5.58z"/>
              </svg>
            </a>
            {/* Twitter/X */}
            <a href="#" className="text-cp-grey-500 hover:text-cp-blue transition-colors duration-300" aria-label="X (Twitter)">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
