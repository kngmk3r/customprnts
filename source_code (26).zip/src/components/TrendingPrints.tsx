import ContentRail from './ContentRail';

const prints = [
  { id: 1, name: 'Church Event Packs', desc: 'Bulk faith-based apparel for conferences, revivals, and ministry events.', bg: '#0f1525', accent: '#1E3A8A', icon: '⛪' },
  { id: 2, name: 'Family Reunion Tees', desc: 'Matching tees, hoodies & accessories for the whole family.', bg: '#121520', accent: '#2a4080', icon: '👨‍👩‍👧‍👦' },
  { id: 3, name: 'School Spirit Sets', desc: 'Tees, jerseys & crewnecks for schools, clubs, and student orgs.', bg: '#101825', accent: '#1a3570', icon: '🎓' },
  { id: 4, name: 'Team Jerseys', desc: 'Custom numbers, names & logos. On-court quality, any quantity.', bg: '#0e1520', accent: '#1E3A8A', icon: '🏀' },
  { id: 5, name: 'Business Merch Kits', desc: 'Corporate branding kits — tees, hats, totes & more for your team.', bg: '#111520', accent: '#253a7a', icon: '🏢' },
  { id: 6, name: 'Birthday Print Bundles', desc: 'Custom birthday tees, party packs & celebration gear.', bg: '#141525', accent: '#1E3A8A', icon: '🎂' },
];

function TrendCard({ print }: { print: typeof prints[0] }) {
  return (
    <div className="snap-start flex-shrink-0 w-[340px] md:w-[440px] group cursor-pointer">
      <div
        className="relative overflow-hidden rounded-lg border border-cp-grey-800/40 transition-all duration-[400ms] ease-out group-hover:border-cp-blue/60 group-hover:shadow-[0_4px_40px_rgba(30,58,138,0.35),0_0_80px_rgba(30,58,138,0.12)] group-hover:scale-[1.03] h-full"
        style={{ backgroundColor: print.bg }}
      >
        {/* 16:10 hero tile area */}
        <div className="aspect-[16/10] relative overflow-hidden">
          {/* Large icon centered */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-7xl md:text-8xl opacity-30 group-hover:opacity-50 group-hover:scale-110 transition-all duration-700 select-none">
              {print.icon}
            </span>
          </div>

          {/* Abstract background shapes */}
          <div className="absolute inset-0">
            <div className="absolute top-0 right-0 w-48 h-48 bg-cp-blue/5 rounded-full blur-[60px] group-hover:bg-cp-blue/10 transition-colors duration-700" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-cp-blue/3 rounded-full blur-[40px]" />
          </div>

          {/* Soft dark gradient overlay at bottom */}
          <div className="absolute inset-0 bg-gradient-to-t from-cp-black via-cp-black/50 to-transparent opacity-70 group-hover:opacity-95 transition-opacity duration-500" />

          {/* Title + desc overlaid on bottom */}
          <div className="absolute bottom-0 left-0 right-0 p-5 z-10">
            <h3 className="stencil-text text-xl md:text-2xl text-cp-white tracking-wider mb-1 group-hover:text-cp-blue transition-colors duration-300 drop-shadow-lg">
              {print.name}
            </h3>
            <p className="font-body text-xs text-cp-grey-300 leading-relaxed drop-shadow-md">
              {print.desc}
            </p>
          </div>
        </div>

        {/* Hover CTA — slides up from bottom */}
        <div className="absolute bottom-0 left-0 right-0 p-5 pt-0 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-400 z-20">
          <button className="w-full py-3 bg-cp-blue text-cp-white font-condensed font-bold text-sm tracking-[0.15em] uppercase hover:bg-cp-blue-bright transition-colors duration-300 shadow-[0_0_20px_rgba(30,58,138,0.4)]">
            EXPLORE
          </button>
        </div>
      </div>
    </div>
  );
}

export default function TrendingPrints() {
  return (
    <ContentRail
      title="TRENDING PRINTS"
      subtitle="Design Ideas"
      gap="gap-3"
      showDots={true}
      showArrows={true}
      bg="bg-cp-black"
    >
      {prints.map((print) => (
        <TrendCard key={print.id} print={print} />
      ))}
    </ContentRail>
  );
}
