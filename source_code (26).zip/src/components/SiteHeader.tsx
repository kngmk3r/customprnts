/**
 * SiteHeader — Unified header across the whole site.
 * Same dark bar, breadcrumb-style nav, and wordmark treatment.
 * - Marketing mode: nav links + "Open Studio" CTA
 * - Studio mode: minimal breadcrumb with Home + Wordmark
 */

import { useState } from 'react';
import Wordmark from './Wordmark';

interface SiteHeaderProps {
  mode: 'marketing' | 'studio';
  /** Optional breadcrumb segments shown after the wordmark */
  breadcrumbs?: { label: string; href?: string }[];
}

const marketingLinks = [
  { label: 'STUDIO', href: '/studio' },
  { label: 'GALLERY', href: '/gallery' },
  { label: 'PRICING', href: '/pricing' },
  { label: 'ABOUT', href: '/about' },
];

const HouseIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

export default function SiteHeader({ mode, breadcrumbs = [] }: SiteHeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="border-b border-studio-border bg-studio-surface sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex items-center gap-3">
        {/* Home link + Wordmark */}
        <a
          href="/"
          className="flex items-center gap-2 shrink-0 hover:opacity-80 transition-opacity"
          aria-label="Back to Homepage"
        >
          <span className="text-studio-muted">
            <HouseIcon />
          </span>
          <span className="hidden sm:inline">
            <Wordmark size="sm" />
          </span>
        </a>

        {/* Marketing: nav links + CTA */}
        {mode === 'marketing' && (
          <>
            <span className="text-studio-border hidden sm:inline">|</span>
            <nav className="hidden md:flex items-center gap-6">
              {marketingLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="font-condensed text-xs font-bold tracking-[0.2em] text-studio-muted hover:text-white transition-colors uppercase"
                >
                  {link.label}
                </a>
              ))}
            </nav>
            <div className="hidden md:flex items-center ml-auto">
              <a
                href="/studio"
                className="studio-btn-primary !py-1.5 !px-4 !text-xs"
              >
                OPEN STUDIO
              </a>
            </div>
          </>
        )}

        {/* Studio: breadcrumb segments */}
        {mode === 'studio' && breadcrumbs.length > 0 && (
          <>
            {breadcrumbs.map((crumb, i) => (
              <span key={i} className="flex items-center gap-3">
                <span className="text-studio-border">|</span>
                {crumb.href ? (
                  <a
                    href={crumb.href}
                    className="font-condensed text-xs font-bold tracking-[0.2em] text-studio-muted hover:text-white transition-colors uppercase"
                  >
                    {crumb.label}
                  </a>
                ) : (
                  <span className="font-condensed text-xs font-bold tracking-[0.2em] text-white uppercase">
                    {crumb.label}
                  </span>
                )}
              </span>
            ))}
          </>
        )}

        {/* Mobile menu toggle (marketing only) */}
        {mode === 'marketing' && (
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden ml-auto flex flex-col gap-1 p-2"
            aria-label="Toggle menu"
          >
            <span className={`w-5 h-0.5 bg-cp-grey-400 transition-all duration-300 ${mobileOpen ? 'rotate-45 translate-y-1.5' : ''}`} />
            <span className={`w-5 h-0.5 bg-cp-blue transition-all duration-300 ${mobileOpen ? 'opacity-0' : ''}`} />
            <span className={`w-5 h-0.5 bg-cp-grey-400 transition-all duration-300 ${mobileOpen ? '-rotate-45 -translate-y-1.5' : ''}`} />
          </button>
        )}
      </div>

      {/* Mobile menu (marketing only) */}
      {mode === 'marketing' && (
        <div className={`md:hidden transition-all duration-300 overflow-hidden ${mobileOpen ? 'max-h-80 opacity-100' : 'max-h-0 opacity-0'}`}>
          <div className="bg-studio-surface border-t border-studio-border px-6 py-4 space-y-3">
            {marketingLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="block font-condensed text-sm font-bold tracking-[0.15em] text-studio-muted hover:text-white transition-colors"
              >
                {link.label}
              </a>
            ))}
            <a
              href="/studio"
              className="btn-primary w-full mt-3 !text-sm"
              onClick={() => setMobileOpen(false)}
            >
              OPEN STUDIO
            </a>
          </div>
        </div>
      )}
    </div>
  );
}
