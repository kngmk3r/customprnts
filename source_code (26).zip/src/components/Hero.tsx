import { useEffect, useState } from 'react';

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-cp-black">
      {/* Animated dark gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#0c1220] via-[#0f1a30] to-[#0a0f1a]" />

      {/* Subtle grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(30,58,138,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(30,58,138,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Glow orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cp-blue/10 rounded-full blur-[120px] animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-cp-blue/8 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        <div
          className={`transition-all duration-1000 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          {/* Tag */}
          <div className="inline-flex items-center gap-2 mb-8 px-4 py-2 border border-cp-blue/30 rounded-full bg-cp-blue/5">
            <span className="w-2 h-2 bg-cp-blue rounded-full animate-pulse" />
            <span className="font-condensed text-xs font-bold tracking-[0.3em] text-cp-blue uppercase">
              Design Studio
            </span>
          </div>

          {/* Headline */}
          <h1 className="stencil-text text-6xl sm:text-7xl md:text-8xl lg:text-9xl leading-[0.9] mb-6 text-cp-white">
            TURN YOUR IDEA
            <br />
            <span className="text-cp-blue">INTO A DESIGN</span>
          </h1>

          {/* Subtitle */}
          <p className="font-barlow text-lg md:text-xl text-cp-grey-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Sketch it, describe it, or upload it — the Studio handles the rest.
            Professional-grade custom designs, ready to produce.
          </p>

          {/* CTA */}
          <a href="/studio" className="btn-primary text-xl !px-12 !py-5 group inline-flex">
            <svg
              width="22"
              height="22"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              className="mr-3 transition-transform group-hover:scale-110"
            >
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
            </svg>
            START CREATING
          </a>
        </div>
      </div>

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-cp-black to-transparent" />
    </section>
  );
}
