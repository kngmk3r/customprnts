import { useEffect, useRef, useState } from 'react';

const steps = [
  { id: 'idea', label: 'Idea', icon: '💡', description: 'Start with a concept' },
  { id: 'interview', label: 'Interview', icon: '💬', description: 'Tell us your vision' },
  { id: 'concepts', label: 'Concepts', icon: '🎨', description: 'AI generates options' },
  { id: 'edit', label: 'Edit', icon: '✏️', description: 'Refine your design' },
  { id: 'preview', label: 'Preview', icon: '👕', description: 'See it on product' },
  { id: 'produce', label: 'Produce', icon: '🚀', description: 'Order or download' },
];

export default function TheJourney() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [activeStep, setActiveStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;
    const timer = setInterval(() => {
      setActiveStep(prev => (prev + 1) % steps.length);
    }, 2000);
    return () => clearInterval(timer);
  }, [isVisible]);

  return (
    <section ref={sectionRef} className="py-20 md:py-32 bg-cp-black relative overflow-hidden">
      {/* Subtle blue accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[1px] bg-gradient-to-r from-transparent via-cp-blue/40 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="stencil-text text-4xl md:text-5xl text-cp-white mb-4">
            THE <span className="text-cp-blue">JOURNEY</span>
          </h2>
          <p className="font-barlow text-cp-grey-400 text-lg max-w-xl mx-auto">
            From initial spark to finished product — every design follows this path.
          </p>
        </div>

        {/* Horizontal Journey Strip */}
        <div className="relative">
          {/* Connector line */}
          <div className="absolute top-[44px] left-0 right-0 h-[2px] bg-cp-grey-800 hidden md:block" />
          <div
            className="absolute top-[44px] left-0 h-[2px] bg-cp-blue transition-all duration-700 hidden md:block"
            style={{ width: `${(activeStep / (steps.length - 1)) * 100}%` }}
          />

          <div className="flex flex-col md:flex-row items-center justify-between gap-8 md:gap-4">
            {steps.map((step, i) => (
              <div
                key={step.id}
                className={`flex flex-col items-center text-center flex-1 transition-all duration-500 cursor-pointer group ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
                } ${i === activeStep ? 'scale-110' : ''}`}
                style={{ transitionDelay: `${i * 100}ms` }}
                onClick={() => setActiveStep(i)}
              >
                {/* Circle node */}
                <div
                  className={`w-[72px] h-[72px] rounded-full flex items-center justify-center text-2xl border-2 transition-all duration-500 ${
                    i <= activeStep
                      ? 'border-cp-blue bg-cp-blue/15 shadow-[0_0_20px_rgba(30,58,138,0.3)]'
                      : 'border-cp-grey-700 bg-cp-grey-900'
                  } ${i === activeStep ? 'ring-4 ring-cp-blue/20' : ''}`}
                >
                  <span className="text-2xl">{step.icon}</span>
                </div>

                {/* Label */}
                <div className="mt-4">
                  <span
                    className={`font-condensed text-sm font-bold tracking-[0.15em] uppercase transition-colors duration-300 ${
                      i === activeStep ? 'text-cp-blue' : i < activeStep ? 'text-cp-grey-300' : 'text-cp-grey-600'
                    }`}
                  >
                    {step.label}
                  </span>
                  <p className={`text-xs mt-1 transition-opacity duration-300 ${
                    i === activeStep ? 'opacity-100 text-cp-grey-400' : 'opacity-0'
                  }`}>
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <a href="/studio" className="btn-primary inline-flex">
            START CREATING
          </a>
        </div>
      </div>
    </section>
  );
}
