/**
 * Wordmark — Text-based logo replacing the SVG graphic logo.
 * Renders "CUSTOM" in bold white + "PRNTS" in grey.
 */

interface WordmarkProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const sizeClasses = {
  sm: 'text-sm',
  md: 'text-lg',
  lg: 'text-2xl',
};

export default function Wordmark({ className = '', size = 'md' }: WordmarkProps) {
  return (
    <span
      className={`font-condensed font-bold tracking-[0.2em] uppercase select-none ${sizeClasses[size]} ${className}`}
    >
      <span className="text-white">CUSTOM</span>
      <span className="text-cp-grey-500">PRNTS</span>
    </span>
  );
}
