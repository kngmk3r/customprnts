import ContentRail from './ContentRail';

const galleryItems = [
  { id: 1, name: 'Street Bold Tee', category: 'Streetwear', bg: '#111118', accent: '#1E3A8A' },
  { id: 2, name: 'Faith Collection', category: 'Faith-Inspired', bg: '#141420', accent: '#253a7a' },
  { id: 3, name: 'Urban Skyline', category: 'City Collection', bg: '#10101c', accent: '#1a3070' },
  { id: 4, name: 'Minimal Classic', category: 'Minimal', bg: '#121220', accent: '#1E3A8A' },
  { id: 5, name: 'Street Essential', category: 'Streetwear', bg: '#111118', accent: '#202860' },
  { id: 6, name: 'Originals', category: 'Athletic', bg: '#0f0f1c', accent: '#1E3A8A' },
  { id: 7, name: 'Clean Slate', category: 'Minimal', bg: '#131320', accent: '#1a3070' },
  { id: 8, name: 'Team Custom', category: 'Team Wear', bg: '#141422', accent: '#253a7a' },
];

function GalleryCard({ item }: { item: typeof galleryItems[0] }) {
  return (
    <div className="snap-start flex-shrink-0 w-[340px] md:w-[440px] group cursor-pointer">
      <div className="relative overflow-hidden rounded-lg border border-cp-grey-800/40 transition-all duration-[400ms] ease-out group-hover:border-cp-blue/60 group-hover:shadow-[0_4px_40px_rgba(30,58,138,0.35),0_0_80px_rgba(30,58,138,0.12)] group-hover:scale-[1.03]">
        {/* Image area */}
        <div className="aspect-[16/10] relative overflow-hidden" style={{ backgroundColor: item.bg }}>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-full h-full">
              <div className="absolute top-1/4 left-1/4 w-1/2 h-1/2 border border-cp-blue/8 rotate-45 group-hover:rotate-[225deg] transition-transform duration-1000" />
              <div className="absolute top-1/3 left-1/3 w-1/3 h-1/3 rounded-full bg-cp-blue/5 group-hover:scale-150 transition-transform duration-700" />
              {/* Garment silhouette */}
              <svg viewBox="0 0 200 200" className="absolute inset-0 w-full h-full p-[18%] opacity-25 group-hover:opacity-45 transition-opacity duration-500" fill="none">
                <path
                  d="M60 30L30 50L40 70L55 60V170H145V60L160 70L170 50L140 30H130C130 45 115 55 100 55C85 55 70 45 70 30H60Z"
                  stroke={item.accent}
                  strokeWidth="1.5"
                  fill={`${item.accent}08`}
                />
                <rect x="75" y="70" width="50" height="50" rx="4" stroke={item.accent} strokeWidth="1" strokeDasharray="4 4" />
              </svg>
            </div>
          </div>

          {/* "Made in Studio" badge */}
          <div className="absolute top-3 left-3 px-2 py-1 bg-cp-blue/20 backdrop-blur-sm rounded border border-cp-blue/30">
            <span className="font-condensed text-[10px] font-bold tracking-[0.15em] text-cp-blue uppercase">Made in Studio</span>
          </div>
        </div>

        {/* Info */}
        <div className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-condensed text-sm font-bold tracking-[0.1em] text-cp-white uppercase group-hover:text-cp-blue transition-colors">{item.name}</h3>
              <p className="font-barlow text-xs text-cp-grey-500 mt-0.5">{item.category}</p>
            </div>
            <span className="font-condensed text-xs text-cp-blue opacity-0 group-hover:opacity-100 transition-opacity">View →</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Gallery() {
  return (
    <section id="gallery" className="py-16 md:py-24 bg-cp-black">
      <ContentRail
        title="GALLERY"
        subtitle="Designs created in the CUSTOM PRNTS Studio"
        autoplay
        autoplayInterval={3500}
      >
        {galleryItems.map(item => (
          <GalleryCard key={item.id} item={item} />
        ))}
      </ContentRail>
    </section>
  );
}
