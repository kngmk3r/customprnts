import { useState, useEffect, useCallback, useRef } from 'react';
import Logo from './Logo';
import CityNightscape from './CityNightscape';

const slides = [
  {
    id: 1,
    tag: 'CUSTOM GEAR',
    title: 'YOUR IDEA. PRINTED TODAY.',
    subtitle: 'Customize Your Own Gear',
    description: 'Tees, hoodies, hats, jerseys, and more — design from scratch or upload your art. No minimums. Next-day pickup.',
    cta1: { label: 'START DESIGNING', href: '#studio' },
    cta2: { label: 'HOW IT WORKS', href: '#how-it-works' },
    bg: 'from-[#0c1220] via-[#0f1a30] to-[#0a0f1a]',
    accent: 'rgba(30,58,138,0.2)',
    patternAngle: -45,
  },
  {
    id: 2,
    tag: '3-HOUR RUSH',
    title: 'NEED IT TODAY?',
    subtitle: 'Rush Print Express',
    description: 'Walk in, design on our 4K touchscreen, pick up in 3 hours. Fastest custom print turnaround in the city.',
    cta1: { label: 'RUSH ORDER', href: '#studio' },
    cta2: null,
    bg: 'from-[#0a0f1a] via-[#101828] to-[#0c1220]',
    accent: 'rgba(30,58,138,0.25)',
    patternAngle: 45,
  },
  {
    id: 3,
    tag: 'DESIGN STUDIO',
    title: 'DESIGN FROM ANYWHERE',
    subtitle: 'Upload. Create. Print.',
    description: 'Use our online studio to upload your art, choose a base, and preview it live. AI design generation included.',
    cta1: { label: 'OPEN STUDIO', href: '#studio' },
    cta2: null,
    bg: 'from-[#0f1a30] via-[#0c1220] to-[#101828]',
    accent: 'rgba(30,58,138,0.18)',
    patternAngle: -30,
  },
  {
    id: 4,
    tag: 'BULK & TEAM',
    title: 'OUTFIT YOUR CREW',
    subtitle: 'No Minimums. Ever.',
    description: 'Church events, school fundraisers, corporate merch, team jerseys — we handle any quantity with the same speed.',
    cta1: { label: 'GET A QUOTE', href: '#bulk' },
    cta2: { label: 'SHOP DROPS', href: '#shop' },
    bg: 'from-[#0a0f1a] via-[#0c1220] to-[#0f1a30]',
    accent: 'rgba(30,58,138,0.15)',
    patternAngle: 60,
  },
];

export default function HeroCarousel() {
  const [current, setCurrent] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goTo = useCallback((index: number) => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrent(index);
    setTimeout(() => setIsTransitioning(false), 600);
  }, [isTransitioning]);

  const next = useCallback(() => {
    goTo((current + 1) % slides.length);
  }, [current, goTo]);

  const prev = useCallback(() => {
    goTo((current - 1 + slides.length) % slides.length);
  }, [current, goTo]);

  // Autoplay
  useEffect(() => {
    if (isHovered) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    timerRef.current = setInterval(next, 5000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isHovered, next]);

  const slide = slides[current];

  return (
    <section
      className="relative min-h-[85vh] md:min-h-screen flex items-center overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Cinematic Dallas nightscape background */}
      <CityNightscape />

      {/* Corner frame accents */}
      <div className="absolute top-0 right-0 w-40 h-40 border-t-2 border-r-2 border-cp-blue/15 z-10" />
      <div className="absolute bottom-0 left-0 w-40 h-40 border-b-2 border-l-2 border-cp-blue/15 z-10" />

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl">
          {/* Logo mark */}
          <div className={`mb-8 transition-all duration-700 ${isTransitioning ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
            <Logo size="lg" showGlow={true} />
          </div>

          {/* Tag */}
          <div className={`flex items-center gap-3 mb-5 transition-all duration-700 delay-100 ${isTransitioning ? 'opacity-0 translate-x-[-20px]' : 'opacity-100 translate-x-0'}`}>
            <div className="w-8 h-px bg-cp-blue" />
            <span className="font-condensed text-xs tracking-[0.4em] text-cp-blue font-bold uppercase">
              {slide.tag}
            </span>
          </div>

          {/* Title */}
          <h1 className={`stencil-text text-[clamp(3rem,10vw,8rem)] leading-[0.85] text-cp-white mb-4 tracking-wider transition-all duration-700 delay-200 ${isTransitioning ? 'opacity-0 translate-y-8' : 'opacity-100 translate-y-0'}`}>
            {slide.title}
          </h1>

          {/* Subtitle */}
          <p className={`font-condensed text-xl md:text-2xl text-cp-blue font-semibold tracking-wide mb-5 transition-all duration-700 delay-300 ${isTransitioning ? 'opacity-0 translate-y-6' : 'opacity-100 translate-y-0'}`}>
            {slide.subtitle}
          </p>

          {/* Description */}
          <p className={`font-body text-base md:text-lg text-cp-grey-400 max-w-xl leading-relaxed mb-10 transition-all duration-700 delay-400 ${isTransitioning ? 'opacity-0 translate-y-5' : 'opacity-100 translate-y-0'}`}>
            {slide.description}
          </p>

          {/* CTAs */}
          <div className={`flex flex-wrap items-center gap-4 transition-all duration-700 delay-500 ${isTransitioning ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
            <a href={slide.cta1.href} className="btn-primary text-lg px-10 py-5">
              {slide.cta1.label}
            </a>
            {slide.cta2 && (
              <a href={slide.cta2.href} className="btn-secondary text-lg px-10 py-5">
                {slide.cta2.label}
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Slide navigation - arrows */}
      <div className="absolute bottom-24 md:bottom-16 right-4 sm:right-6 lg:right-8 z-20 flex items-center gap-3">
        <button
          onClick={prev}
          className="w-12 h-12 flex items-center justify-center border border-cp-grey-700/60 text-cp-grey-400 hover:border-cp-blue hover:text-cp-blue hover:bg-cp-blue/10 backdrop-blur-sm transition-all duration-300 rounded-full"
          aria-label="Previous slide"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </button>
        <button
          onClick={next}
          className="w-12 h-12 flex items-center justify-center border border-cp-grey-700/60 text-cp-grey-400 hover:border-cp-blue hover:text-cp-blue hover:bg-cp-blue/10 backdrop-blur-sm transition-all duration-300 rounded-full"
          aria-label="Next slide"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 18l6-6-6-6" />
          </svg>
        </button>
      </div>

      {/* Dot indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2.5">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            className={`transition-all duration-400 rounded-full ${i === current ? 'w-10 h-2 bg-cp-blue' : 'w-2 h-2 bg-cp-grey-600 hover:bg-cp-grey-400'}`}
            aria-label={`Go to slide ${i + 1}`}
          />
        ))}
      </div>

      {/* Slide counter */}
      <div className="absolute bottom-6 right-4 sm:right-6 lg:right-8 z-20">
        <span className="stencil-text text-sm text-cp-grey-400 tracking-widest">
          {String(current + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}
        </span>
      </div>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-cp-grey-800 z-20">
        <div
          className="h-full bg-cp-blue transition-all duration-300"
          style={{ width: `${((current + 1) / slides.length) * 100}%` }}
        />
      </div>
    </section>
  );
}
