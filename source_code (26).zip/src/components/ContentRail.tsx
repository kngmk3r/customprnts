import { useRef, useState, useEffect, useCallback, ReactNode } from 'react';

interface ContentRailProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  gap?: string;
  showDots?: boolean;
  showArrows?: boolean;
  autoplay?: boolean;
  autoplayInterval?: number;
  className?: string;
  titleAlign?: 'left' | 'center';
  bg?: string;
}

export default function ContentRail({
  children,
  title,
  subtitle,
  gap = 'gap-5',
  showDots = true,
  showArrows = true,
  autoplay = false,
  autoplayInterval = 4000,
  className = '',
  titleAlign = 'left',
  bg = 'bg-cp-black',
}: ContentRailProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [childCount, setChildCount] = useState(0);

  useEffect(() => {
    if (!scrollRef.current) return;
    setChildCount(scrollRef.current.children.length);
  }, [children]);

  const scrollToIndex = useCallback((index: number) => {
    if (!scrollRef.current) return;
    const children = Array.from(scrollRef.current.children) as HTMLElement[];
    if (index < 0) index = children.length - 1;
    if (index >= children.length) index = 0;
    const child = children[index];
    if (child) {
      const containerRect = scrollRef.current.getBoundingClientRect();
      const childRect = child.getBoundingClientRect();
      const scrollLeft = child.offsetLeft - containerRect.width / 2 + childRect.width / 2;
      scrollRef.current.scrollTo({ left: scrollLeft, behavior: 'smooth' });
      setActiveIndex(index);
    }
  }, []);

  const scrollPrev = useCallback(() => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: -420, behavior: 'smooth' });
  }, []);

  const scrollNext = useCallback(() => {
    if (!scrollRef.current) return;
    scrollRef.current.scrollBy({ left: 420, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    const handleScroll = () => {
      const children = Array.from(container.children) as HTMLElement[];
      const center = container.scrollLeft + container.clientWidth / 2;
      let closest = 0;
      let closestDist = Infinity;
      children.forEach((child, i) => {
        const dist = Math.abs(child.offsetLeft + child.offsetWidth / 2 - center);
        if (dist < closestDist) { closestDist = dist; closest = i; }
      });
      setActiveIndex(closest);
    };
    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!autoplay || isHovered) return;
    const iv = setInterval(() => {
      setActiveIndex(prev => {
        const next = prev + 1 >= childCount ? 0 : prev + 1;
        scrollToIndex(next);
        return next;
      });
    }, autoplayInterval);
    return () => clearInterval(iv);
  }, [autoplay, isHovered, autoplayInterval, scrollToIndex, childCount]);

  return (
    <section className={`relative py-10 md:py-16 ${bg} ${className}`}>
      {title && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8">
          <div className={`flex items-end justify-between ${titleAlign === 'center' ? 'flex-col items-center gap-4' : ''}`}>
            <div>
              {subtitle && (
                <span className="font-condensed text-sm tracking-[0.4em] text-cp-blue font-semibold uppercase block mb-3">
                  {subtitle}
                </span>
              )}
              <h2 className="stencil-text text-3xl md:text-5xl text-cp-white tracking-wider">{title}</h2>
            </div>
            {showArrows && titleAlign === 'left' && (
              <div className="hidden md:flex items-center gap-3">
                <button onClick={scrollPrev} className="w-11 h-11 flex items-center justify-center border border-cp-grey-700 text-cp-grey-400 hover:border-cp-blue hover:text-cp-blue hover:bg-cp-blue/10 transition-all duration-300 rounded-full" aria-label="Previous">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
                </button>
                <button onClick={scrollNext} className="w-11 h-11 flex items-center justify-center border border-cp-grey-700 text-cp-grey-400 hover:border-cp-blue hover:text-cp-blue hover:bg-cp-blue/10 transition-all duration-300 rounded-full" aria-label="Next">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6" /></svg>
                </button>
              </div>
            )}
          </div>
          <div className="w-16 h-0.5 bg-cp-blue mt-5" />
        </div>
      )}

      <div className="relative group">
        <div
          ref={scrollRef}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          className={`flex ${gap} overflow-x-auto hide-scrollbar scroll-smooth snap-x snap-mandatory px-4 sm:px-6 lg:px-8 pb-4`}
          style={{ scrollPaddingInline: '1rem' }}
        >
          {children}
        </div>

        {showArrows && (
          <>
            <button onClick={scrollPrev} className="md:hidden absolute left-2 top-1/2 -translate-y-1/2 z-20 w-10 h-10 flex items-center justify-center bg-cp-black/80 backdrop-blur-sm border border-cp-grey-700 text-cp-white hover:border-cp-blue hover:text-cp-blue transition-all rounded-full opacity-0 group-hover:opacity-100" aria-label="Previous">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M15 18l-6-6 6-6" /></svg>
            </button>
            <button onClick={scrollNext} className="md:hidden absolute right-2 top-1/2 -translate-y-1/2 z-20 w-10 h-10 flex items-center justify-center bg-cp-black/80 backdrop-blur-sm border border-cp-grey-700 text-cp-white hover:border-cp-blue hover:text-cp-blue transition-all rounded-full opacity-0 group-hover:opacity-100" aria-label="Next">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6" /></svg>
            </button>
          </>
        )}

        <div className="absolute top-0 left-0 bottom-0 w-12 bg-gradient-to-r from-cp-black to-transparent pointer-events-none z-10" />
        <div className="absolute top-0 right-0 bottom-0 w-12 bg-gradient-to-l from-cp-black to-transparent pointer-events-none z-10" />
      </div>

      {showDots && childCount > 0 && (
        <div className="flex items-center justify-center gap-2 mt-6">
          {Array.from({ length: Math.min(childCount, 12) }).map((_, i) => (
            <button
              key={i}
              onClick={() => scrollToIndex(i)}
              className={`transition-all duration-300 rounded-full ${activeIndex === i ? 'w-8 h-2 bg-cp-blue' : 'w-2 h-2 bg-cp-grey-600 hover:bg-cp-grey-400'}`}
              aria-label={`Slide ${i + 1}`}
            />
          ))}
        </div>
      )}
    </section>
  );
}
