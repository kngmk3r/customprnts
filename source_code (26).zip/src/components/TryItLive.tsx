import { useEffect, useRef, useState } from 'react';

const sampleTexts = ['YOUR DESIGN', 'STAY TRUE', 'CUSTOM'];

export default function TryItLive() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [text, setText] = useState(sampleTexts[0]);
  const [color, setColor] = useState('#D4AF37');
  const animFrameRef = useRef<number>(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true); },
      { threshold: 0.2 }
    );
    const el = canvasRef.current?.parentElement;
    if (el) observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !isVisible) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;

    const draw = () => {
      tick += 0.02;
      const w = canvas.width;
      const h = canvas.height;

      // Background
      ctx.fillStyle = '#0d0d0d';
      ctx.fillRect(0, 0, w, h);

      // Grid lines
      ctx.strokeStyle = 'rgba(30,58,138,0.06)';
      ctx.lineWidth = 1;
      for (let x = 0; x < w; x += 40) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
      }
      for (let y = 0; y < h; y += 40) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
      }

      // Border box
      const bx = 40, by = 30, bw = w - 80, bh = h - 60;
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(bx, by, bw, bh);
      ctx.strokeStyle = color + '40';
      ctx.lineWidth = 1;
      ctx.strokeRect(bx + 8, by + 8, bw - 16, bh - 16);

      // Main text
      const fontSize = Math.min(w / 6, 72);
      ctx.font = `bold ${fontSize}px Impact, Arial Black, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = color;
      const wobble = Math.sin(tick) * 2;
      ctx.fillText(text, w / 2 + wobble, h / 2);

      // Underline
      const tw = ctx.measureText(text).width;
      ctx.beginPath();
      ctx.moveTo(w / 2 - tw / 2, h / 2 + fontSize * 0.4);
      ctx.lineTo(w / 2 + tw / 2, h / 2 + fontSize * 0.4);
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.stroke();

      // Branding
      ctx.font = '12px Arial, sans-serif';
      ctx.fillStyle = color + '99';
      ctx.textAlign = 'center';
      ctx.fillText('★ CUSTOM PRNTS STUDIO ★', w / 2, h - 20);

      // Cursor blink
      const cursorX = w / 2 + tw / 2 + 10 + Math.sin(tick * 3) * 4;
      ctx.fillStyle = color;
      ctx.fillRect(cursorX, h / 2 - fontSize / 2, 2, fontSize);

      animFrameRef.current = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [text, color, isVisible]);

  return (
    <section className="py-20 md:py-32 bg-gradient-to-b from-cp-black via-[#0a0f1a] to-cp-black relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="stencil-text text-4xl md:text-5xl text-cp-white mb-4">
            TRY IT <span className="text-cp-blue">LIVE</span>
          </h2>
          <p className="font-barlow text-cp-grey-400 text-lg max-w-xl mx-auto">
            Preview the Studio canvas. Click controls below to see it in action.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row items-start gap-8">
          {/* Canvas Preview */}
          <div className="flex-1 w-full bg-[#0d0d0d] border border-cp-grey-800 rounded-lg overflow-hidden">
            <canvas
              ref={canvasRef}
              width={800}
              height={450}
              className="w-full h-auto"
            />
          </div>

          {/* Controls */}
          <div className="w-full lg:w-64 space-y-6">
            {/* Text Input */}
            <div>
              <label className="font-condensed text-xs font-bold tracking-[0.2em] text-cp-grey-500 uppercase block mb-2">
                Design Text
              </label>
              <input
                type="text"
                value={text}
                onChange={e => setText(e.target.value || 'YOUR DESIGN')}
                className="w-full bg-cp-grey-900 border border-cp-grey-700 rounded px-3 py-2 text-cp-white font-barlow text-sm focus:outline-none focus:border-cp-blue"
                placeholder="Type your text"
              />
            </div>

            {/* Color Swatches */}
            <div>
              <label className="font-condensed text-xs font-bold tracking-[0.2em] text-cp-grey-500 uppercase block mb-2">
                Color
              </label>
              <div className="flex gap-2">
                {['#D4AF37', '#FAFAFA', '#1E3A8A', '#c41e3a', '#22c55e'].map(c => (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className={`w-10 h-10 rounded border-2 transition-all ${
                      color === c ? 'border-cp-white scale-110' : 'border-cp-grey-700 hover:border-cp-grey-500'
                    }`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>

            {/* Quick Text Buttons */}
            <div>
              <label className="font-condensed text-xs font-bold tracking-[0.2em] text-cp-grey-500 uppercase block mb-2">
                Quick Text
              </label>
              <div className="flex flex-wrap gap-2">
                {sampleTexts.map(t => (
                  <button
                    key={t}
                    onClick={() => setText(t)}
                    className={`px-3 py-1 rounded text-xs font-condensed font-bold tracking-wider transition-all ${
                      text === t
                        ? 'bg-cp-blue text-white'
                        : 'bg-cp-grey-900 text-cp-grey-400 hover:bg-cp-grey-800'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* CTA */}
            <a href="/studio" className="btn-primary w-full text-center !text-sm !py-3 block">
              OPEN STUDIO
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
