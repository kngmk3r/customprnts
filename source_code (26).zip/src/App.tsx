import { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import SiteHeader from './components/SiteHeader';
import Hero from './components/Hero';
import TheJourney from './components/TheJourney';
import TryItLive from './components/TryItLive';
import Gallery from './components/Gallery';
import Footer from './components/Footer';
import { StudioApp } from './studio';
import GalleryPage from './pages/GalleryPage';
import PricingPage from './pages/PricingPage';
import AboutPage from './pages/AboutPage';

function HomePage() {
  return (
    <div className="min-h-screen bg-cp-black text-cp-white overflow-x-hidden">
      <SiteHeader mode="marketing" />
      <Hero />
      <TheJourney />
      <TryItLive />
      <Gallery />
      <Footer />
    </div>
  );
}

function NotFound() {
  return (
    <div className="min-h-screen bg-cp-black text-cp-white flex items-center justify-center">
      <div className="text-center">
        <h1 className="stencil-text text-6xl text-cp-blue mb-4">404</h1>
        <p className="font-body text-cp-grey-400 mb-8">Page not found</p>
        <a href="/" className="btn-primary">Back to Home</a>
      </div>
    </div>
  );
}

function App() {
  const location = useLocation();

  useEffect(() => {
    const titles: Record<string, string> = {
      '/': 'CUSTOM PRNTS — Turn Your Idea Into a Design',
      '/studio': 'CUSTOM PRNTS Design Studio',
      '/gallery': 'CUSTOM PRNTS — Gallery',
      '/pricing': 'CUSTOM PRNTS — Pricing',
      '/about': 'CUSTOM PRNTS — About',
    };
    document.title = titles[location.pathname] || 'CUSTOM PRNTS — Your Idea. Printed Today.';
  }, [location.pathname]);

  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/studio" element={<StudioApp />} />
      <Route path="/gallery" element={<GalleryPage />} />
      <Route path="/pricing" element={<PricingPage />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
