/* eslint-disable @typescript-eslint/no-explicit-any */
/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_EDGESPARK_WORKER_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

export {};