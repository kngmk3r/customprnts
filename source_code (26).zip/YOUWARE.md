# CUSTOM PRNTS — Design Studio Platform

## Project Overview
A custom design studio platform where users turn ideas into designs. Printing is one possible output among several. Built with React, TypeScript, Vite, and Tailwind CSS. Hosted on YouWare.

## Brand Identity
- **Name**: CUSTOM PRNTS
- **Tagline**: "TURN YOUR IDEA INTO A DESIGN"
- **Colors**: Black (#0A0A0A / #0d0d0d / #111111) / White (#FAFAFA) base with Gold (#D4AF37) premium accent, Royal Blue (#1E3A8A) secondary
- **Fonts**: Bebas Neue (stencil headlines), Oswald (headings), Barlow Condensed (UI), Barlow (body)

## Stack
- Frontend: React 18 + Vite + Fabric.js 5.3 (CDN-loaded) + Tailwind CSS 3.4
- Backend: Node.js/EdgeSpark (Hono) + YouBase (Drizzle ORM, SQLite) + Storage bucket `studio-designs`
- AI Providers: Runware API (free + premium Ideogram/Recraft), Google Gemini 3.1 Flash Image, OpenAI GPT-Image-2

## Architecture (V2 — Intent-based)

### Frontend Router — `src/studio/StudioApp.tsx`
- 7 views: `projects` | `new-project` (Interview) | `concepts` | `placement` | `editor` | `produce` | `locker`
- `/placement` = stable zero-experience flow (Formation Cards polished in Zip 23), `/editor` = advanced v2
- Session handling: `ensureSession()` before generation with checking/failed overlays

### AI Image Generation — Two-Tier (Tier-aware)

**CONFIG in `backend/server/src/index.ts`:**
- `runware.freeNoText`: `runware:100@1` steps:4 $0.0006/img — FLUX schnell, mangles text
- `runware.freeWithText`: `prunaai:p-image@ideogram` $0.0016875/img — Ideogram-family, handles lettering
- `runware.premium`: `ideogram:4@0` $0.03/img — best typography for merch
- `runware.premiumAlt`: `recraft:v4.1@0` $0.035/img — design-native
- `gemini`: `gemini-3.1-flash-image` — ~$0.04/img est
- `openai`: `gpt-image-2` size 1024x1024 quality high background transparent $0.1248/img — last resort

**FREE tier:**
- `briefHasText()` checks `mainWording` + description/notes for quoted text or keywords (text|word|slogan|says|lettering|typography|font|quote|caption|name|title|logo)
- If hasText → freeWithText (Ideogram), else freeNoText (schnell) with fallback to freeWithText if schnell fails
- Watermark: Runware `advancedFeatures.watermark` tiled CUSTOM PRNTS 0.35 opacity #cccccc
- Never falls back to paid models (Runware-only)

**PREMIUM tier — chain after Zip 23 fix:**
- **Ideogram → Recraft → Gemini → OpenAI** (Gemini primary, OpenAI last-resort, reversed from OpenAI→Gemini)
- No watermark, clean output, PNG with alpha
- Parallelized batch: `Promise.all` 4 prompts ~40s→12s, atomic cleanup on failure (deletes uploaded keys)
- Cost tracking: `generation_batches.cost_usd`, `generated_designs.cost_usd` from Runware `includeCost`

**Prompt Construction:**
- Neutral ChatGPT-style, no forced art directions, 4 variation instructions per batch (Bold Graphic, Artistic Illustrative, Clean Minimal photorealistic NO logos/mascots, Stylized Retro)
- Artwork-only, isolated on plain background — no garment mockup, no mannequin, no product photography

### Backend Routes (All authenticated via /api/*, CORS for customprnts.youware.app + *.preview.youware.app)
- `POST /api/generate-batch` — 4 images tier-aware, rate limit 1/60s, accepts optional `projectId` for retry (now infers tier from last batch if tier not supplied), optional `tier` free|premium
- `POST /api/regenerate-design` — single regen preserving batch tier, rate limit 1/20s, lifecycle versioning (old → superseded, new → active)
- `GET /api/designs/:projectId` — active only ordered by concept_index
- `GET /api/design-history/:projectId` — all designs grouped by batch, newest first
- `GET /api/design-url/:designId` — fresh signed URL
- `POST /api/locker/add` + `GET /api/locker` + `DELETE /api/locker/:id` — saved designs grouped by project
- `GET /api/public/hello` — health

### Database Tables
- `studio_projects`: id, owner_user_id, brief_json, created_at, updated_at
- `generation_batches`: id, owner_user_id, project_id, provider, model, prompt_version, status, timing, errors, cost_usd, tier (free|premium)
- `generated_designs`: id, owner_user_id, project_id, batch_id, concept_index, concept_name, provider, model, prompt, storage_key, preview_storage_key, status (active|superseded), cost_usd, created_at
- `generation_events`: id, owner_user_id, event_type (batch|regenerate), project_id, batch_id, design_id, created_at — for rate limiting
- `locker_items`: id, owner_user_id, project_id, design_id, design_image_url, storage_key, prompt, product_type, style, concept_name, created_at

### Storage
- `studio-designs` bucket — private, path `${userId}/${projectId}/${batchId}/${designId}.png`, signed URLs 3600s

## Design Studio (/studio) Flow
1. Projects → Browse/load
2. Interview → Sequential Q&A (getNextQuestion) — text, textarea, select, color-swatches (single + multi 3 max), image-upload — 320px mobile polished
3. Concept Selection → AI 4 concepts, Select/Regenerate (MAX 3 → 5 min cooldown localStorage + server 20s), Keep in Locker/Discard, View Previous Generations
4. Design Placement → ★ Polished Zip 23: Formation Cards (ghost mannequins + glowing Print Zones) — responsive desktop split 52/48 + mobile tabs placements/preview
5. Design Editor → Advanced v2 modular (Fabric.js) — LeftToolbar (AI, Upload, Text, Shapes, Layers 56px + panel), CenterCanvas, RightPanel context-sensitive, FloatingToolbar bound to object:moving/scaling/rotating, Physical Intent smart layouts, Editor/Mockup toggle via MockupRenderer
6. Produce → Three equal choices: Order Print / Download Files / Save Project — uses MockupRenderer for 1:1 match
7. Locker → Saved designs grouped by project

### Files (Key)
```
src/studio/
├── StudioApp.tsx               — Main router 7 views + session handling
├── getNextQuestion.ts          — Interview question definitions + sequential logic
├── conceptGenerator.ts         — Client AI tier definitions, generateConceptsAsync(brief, tier), regenerateDesignAsync, locker + history APIs
├── edgesparkClient.ts          — studioFetch authenticated
├── storage.ts                  — IndexedDB cp-studio, Project type with placement {presetId?, widthInches, topOffsetInches, horizontalOffsetInches, rotationDegrees} + legacyPlacement
├── store.ts                    — useStudioStore hook: createProject(brief, tier), openProject, regenerateConcept, retryGeneration (now tier-preserving via backend inference), overlay management (watermark etc)
├── pages/
│   ├── NewProjectPage.tsx      — ★ Zip 23 polished: 320px safe, rounded-xl inputs, color swatches grid 4 xs:5 sm:7, progress bar gold glow
│   ├── ConceptSelectionPage.tsx — 4-grid, locker/discard, history
│   ├── PlacementPage.tsx        — ★ Zip 23 full rewrite: Formation factory per category, ghost silhouettes (TShirt/Hat/Mug/Generic), glowing Print Zones with corner brackets, color picker 44-48px rounded 12px + dark/light logic, mobile tabs + auto-switch
│   ├── DesignEditorPage.tsx     — Wraps EditorLayout v2
│   ├── ProjectsPage.tsx
│   ├── LockerPage.tsx
│   └── ProducePage.tsx
├── editor/
│   ├── data/productLibrary.ts  — 25+ products, 10 categories, viewpoint system (front/back/sleeve etc), physicalPrintArea inches, colors GARMENT/CERAMIC/METAL, mapBriefToProductId
│   ├── components/MockupRenderer.tsx — Offscreen canvas compositing baseImageUrl + maskUrl via source-in, fallback to colored silhouette
│   ├── components/v2/EditorLayout.tsx — ★ Fixed hook ordering + polished mobile: top bar 14px rounded-full back, view toggle + zoom range, canvas bg #080808, floating toolbar mobile backdrop-blur rounded-full, layers bottom sheet 60%, bottom toolbar scrollable 320+ safe min-w 56px touch targets
│   ├── components/v2/CenterCanvas.tsx, LeftToolbar.tsx, RightPanel.tsx, FloatingToolbar.tsx, ProductBrowser.tsx, ViewpointBar.tsx
│   └── utils/ HistoryManager.ts, exportManager.ts, measurementUtils.ts, etc
└── overlaySystem.ts            — 13 overlay types non-destructive (watermark etc) pointer-events:none

backend/server/src/
├── index.ts                    — Hono routes, CONFIG two-tier, briefHasText, buildImagePrompt, isRetryable, adapters geminiGenerate/openaiGenerate/runwareGenerate (array task body, outputType base64Data PNG includeCost), generateBatchAtomic Promise.all, commitBatchToDb, buildProviderChain (free Runware-only, premium Ideogram→Recraft→Gemini→OpenAI), rate limit via generation_events
└── __generated__/ db_schema.ts, etc

src/components/ — Homepage Studio-first: SiteHeader, Hero "Turn Your Idea Into a Design", TheJourney horizontal strip, TryItLive canvas demo, Gallery Made in the Studio, Footer
```

### Editor Architecture (v2)
- **State Separation:** CanvasState (artwork layers) decoupled from PlacementState (product placement)
- **Physical Sync:** Real-time inch/offset calculations from canvas object transforms → placementWidthInches etc
- **Floating UI:** FloatingToolbar follows selections, wired to canvas transform events via trigger counter
- **Save State:** Every project remembers artwork, layers, placement with presetId, scale, rotation, product, color, view
- **Future Ready:** 360° viewer, multiple artwork per view, multiple products per project, version history, etc

### Placement Presets (Now Formation Factory)
- Tops: Center Chest 10" MOST POPULAR, Left Chest 3.5", Right Chest 3.5", Full Front 11.5" PREMIUM, Full Back 12", Upper Back 4", Left Sleeve 3"
- Headwear: Front Center 4" MOST POPULAR, Back Arch 3", Side Left/Right 2.5"
- Drinkware: Front 3.2" MOST POPULAR, Back 3.2", Full Wrap 8.5" PREMIUM
- Generic: per viewpoint 75% of maxWidth

### AI Prompt Spec
- `IMPORTANT: Generate ONLY isolated artwork on plain background, no garment/mockup/model/person/mannequin, follow customer description faithfully, no forced style unless requested, otherwise natural ChatGPT-like polished image + Variation instruction`

### Interview Flow
- `getNextQuestion(brief)` returns next unanswered where value === undefined (empty '' counts as answered for optional skip)
- UI: answered collapsed opacity 70%, current active gold border shadow, Next/Skip/Previous, Review step with edit jump-back (deletes target + later fields)
- To swap for AI conversation: replace body of getNextQuestion() — UI unchanged

### Produce Step
- MockupRenderer uses same compositing as Editor for 1:1 visual match
- Three equal choices not funnel: Order Print (Pickup 3hrs / Delivery 2-5 days), Download Files (Transparent PNG / PNG with bg / Project JSON), Save Project (IndexedDB)

### Mobile 320px Polish (Zip 23)
- Tailwind added `xs: 360px` breakpoint (previously dead)
- Interview: px-4 mobile px-6 desktop, rounded-xl inputs py-3.5, color grid 4 cols at 320 5 at 360, upload icon circle
- Placement: grid-cols-2 mobile lg:grid-cols-3, tabs placements/preview sticky top-14, cards aspect 3/4 mobile, color picker 44px rounded 12px
- Editor mobile: top bar 14px rounded-full back + truncated, undo/redo/save circles, view toggle + zoom range, canvas shadow, floating toolbar backdrop-blur rounded-full, layers sheet 20px rounded-t, bottom toolbar overflow-x-auto min-w 56px

## Build
```bash
pnpm install
pnpm run build  # vite 7.3 — 74 modules → 512 kB JS (139 kB gzip) + 6.22 kB CSS
backend: edgespark build (Hono)
```

## Backend Secrets Required
- `RUNWARE_API_KEY` — for free + premium tier
- `GEMINI_API_KEY` — gemini-3.1-flash-image
- `OPENAI_API_KEY` — gpt-image-2 (expensive last-resort)

## Current ZIP
- `source_code (22).zip` was base (YouWare state with two-tier implemented)
- `source_code_polished.zip` is current — includes Placement + mobile overhaul + backend Gemini-primary fix + storage fix + tailwind xs
- Dist not included — build output excluded

## Known Issues / Next Steps
- ConceptSelectionPage mobile still needs polish (1 col sm:2 currently, buttons could stack vertically at 320)
- ProducePage uses mixed legacy `designSize %` + new `widthInches` — should be inches-only
- Formation cards for bags/home could have custom silhouettes (tote shape) vs generic rect
- Cost tracking: Gemini/OpenAI cost_usd = 0 (Runware returns cost) — should estimate
- Overlay system: FREE watermark is baked pixels (Runware), not just UI overlay — two systems conflated
- No test harness for fallback chain — dev endpoint /api/test-fallback could force-fail Runware
- Rate limiting dual layer (localStorage 3→5min + server 60s/20s) — maybe redundant but works
- `yw_manifest.json` worker_url → backend endpoint

## Brand Evolution
Zip 17 Product Perfection — offscreen canvas compositing, physical sync, floating toolbar, unified produce
Zip 21 Unified Placement — Two-path /placement (public guided) + /editor (advanced private) sharing data model, Formation Cards ghost mannequins
Zip 22 Two-tier — Runware free ($0.0024/batch) + premium Ideogram→Recraft→GPT-4o→Gemini pipeline, parallelized 40s→12s, cost_usd/tier tracking
Zip 23 Polished UI (current) — Formation factory per category, premium draft-day visuals, full mobile 320px interview/placement/editor, tailwind xs, backend Gemini primary reversal
