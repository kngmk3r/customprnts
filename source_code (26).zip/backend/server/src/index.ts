import { Hono } from "hono";
import type { Client } from "@sdk/server-types";
import { tables, buckets } from "@generated";
import { eq, and, gt } from "drizzle-orm";
import { GoogleGenAI } from "@google/genai";

// ═══════════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════════

const CONFIG = {
  fallbackEnabled: true,
  // Fix for free tier being completely broken when Runware fails — allow Gemini as cheap emergency fallback
  // User analysis: free was locked to Runware-only since recent change, previous successes came from older version that allowed Gemini fallback
  freeAllowGeminiFallback: true,

  runware: {
    endpoint: "https://api.runware.ai/v1",
    // FREE — no text. Step-distilled: steps:4 is REQUIRED, not optional.
    freeNoText:   { model: "runware:100@1", steps: 4 },      // $0.0006/img
    // FREE — brief contains text/slogan
    freeWithText: { model: "prunaai:p-image@ideogram" },      // $0.0016875/img
    // PREMIUM primary — best typography for merch
    premium:      { model: "ideogram:4@0" },                  // $0.03/img
    // PREMIUM fallback — design-native
    premiumAlt:   { model: "recraft:v4.1@0" },                // $0.035/img
    timeoutMs: 60_000,
  },

  // gemini-2.5-flash-image was RETIRED 2026-01-15 — current code 404s
  gemini: { model: "gemini-3.1-flash-image", timeoutMs: 60_000 },

  // gpt-image-1 superseded. NOTE: quality "high" = $0.1248/img — keep as
  // last-resort fallback only, never primary.
  openai: {
    model: "gpt-image-2",
    size: "1024x1024" as const,
    quality: "high" as const,
    background: "transparent" as const,
    timeoutMs: 60_000,
  },

  promptVersion: "v6",
  conceptsPerBatch: 4,

  rateLimits: {
    batchCooldownMs: 60_000,
    regenCooldownMs: 20_000,
    freeDailyBatches: 5,
  },

  freeTierWatermark: true,

  maxInputLengths: {
    name: 200, description: 2000, productType: 50,
    preferredColors: 200, mainWording: 200, notes: 2000,
  },

  allowedOrigins: [
    "https://customprnts.youware.app",
    "https://*.preview.youware.app",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
  ],
} as const;

type ProviderName = "runware" | "gemini" | "openai";
type Tier = "free" | "premium";

interface BriefInput {
  name?: string; description?: string; productType?: string;
  preferredColors?: string; mainWording?: string; notes?: string;
}

interface DesignResult {
  id: string; conceptIndex: number; conceptName: string;
  storageKey: string; signedPreviewUrl: string;
}

// Typed error that carries uploaded keys for cleanup
class BatchGenerationError extends Error {
  uploadedKeys: string[];
  constructor(message: string, uploadedKeys: string[]) {
    super(message);
    this.name = "BatchGenerationError";
    this.uploadedKeys = uploadedKeys;
  }
}

// ═══════════════════════════════════════════════════════════════════
// VALIDATION + SANITIZE
// ═══════════════════════════════════════════════════════════════════

function validateBrief(brief: any): { valid: boolean; error?: string } {
  if (!brief || typeof brief !== "object") return { valid: false, error: "Invalid request body" };
  for (const [key, maxLen] of Object.entries(CONFIG.maxInputLengths)) {
    const val = brief[key];
    if (val !== undefined && val !== null && typeof val === "string" && val.length > maxLen) {
      return { valid: false, error: `Field "${key}" exceeds max length ${maxLen}` };
    }
  }
  return { valid: true };
}

function sanitize(val: unknown, max: number): string {
  return typeof val === "string" ? val.slice(0, max).trim() : "";
}

/**
 * FLUX schnell mangles lettering. Any brief with text MUST route to the
 * Ideogram-family model. Your ProjectBrief has a dedicated mainWording field.
 */
function briefHasText(brief: BriefInput): boolean {
  if (sanitize(brief.mainWording, 200).length > 0) return true;
  const blob = `${sanitize(brief.description, 2000)} ${sanitize(brief.notes, 2000)}`;
  if (/"'""].{2,}["'"""]/.test(blob)) return true;
  if (/\b(text|word|words|slogan|says|saying|lettering|typography|font|quote|caption|name|title|logo)\b/i.test(blob)) return true;
  return false;
}

// ═══════════════════════════════════════════════════════════════════
// PROMPT CONSTRUCTION
// ═══════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════
// NEUTRAL PROMPT BUILDER — ChatGPT-style, no forced art directions
// ═══════════════════════════════════════════════════════════════════

const VARIATION_INSTRUCTIONS = [
  // Concept 1: Bold Graphic — strong, punchy, merchandise-ready
  "Create a bold, eye-catching graphic interpretation. Strong composition, vivid colors, punchy visual impact. Output only the isolated artwork on a plain background — no garment, no mockup.",
  // Concept 2: Artistic / Illustrative — creative, expressive, painterly
  "Create an artistic, illustrative interpretation with a creative or painterly quality. Expressive composition, rich detail, unique artistic flair. Output only the isolated artwork on a plain background — no garment, no mockup.",
  // Concept 3: Clean Minimal — photorealistic, natural, NO logos/mascots/clip-art
  "Create a clean, minimal, photorealistic image. This should look like a real photograph or a high-quality realistic digital painting — NOT a logo, NOT a mascot, NOT a badge or crest, NOT a vector illustration, NOT clip-art, NOT a t-shirt graphic. No bold outlines, no flat shading, no text banners, no ribbon shapes. Natural lighting, realistic textures, lifelike quality. Output only the image on a plain background — no garment, no mockup.",
  // Concept 4: Stylized / Retro — unique aesthetic, vintage or trending style
  "Create a stylized interpretation with a distinctive aesthetic — vintage, retro, neon, or trending art style. Unique color palette, interesting textures or effects. Output only the isolated artwork on a plain background — no garment, no mockup.",
];

function buildImagePrompt(brief: BriefInput, variationIndex: number): string {
  const name = sanitize(brief.name, 200) || "";
  const desc = sanitize(brief.description, 2000) || "";
  const pt = sanitize(brief.productType, 50) || "";
  const colors = sanitize(brief.preferredColors, 200) || "";
  const wording = sanitize(brief.mainWording, 200) || "";
  const notes = sanitize(brief.notes, 2000) || "";

  let prompt = `Create an image based on the following customer request.\n\n`;

  if (desc) {
    prompt += `Main request: ${desc}\n`;
  }

  if (name) {
    prompt += `Project name: ${name}\n`;
  }

  if (colors) {
    prompt += `Preferred colors: ${colors}\n`;
  }

  if (pt) {
    prompt += `Product context: ${pt}\n`;
  }

  if (wording) {
    prompt += `Requested wording: ${wording}\n`;
  }

  if (notes) {
    prompt += `Additional details: ${notes}\n`;
  }

  prompt += `
IMPORTANT: Generate ONLY the isolated artwork itself on a plain background.
This is a standalone image meant to be placed onto a product later by the editor.

Do NOT include:
- No t-shirt mockup, no garment, no clothing product shot
- No photo of apparel, no model wearing clothing
- No product photography, no lifestyle photo
- No hoodie, no sweatshirt, no hat, no mug, no product of any kind
- No person, no model, no mannequin

DO include:
- The artwork only, isolated on a clean plain background
- Follow the customer's description faithfully
- Do not impose a style that the customer did not request
- If the customer requests a particular style or layout, follow it
- Otherwise create a natural, polished image similar to ordinary ChatGPT image generation
`;

  const variation = VARIATION_INSTRUCTIONS[variationIndex % VARIATION_INSTRUCTIONS.length];
  prompt += `\nVariation instruction: ${variation}`;

  return prompt;
}

// ═══════════════════════════════════════════════════════════════════
// RETRYABLE ERROR DETECTION
// ═══════════════════════════════════════════════════════════════════

function isRetryable(err: any): boolean {
  const m = String(err?.message || "").toLowerCase();
  if (m.includes("timeout") || m.includes("econnrefused") || m.includes("econnreset") || m.includes("fetch failed")) return true;
  if (m.includes("429") || m.includes("rate limit")) return true;
  if (m.includes("500") || m.includes("502") || m.includes("503") || m.includes("504")) return true;
  return false;
}

// ═══════════════════════════════════════════════════════════════════
// IMAGE GENERATION ADAPTERS
// ═══════════════════════════════════════════════════════════════════

async function geminiGenerate(apiKey: string, prompt: string): Promise<{ data: string; mime: string }> {
  const ai = new GoogleGenAI({ apiKey });
  const res = await ai.models.generateContent({
    model: CONFIG.gemini.model, contents: prompt,
    config: { temperature: 1.0, responseModalities: ["image", "text"] },
  });
  const parts = res.candidates?.[0]?.content?.parts || [];
  const img = parts.find((p: any) => p.inlineData);
  if (!img?.inlineData?.data) throw new Error("No image data from Gemini");
  return { data: img.inlineData.data, mime: img.inlineData.mimeType || "image/png" };
}

async function openaiGenerate(apiKey: string, prompt: string): Promise<{ data: string; mime: string }> {
  const res = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: CONFIG.openai.model, prompt, n: 1, size: CONFIG.openai.size, quality: CONFIG.openai.quality, background: CONFIG.openai.background }),
  });
  if (!res.ok) throw new Error(`OpenAI HTTP ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const json: any = await res.json();
  const b64 = json.data?.[0]?.b64_json;
  if (!b64) throw new Error("No image data from OpenAI");
  return { data: b64, mime: "image/png" };
}

interface RunwareOpts {
  model: string;
  steps?: number;
  watermark?: boolean;
  width?: number;
  height?: number;
}

/**
 * Runware image adapter. Body is an ARRAY of task objects.
 * Verified against api.runware.ai/v1.
 */
async function runwareGenerate(
  apiKey: string,
  prompt: string,
  opts: RunwareOpts,
): Promise<{ data: string; mime: string; cost?: number }> {
  const task: Record<string, unknown> = {
    taskType: "imageInference",
    taskUUID: crypto.randomUUID(),
    model: opts.model,
    positivePrompt: prompt,
    width: opts.width ?? 1024,
    height: opts.height ?? 1024,
    numberResults: 1,
    outputType: "base64Data",
    outputFormat: "PNG",       // PNG required for alpha; JPG has none
    includeCost: true,
    deliveryMethod: "sync",
  };

  // schnell is step-distilled — omitting this is slower AND worse
  if (opts.steps) task.steps = opts.steps;

  if (opts.watermark) {
    task.advancedFeatures = {
      watermark: {
        text: "CUSTOM PRNTS",
        tiled: true,
        opacity: 0.35,
        fontColor: "#cccccc",
      },
    };
  }

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), CONFIG.runware.timeoutMs);
  let res: Response;
  try {
    res = await fetch(CONFIG.runware.endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify([task]),
      signal: ctl.signal,
    });
  } finally {
    clearTimeout(timer);
  }

  if (!res.ok) throw new Error(`Runware HTTP ${res.status}: ${(await res.text()).slice(0, 300)}`);

  const json: any = await res.json();
  if (json.errors?.length) {
    const e = json.errors[0];
    throw new Error(`Runware error: ${e.message || e.code || "unknown"}`);
  }

  const item = (json.data || []).find((d: any) => d.taskType === "imageInference");
  if (!item?.imageBase64Data) throw new Error("No image data from Runware");

  return {
    data: item.imageBase64Data.replace(/^data:image\/\w+;base64,/, ""),
    mime: "image/png",
    cost: item.cost,
  };
}

// ═══════════════════════════════════════════════════════════════════
// STORAGE HELPERS
// ═══════════════════════════════════════════════════════════════════

function mimeToExt(mime: string): string {
  if (mime.includes("jpeg") || mime.includes("jpg")) return ".jpg";
  if (mime.includes("webp")) return ".webp";
  if (mime.includes("gif")) return ".gif";
  return ".png";
}

async function saveImage(edgespark: Client<any>, key: string, b64Data: string, mime: string) {
  const buf = Uint8Array.from(atob(b64Data), (c) => c.charCodeAt(0));
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
  await edgespark.storage.from(buckets.studio_designs).put(key, ab, { contentType: mime });
}

async function deleteImage(edgespark: Client<any>, key: string) {
  try { await edgespark.storage.from(buckets.studio_designs).delete(key); } catch { /* best effort */ }
}

async function getSignedUrl(edgespark: Client<any>, key: string): Promise<string> {
  const { downloadUrl } = await edgespark.storage.from(buckets.studio_designs).createPresignedGetUrl(key, 3600);
  return downloadUrl;
}

async function cleanupKeys(edgespark: Client<any>, keys: string[]) {
  for (const k of keys) await deleteImage(edgespark, k);
}

// ═══════════════════════════════════════════════════════════════════
// AUTH + CORS
// ═══════════════════════════════════════════════════════════════════

function requireUser(edgespark: Client<any>, c: any): { ok: boolean; user?: any; error?: any } {
  const user = edgespark.auth.user;
  if (!user) return { ok: false, error: c.json({ success: false, error: { code: "UNAUTHORIZED", message: "Authentication required.", retryable: false } }, 401) };
  return { ok: true, user };
}

function isOriginAllowed(origin: string): boolean {
  return CONFIG.allowedOrigins.some((o) => o.includes("*") ? origin.endsWith(o.replace("*.", "")) : origin === o);
}

// ═══════════════════════════════════════════════════════════════════
// RATE LIMIT via generation_events
// ═══════════════════════════════════════════════════════════════════

async function checkRateLimit(edgespark: Client<any>, userId: string, eventType: string, cooldownMs: number): Promise<boolean> {
  const recent = await edgespark.db.select({ id: tables.generationEvents.id }).from(tables.generationEvents)
    .where(and(eq(tables.generationEvents.ownerUserId, userId), eq(tables.generationEvents.eventType, eventType), gt(tables.generationEvents.createdAt, Date.now() - cooldownMs))).limit(1);
  return recent.length > 0;
}

async function recordEvent(edgespark: Client<any>, userId: string, eventType: string, refs: { projectId?: string; batchId?: string; designId?: string } = {}) {
  const id = `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  await edgespark.db.insert(tables.generationEvents).values({
    id, ownerUserId: userId, eventType,
    projectId: refs.projectId || null, batchId: refs.batchId || null, designId: refs.designId || null,
  });
}

// ═══════════════════════════════════════════════════════════════════
// ATOMIC BATCH GENERATOR
// Fix #1: Cleans up uploaded files on failure before rethrowing
// ═══════════════════════════════════════════════════════════════════

async function generateBatchAtomic(
  edgespark: Client<any>,
  genFn: (prompt: string) => Promise<{ data: string; mime: string; cost?: number }>,
  prompts: { index: number; prompt: string }[],
  userId: string, projectId: string, batchId: string,
): Promise<(DesignResult & { costUsd: number })[]> {
  const uploadedKeys: string[] = [];
  try {
    const results = await Promise.all(
      prompts.map(async ({ prompt, index }) => {
        const did = `design_${Date.now()}_${index}_${Math.random().toString(36).slice(2, 6)}`;
        const { data, mime, cost } = await genFn(prompt);
        const ext = mimeToExt(mime);
        const sk = `${userId}/${projectId}/${batchId}/${did}${ext}`;
        await saveImage(edgespark, sk, data, mime);
        uploadedKeys.push(sk);
        const url = await getSignedUrl(edgespark, sk);
        return {
          id: did, conceptIndex: index, conceptName: `Concept ${index + 1}`,
          storageKey: sk, signedPreviewUrl: url, costUsd: cost ?? 0,
        };
      }),
    );
    return results.sort((a, b) => a.conceptIndex - b.conceptIndex);
  } catch (err: any) {
    await cleanupKeys(edgespark, uploadedKeys);
    throw new BatchGenerationError(err.message || "Batch generation failed", uploadedKeys);
  }
}

// ═══════════════════════════════════════════════════════════════════
// COMMIT BATCH TO DB
// ═══════════════════════════════════════════════════════════════════

async function commitBatchToDb(
  edgespark: Client<any>, designs: (DesignResult & { costUsd: number })[],
  prompts: { index: number; prompt: string }[],
  provider: ProviderName, model: string, tier: Tier,
  userId: string, projectId: string, batchId: string,
) {
  const batchCost = designs.reduce((s, d) => s + (d.costUsd || 0), 0);
  await edgespark.db.update(tables.generationBatches).set({
    costUsd: batchCost, tier,
  }).where(eq(tables.generationBatches.id, batchId));

  for (let i = 0; i < designs.length; i++) {
    const d = designs[i];
    await edgespark.db.insert(tables.generatedDesigns).values({
      id: d.id, ownerUserId: userId, projectId, batchId,
      conceptIndex: d.conceptIndex, conceptName: d.conceptName,
      provider, model, prompt: prompts[i].prompt,
      storageKey: d.storageKey, previewStorageKey: d.storageKey,
      status: "active", costUsd: d.costUsd || 0,
    });
  }
}

// ═══════════════════════════════════════════════════════════════════
// TIER-AWARE PROVIDER CHAIN
// ═══════════════════════════════════════════════════════════════════

interface ProviderAttempt {
  name: ProviderName;
  model: string;
  run: (prompt: string) => Promise<{ data: string; mime: string; cost?: number }>;
}

function buildProviderChain(
  edgespark: Client<any>,
  tier: Tier,
  useTextModel: boolean,
): ProviderAttempt[] {
  const rwKey  = edgespark.secret.get("RUNWARE_API_KEY");
  const oaiKey = edgespark.secret.get("OPENAI_API_KEY");
  const gemKey = edgespark.secret.get("GEMINI_API_KEY");
  const chain: ProviderAttempt[] = [];

  if (tier === "free") {
    if (rwKey) {
      const cfg = useTextModel ? CONFIG.runware.freeWithText : CONFIG.runware.freeNoText;
      chain.push({
        name: "runware", model: cfg.model,
        run: (p) => runwareGenerate(rwKey, p, {
          model: cfg.model,
          steps: (cfg as any).steps,
          watermark: CONFIG.freeTierWatermark,
        }),
      });
      // escalate to the text model if schnell fails
      if (!useTextModel) {
        chain.push({
          name: "runware", model: CONFIG.runware.freeWithText.model,
          run: (p) => runwareGenerate(rwKey, p, {
            model: CONFIG.runware.freeWithText.model,
            watermark: CONFIG.freeTierWatermark,
          }),
        });
      }
    }
    // Emergency fallback for free tier when Runware fails — allows Gemini (cheap ~$0.04) to keep UX working
    // Does NOT fall back to expensive OpenAI gpt-image-2 high ($0.1248) — that's premium-only last resort
    // This fixes "free is completely broken when Runware fails" per user analysis
    if (CONFIG.freeAllowGeminiFallback && gemKey) {
      chain.push({
        name: "gemini", model: CONFIG.gemini.model,
        run: (p) => geminiGenerate(gemKey, p),
      });
    }
    // If still empty (no Runware key and no Gemini), return empty → 503 NO_PROVIDER
    return chain;
  }

  // PREMIUM — clean output, no watermark
  // Spec: Ideogram → Recraft → Gemini → OpenAI
  // User noted: Gemini is primary fallback, OpenAI is secondary (just reversed)
  // So after Runware premium (Ideogram/Recraft), Gemini before OpenAI (g-image-2 is expensive last-resort)
  if (rwKey) {
    chain.push({
      name: "runware", model: CONFIG.runware.premium.model,
      run: (p) => runwareGenerate(rwKey, p, { model: CONFIG.runware.premium.model }),
    });
    chain.push({
      name: "runware", model: CONFIG.runware.premiumAlt.model,
      run: (p) => runwareGenerate(rwKey, p, { model: CONFIG.runware.premiumAlt.model }),
    });
  }
  if (gemKey) chain.push({ name: "gemini", model: CONFIG.gemini.model, run: (p) => geminiGenerate(gemKey, p) });
  if (oaiKey) chain.push({ name: "openai", model: CONFIG.openai.model, run: (p) => openaiGenerate(oaiKey, p) });

  return chain;
}

// ═══════════════════════════════════════════════════════════════════
// HONO APP
// ═══════════════════════════════════════════════════════════════════

export async function createApp(edgespark: Client<typeof tables>): Promise<Hono> {
  const app = new Hono();

  // CORS on all /api/*
  app.use("/api/*", async (c, next) => {
    const origin = c.req.header("Origin") || "";
    if (origin && isOriginAllowed(origin)) {
      c.header("Access-Control-Allow-Origin", origin);
      c.header("Access-Control-Allow-Credentials", "true");
    }
    c.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    c.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (c.req.method === "OPTIONS") return new Response(null, { status: 204 });
    await next();
  });

  app.get("/api/public/hello", (c) => c.json({ message: "Hello from EdgeSpark!" }));

  // ═══════════════════════════════════════════════════════════════
  // BATCH GENERATION
  // Fix #3: Accept optional projectId for retry under existing project
  // ═══════════════════════════════════════════════════════════════

  app.post("/api/generate-batch", async (c) => {
    const t0 = Date.now();
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;

    let body: any;
    try { body = await c.req.json(); } catch {
      return c.json({ success: false, error: { code: "PARSE_ERROR", message: "Invalid body", retryable: false } }, 400);
    }
    const brief: BriefInput = body;
    const v = validateBrief(brief);
    if (!v.valid) return c.json({ success: false, error: { code: "VALIDATION_ERROR", message: v.error!, retryable: false } }, 400);

    if (await checkRateLimit(edgespark, user.id, "batch", CONFIG.rateLimits.batchCooldownMs)) {
      return c.json({ success: false, error: { code: "RATE_LIMITED", message: "Please wait before generating another batch.", retryable: true } }, 429);
    }

    // Handle optional projectId for retry — preserve tier if not explicitly passed
    let projectId: string;
    let isNewProject = false;
    const requestedProjectId = body.projectId;
    let inferredTier: Tier | null = null;

    if (requestedProjectId && typeof requestedProjectId === "string") {
      const existing = await edgespark.db.select({ id: tables.studioProjects.id })
        .from(tables.studioProjects)
        .where(and(eq(tables.studioProjects.id, requestedProjectId), eq(tables.studioProjects.ownerUserId, user.id)))
        .limit(1);
      if (existing.length === 0) {
        return c.json({ success: false, error: { code: "NOT_FOUND", message: "Project not found or not owned by you.", retryable: false } }, 404);
      }
      projectId = requestedProjectId;
      // Infer tier from last batch if body.tier not supplied
      if (!body.tier) {
        const lastBatches = await edgespark.db.select({ tier: tables.generationBatches.tier, createdAt: tables.generationBatches.createdAt })
          .from(tables.generationBatches)
          .where(eq(tables.generationBatches.projectId, projectId));
        if (lastBatches.length > 0) {
          lastBatches.sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0));
          if (lastBatches[0]?.tier) inferredTier = lastBatches[0].tier as Tier;
        }
      }
    } else {
      projectId = `proj_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      await edgespark.db.insert(tables.studioProjects).values({ id: projectId, ownerUserId: user.id, briefJson: JSON.stringify(brief) });
      isNewProject = true;
    }

    // Tier: explicit body.tier wins, else inferred from retry, else free
    const tier: Tier = body.tier === "premium" ? "premium" : body.tier === "free" ? "free" : (inferredTier || "free");
    const useTextModel = briefHasText(brief);

    const batchId = `batch_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await edgespark.db.insert(tables.generationBatches).values({
      id: batchId, ownerUserId: user.id, projectId,
      provider: "pending", model: "pending",
      promptVersion: CONFIG.promptVersion, status: "generating",
    });

    const prompts = Array.from({ length: CONFIG.conceptsPerBatch }, (_, i) => ({
      index: i,
      prompt: buildImagePrompt(brief, i),
    }));

    // TODO(credits): when credits ship — check balance & decrement here for premium,
    // and refund in the failure branch below.

    const chain = buildProviderChain(edgespark, tier, useTextModel);
    if (chain.length === 0) {
      return c.json({ success: false, error: {
        code: "NO_PROVIDER", message: "Design generation is temporarily unavailable.", retryable: true,
      }}, 503);
    }

    let designs: (DesignResult & { costUsd: number })[] | null = null;
    let providerUsed: ProviderName = chain[0].name;
    let modelUsed = chain[0].model;
    let lastError: any = null;

    for (const attempt of chain) {
      try {
        console.log(`[BATCH] tier=${tier} text=${useTextModel} → ${attempt.name}/${attempt.model}`);
        designs = await generateBatchAtomic(edgespark, attempt.run, prompts, user.id, projectId, batchId);
        providerUsed = attempt.name;
        modelUsed = attempt.model;
        break;
      } catch (err: any) {
        lastError = err;
        console.warn(`[BATCH] ${attempt.name}/${attempt.model} failed: ${err.message}`);
        if (!CONFIG.fallbackEnabled) break;
      }
    }

    const dur = Date.now() - t0;

    if (!designs || designs.length !== CONFIG.conceptsPerBatch) {
      // TODO(credits): refund premium credit here
      await edgespark.db.update(tables.generationBatches).set({
        status: "failed", completedAt: Date.now(), totalDurationMs: dur,
        errorCode: "ALL_FAILED", errorMessageSafe: "Could not generate designs.",
      }).where(eq(tables.generationBatches.id, batchId));
      await recordEvent(edgespark, user.id, "batch", { projectId, batchId });
      return c.json({ success: false, error: { code: "GENERATION_FAILED", message: "Failed to generate designs. Please try again.", retryable: isRetryable(lastError) }, metadata: { batchId, provider: providerUsed, model: modelUsed, promptVersion: CONFIG.promptVersion, totalDurationMs: dur } }, 500);
    }

    const batchCost = designs.reduce((s, d) => s + (d.costUsd || 0), 0);
    console.log(`[BATCH] done tier=${tier} model=${modelUsed} cost=$${batchCost.toFixed(6)}`);

    // Success — commit all 4 as active
    await commitBatchToDb(edgespark, designs, prompts, providerUsed, modelUsed, tier, user.id, projectId, batchId);
    await edgespark.db.update(tables.generationBatches).set({
      status: "completed", completedAt: Date.now(), totalDurationMs: dur,
      provider: providerUsed, model: modelUsed,
    }).where(eq(tables.generationBatches.id, batchId));
    await recordEvent(edgespark, user.id, "batch", { projectId, batchId });

    return c.json({ success: true, projectId, designs, metadata: { batchId, provider: providerUsed, model: modelUsed, tier, promptVersion: CONFIG.promptVersion, totalDurationMs: dur, costUsd: batchCost } });
  });

  // ═══════════════════════════════════════════════════════════════
  // REGENERATION — lifecycle versioning
  // Fix #2: Mark old as superseded, insert new as active
  // ═══════════════════════════════════════════════════════════════

  app.post("/api/regenerate-design", async (c) => {
    const t0 = Date.now();
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;

    let body: any;
    try { body = await c.req.json(); } catch {
      return c.json({ success: false, error: { code: "PARSE_ERROR", message: "Invalid body", retryable: false } }, 400);
    }
    const { designId, brief } = body;
    if (!designId || typeof designId !== "string") return c.json({ success: false, error: { code: "VALIDATION_ERROR", message: "Missing designId", retryable: false } }, 400);
    const v = validateBrief(brief);
    if (!v.valid) return c.json({ success: false, error: { code: "VALIDATION_ERROR", message: v.error!, retryable: false } }, 400);

    // Find the current active design for this concept slot
    const rows = await edgespark.db.select().from(tables.generatedDesigns)
      .where(and(eq(tables.generatedDesigns.id, designId), eq(tables.generatedDesigns.ownerUserId, user.id), eq(tables.generatedDesigns.status, "active")))
      .limit(1);
    if (rows.length === 0) return c.json({ success: false, error: { code: "NOT_FOUND", message: "Design not found or not active", retryable: false } }, 404);
    const d = rows[0];

    if (await checkRateLimit(edgespark, user.id, "regenerate", CONFIG.rateLimits.regenCooldownMs)) {
      return c.json({ success: false, error: { code: "RATE_LIMITED", message: "Please wait before regenerating.", retryable: true } }, 429);
    }

    // Read the batch's original tier — regeneration uses the same tier
    const batchRows = await edgespark.db.select().from(tables.generationBatches)
      .where(eq(tables.generationBatches.id, d.batchId)).limit(1);
    const batchTier: Tier = (batchRows[0]?.tier === "premium") ? "premium" : "free";
    const useTextModel = briefHasText(brief);

    const prompt = buildImagePrompt(brief, d.conceptIndex);
    const nid = `design_${Date.now()}_${d.conceptIndex}_${Math.random().toString(36).slice(2, 6)}`;

    const chain = buildProviderChain(edgespark, batchTier, useTextModel);
    if (chain.length === 0) {
      return c.json({ success: false, error: {
        code: "NO_PROVIDER", message: "Design generation is temporarily unavailable.", retryable: true,
      }}, 503);
    }

    let lastError: any = null;

    for (const attempt of chain) {
      try {
        console.log(`[REGEN] tier=${batchTier} → ${attempt.name}/${attempt.model}`);
        const result = await attempt.run(prompt);
        console.log(`[REGEN] ${attempt.name}/${attempt.model} succeeded.`);
        const ext = mimeToExt(result.mime);
        const nsk = `${user.id}/${d.projectId}/${d.batchId}/${nid}${ext}`;
        await saveImage(edgespark, nsk, result.data, result.mime);
        const url = await getSignedUrl(edgespark, nsk);

        await edgespark.db.update(tables.generatedDesigns).set({ status: "superseded" }).where(eq(tables.generatedDesigns.id, d.id));
        await edgespark.db.insert(tables.generatedDesigns).values({
          id: nid, ownerUserId: user.id, projectId: d.projectId, batchId: d.batchId,
          conceptIndex: d.conceptIndex, conceptName: d.conceptName,
          provider: attempt.name, model: attempt.model, prompt,
          storageKey: nsk, previewStorageKey: nsk, status: "active",
          costUsd: result.cost ?? 0,
        });
        await recordEvent(edgespark, user.id, "regenerate", { projectId: d.projectId, batchId: d.batchId, designId: nid });
        return c.json({ success: true, design: { id: nid, conceptIndex: d.conceptIndex, conceptName: d.conceptName, storageKey: nsk, signedPreviewUrl: url }, metadata: { provider: attempt.name, model: attempt.model, tier: batchTier, promptVersion: CONFIG.promptVersion, totalDurationMs: Date.now() - t0 } });
      } catch (err: any) {
        lastError = err;
        console.warn(`[REGEN] ${attempt.name}/${attempt.model} failed: ${err.message}`);
        if (!CONFIG.fallbackEnabled) break;
      }
    }

    await recordEvent(edgespark, user.id, "regenerate", { projectId: d.projectId, batchId: d.batchId });
    return c.json({ success: false, error: { code: "GENERATION_FAILED", message: "Failed to regenerate. Please try again.", retryable: isRetryable(lastError) } }, 500);
  });

  // ═══════════════════════════════════════════════════════════════
  // GET DESIGNS — active only, ordered by concept_index
  // ═══════════════════════════════════════════════════════════════

  app.get("/api/designs/:projectId", async (c) => {
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;
    const pid = c.req.param("projectId");
    const rows = await edgespark.db.select().from(tables.generatedDesigns)
      .where(and(eq(tables.generatedDesigns.projectId, pid), eq(tables.generatedDesigns.ownerUserId, user.id), eq(tables.generatedDesigns.status, "active")));

    // Order by concept_index to always show exactly the current 4 slots
    rows.sort((a, b) => a.conceptIndex - b.conceptIndex);

    const designs = await Promise.all(rows.map(async (d) => ({
      id: d.id, conceptIndex: d.conceptIndex, conceptName: d.conceptName,
      storageKey: d.storageKey, signedPreviewUrl: await getSignedUrl(edgespark, d.storageKey),
      provider: d.provider, model: d.model, status: d.status,
    })));

    return c.json({ designs });
  });

  // ═══════════════════════════════════════════════════════════════
  // GET DESIGN HISTORY — all designs for a project, grouped by batch
  // ═══════════════════════════════════════════════════════════════

  app.get("/api/design-history/:projectId", async (c) => {
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;
    const pid = c.req.param("projectId");

    const rows = await edgespark.db.select().from(tables.generatedDesigns)
      .where(and(
        eq(tables.generatedDesigns.projectId, pid),
        eq(tables.generatedDesigns.ownerUserId, user.id),
      ));

    // Group by batch, order within each batch by conceptIndex
    const batchMap = new Map<string, typeof rows>();
    for (const r of rows) {
      const arr = batchMap.get(r.batchId) || [];
      arr.push(r);
      batchMap.set(r.batchId, arr);
    }

    const batches = await Promise.all(
      Array.from(batchMap.entries()).map(async ([batchId, designs]) => {
        designs.sort((a, b) => a.conceptIndex - b.conceptIndex);
        // Get batch metadata
        const batchRow = await edgespark.db.select().from(tables.generationBatches)
          .where(eq(tables.generationBatches.id, batchId)).limit(1);
        const batchMeta = batchRow[0] || null;

        const items = await Promise.all(designs.map(async (d) => ({
          id: d.id,
          conceptIndex: d.conceptIndex,
          conceptName: d.conceptName,
          storageKey: d.storageKey,
          signedPreviewUrl: await getSignedUrl(edgespark, d.storageKey),
          provider: d.provider,
          model: d.model,
          prompt: d.prompt,
          status: d.status,
          createdAt: d.createdAt,
        })));

        return {
          batchId,
          provider: batchMeta?.provider || null,
          model: batchMeta?.model || null,
          createdAt: batchMeta?.createdAt || items[0]?.createdAt || 0,
          designs: items,
        };
      })
    );

    // Sort batches newest first
    batches.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    return c.json({ batches });
  });

  // ═══════════════════════════════════════════════════════════════
  // LOCKER — add, list, remove
  // ═══════════════════════════════════════════════════════════════

  app.post("/api/locker/add", async (c) => {
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;

    let body: any;
    try { body = await c.req.json(); } catch {
      return c.json({ success: false, error: { code: "PARSE_ERROR", message: "Invalid body", retryable: false } }, 400);
    }

    const { designId, projectId, imageUrl, storageKey, prompt, productType, style, conceptName } = body;
    if (!designId || !projectId || !imageUrl || !storageKey) {
      return c.json({ success: false, error: { code: "VALIDATION_ERROR", message: "Missing required fields", retryable: false } }, 400);
    }

    // Check if already locked
    const existing = await edgespark.db.select({ id: tables.lockerItems.id }).from(tables.lockerItems)
      .where(and(eq(tables.lockerItems.ownerUserId, user.id), eq(tables.lockerItems.designId, designId)))
      .limit(1);
    if (existing.length > 0) {
      return c.json({ success: true, id: existing[0].id, alreadyLocked: true });
    }

    const id = `locker_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    await edgespark.db.insert(tables.lockerItems).values({
      id, ownerUserId: user.id, projectId, designId,
      designImageUrl: imageUrl, storageKey,
      prompt: prompt || null, productType: productType || null,
      style: style || null, conceptName: conceptName || null,
    });

    return c.json({ success: true, id });
  });

  app.get("/api/locker", async (c) => {
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;

    const rows = await edgespark.db.select().from(tables.lockerItems)
      .where(eq(tables.lockerItems.ownerUserId, user.id));

    // Group by project
    const projectMap = new Map<string, typeof rows>();
    for (const r of rows) {
      const arr = projectMap.get(r.projectId) || [];
      arr.push(r);
      projectMap.set(r.projectId, arr);
    }

    const groups = await Promise.all(
      Array.from(projectMap.entries()).map(async ([projectId, items]) => {
        // Get project brief for name
        const projRow = await edgespark.db.select().from(tables.studioProjects)
          .where(eq(tables.studioProjects.id, projectId)).limit(1);
        let projectName = "Untitled Project";
        try {
          if (projRow[0]?.briefJson) projectName = JSON.parse(projRow[0].briefJson).name || projectName;
        } catch { /* ignore */ }

        return {
          projectId,
          projectName,
          items: items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).map((r) => ({
            id: r.id,
            designId: r.designId,
            designImageUrl: r.designImageUrl,
            storageKey: r.storageKey,
            prompt: r.prompt,
            productType: r.productType,
            style: r.style,
            conceptName: r.conceptName,
            createdAt: r.createdAt,
          })),
        };
      })
    );

    return c.json({ groups });
  });

  app.delete("/api/locker/:id", async (c) => {
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;
    const lid = c.req.param("id");

    const existing = await edgespark.db.select({ id: tables.lockerItems.id }).from(tables.lockerItems)
      .where(and(eq(tables.lockerItems.id, lid), eq(tables.lockerItems.ownerUserId, user.id)))
      .limit(1);
    if (existing.length === 0) return c.json({ error: "Not found" }, 404);

    await edgespark.db.delete(tables.lockerItems)
      .where(and(eq(tables.lockerItems.id, lid), eq(tables.lockerItems.ownerUserId, user.id)));

    return c.json({ success: true });
  });

  app.get("/api/design-url/:designId", async (c) => {
    const auth = requireUser(edgespark, c);
    if (!auth.ok) return auth.error;
    const user = auth.user;
    const did = c.req.param("designId");
    const rows = await edgespark.db.select().from(tables.generatedDesigns)
      .where(and(eq(tables.generatedDesigns.id, did), eq(tables.generatedDesigns.ownerUserId, user.id))).limit(1);
    if (rows.length === 0) return c.json({ error: "Not found" }, 404);
    const url = await getSignedUrl(edgespark, rows[0].storageKey);
    return c.json({ url });
  });

  return app;
}
